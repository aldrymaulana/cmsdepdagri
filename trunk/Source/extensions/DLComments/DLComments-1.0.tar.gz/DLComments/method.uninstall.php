<?php
if(!($this instanceof DLComments)) { exit; }

// Remove Permissions
$this->RemovePermission('DL Suite: Comments');

// Remove the table
$db =& $this->GetDb();
$dictionary = NewDataDictionary($db);
$sql = $dictionary->DropTableSQL(cms_db_prefix().'module_dlcomments');
$dictionary->ExecuteSQLArray($sql);

// Remove templates
$css_templates = explode('|', $this->GetPreference('list_of_css_templates'));
foreach($css_templates as $css_template) { $this->DeleteTemplate('css_'.$css_template); }

$comments_templates = explode('|', $this->GetPreference('list_of_comments_templates'));
foreach($comments_templates as $comments_template) { $this->DeleteTemplate('comments_'.$comments_template); }

$submission_form_templates = explode('|', $this->GetPreference('list_of_submission_form_templates'));
foreach($submission_form_templates as $submission_form_template) { $this->DeleteTemplate('submission_form_'.$submission_form_template); };

// Remove user preferences
$this->RemovePreference('missing_group');
$this->RemovePreference('missing_required');
$this->RemovePreference('success_add');
$this->RemovePreference('show_icon');
$this->RemovePreference('icon_success');
$this->RemovePreference('icon_warning');
$this->RemovePreference('icon_error');
$this->RemovePreference('auto_approve');
$this->RemovePreference('send_email');
$this->RemovePreference('email_address');
$this->RemovePreference('use_captcha');

// Add entry to admin log
$this->Audit(0, $this->GetFriendlyName(), 'Uninstalled DL Suite: Comments');
?>