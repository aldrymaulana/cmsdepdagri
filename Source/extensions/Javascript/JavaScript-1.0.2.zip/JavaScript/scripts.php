<?php
require('..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'fileloc.php');
require(CONFIG_FILE_LOCATION);

require(dirname(CONFIG_FILE_LOCATION).DIRECTORY_SEPARATOR.'include.php');

require(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'class.jsmin.php');
require(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'class.JavaScriptPacker.php');

$db = $gCms->GetDb();
$smarty = $gCms->GetSmarty();

$query = "SELECT * FROM {$config['db_prefix']}module_javascript WHERE javascript_external_include = 0";

if ( isset($_GET['javascript']) ) {
	$query .= " AND javascript_alias = " . $db->qstr($_GET['javascript']);
} else {
	$query .= " AND javascript_global <> 0";
}

$query .= " ORDER BY javascript_sort_order;";

$rsScripts = $db->Execute($query);

if ($db->ErrorNo() > 0) {
	echo "/*" . $db->ErrorMsg() . "*/";
}

while ( ($rsScripts) && (!$rsScripts->EOF) ) {
	echo "/*Script: {$rsScripts->fields['javascript_name']}*/\r";
	//Switch to our delimiters so that JS brackets are not processed
	// [-[ & ]-] ensure that JSON is not parsed as well
	$smarty->left_delimiter = '[-[';
	$smarty->right_delimiter = ']-]';
	
	//Compile the data and return in in $_compiled
	$smarty->_compile_source('Temporary JavaScript', $rsScripts->fields['javascript_content'], $_compiled );
	
	//Interpret the compiled information
	@ob_start();
	$smarty->_eval('?>' . $_compiled);
	$contents = @ob_get_contents();
	@ob_end_clean();
	
	//Set the delimiters back to the CMS to finish the rest of the processing
	$smarty->left_delimiter = '{';
	$smarty->right_delimiter = '}';
	
	//Display the JavaScript
	if ((bool)$rsScripts->fields['javascript_compress']) {
		echo "/*Minified using JSMin http://www.crockford.com/javascript/jsmin.html*/\r";
		$contents = JSMin::minify($contents);
	}
	
	if ((bool)$rsScripts->fields['javascript_pack']) {
		echo "/*Packed using Packer http://joliclic.free.fr/php/javascript-packer/en/*/\r";
		$packer = new JavaScriptPacker($contents, 'Normal', false, false);
		$contents = $packer->pack();
	}
	
	echo $contents;
	
	$rsScripts->MoveNext();
}

?>