<?php
if(!($this instanceof DLComments)) { exit; }

// Result array to be sent back
$response = array( 'success' => FALSE, 'hide_html_area' => FALSE, 'message' => '', 'html' => '');

// Get user input
$group      = DLSupport::SanitizeString($params['group']);
$user       = DLSupport::SanitizeString($params['user']);
$comment    = DLSupport::SanitizeString(html_entity_decode($params['comment']));

// Validate input
if(empty($group)) {
    $response['message'] = $this->GetIconFrontend('error', $this->Lang('error_messag').': ').$this->GetPreference('missing_group');
    DLSupport::CleanExit(json_encode($response));
}
if(empty($user) || empty($comment)) {
    $response['message'] = $this->GetIconFrontend('error', $this->Lang('error_message').': ').$this->GetPreference('missing_required');
    DLSupport::CleanExit(json_encode($response));
}
if(($this->GetPreference('use_captcha') == 'Yes') && !DLSupport::CaptchaValidate()) {
    $response['message'] = $this->Lang('invalid_captcha');
    DLSupport::CleanExit(json_encode($response));
}

// Get user preferences
$auto_approve = $this->GetPreference('auto_approve');
$send_email = $this->GetPreference('send_email');
$email_address = $this->GetPreference('email_address');

// Get the database object
$db =& $this->GetDb();

// SQL Templates
$insert = 'INSERT INTO %smodule_dlcomments (`group`, `user`, `comment`, `posted_date`, `approved`) VALUES ("%s", "%s", "%s", "%s", "%s");';
$sql = sprintf($insert, cms_db_prefix(), $group, $user, $comment, time(), ($auto_approve == 'Yes' ? '1' : '0'));

// Execute the command
$db->Execute($sql);

// If we made it here, it was a success
$response['success'] = TRUE;
$response['hide_html_area'] = TRUE;
$response['message'] = $this->GetIconFrontend('success', $this->Lang('success_message').': ').$this->GetPreference('success_add');

// See if we should send an email
if(($send_email == 'Yes') && !empty($email_address) && ($auto_approve == 'No')) {
    $mailer = DLSupport::ModuleInstance('CMSMailer');
    $mailer->reset();
    $mailer->IsHTML();
    $mailer->AddAddress($email_address);
    $mailer->SetSubject($this->Lang('mail_subject'));
    $mailer->SetBody($this->Lang('mail_body').$group);
    $mailer->Send();
}

DLSupport::CleanExit(json_encode($response));
?>