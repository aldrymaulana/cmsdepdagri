tinyMCE.addI18n('ca.searchreplace_dlg',{
searchnext_desc:"Torna a buscar",
notfound:"S'ha completat la recerca. No s'ha trobat la cadena buscada.",
search_title:"Busca",
replace_title:"Busca/Substitueix",
allreplaced:"S'han substitu\u00EFt totes les ocurr\u00E8ncies de la cadena buscada.",
findwhat:"Busca",
replacewith:"Substitueix per",
direction:"Direcci\u00F3",
up:"Amunt",
down:"Avall",
mcase:"Distingeix maj\u00FAscules i min\u00FAscules",
findnext:"Seg\u00FCent",
replace:"Substitueix",
replaceall:"Substitueix tot"
});