<?php
if(!($this instanceof DLComments)) { exit; }

// Get user input
$show_comments      = isset($params['comments']) ? (boolean)$params['comments'] : TRUE;
$show_form          = isset($params['form']) ? (boolean)$params['form'] : FALSE;
$show_css           = isset($params['css']) ? $params['css'] : TRUE;
$group              = !empty($params['group']) ? $params['group'] : ucwords(str_replace('-', ' ', DLSupport::GetPageInfo('alias')));
$comment_template   = !empty($params['comment_template']) ? $params['comment_template'] : FALSE;
$form_template      = !empty($params['form_template']) ? $params['form_template'] : FALSE;

if($show_css) {
    echo $this->ShowFrontendCSS($css);
}
if($show_comments) {
    echo $this->ShowUserComments($group, $comment_template);
}
if($show_form) {
    echo $this->ShowSubmissionForm($id, $returnid, $params, $group, $form_template);
}
?>