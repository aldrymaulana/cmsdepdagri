<?php

$db = $this->GetDb();
$dict = NewDataDictionary($db);

$sqlarray = $dict->DropTableSQL(cms_db_prefix()."module_javascript");
$dict->ExecuteSQLArray($sqlarray);

$db->DropSequence(cms_db_prefix()."module_javascript_seq");
?>