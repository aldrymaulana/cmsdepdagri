DLSupport.Browser = {
    Gecko: navigator.userAgent.indexOf('Gecko') > -1 && navigator.userAgent.indexOf('KHTML') == -1,
    IE: !!(window.attachEvent && !window.opera),
    MobileSafari: !!navigator.userAgent.match(/Apple.*Mobile.*Safari/),
    Opera: !!window.opera,
    WebKit: navigator.userAgent.indexOf('AppleWebKit/') > -1
};