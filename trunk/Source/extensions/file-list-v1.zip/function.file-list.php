echo "<ul>";
$dir = "ENTER FOLDER HERE"; // YOU CAN DEFINE YOU FOLDER STRUCTURE HERE I.E. /UPLOADS/FILE/DOWNLOADS/
if (is_dir($dir)) {
    if ($dh = opendir($dir)) {
	if ($handle = opendir($dir)) {
    while (false !== ($file = readdir($handle))) {
        if ($file != "." && $file != "..") {
            echo "<li><a href='$dir$file' target='_blank'>$file</a></li>";
        }
    }
    closedir($handle);
}
    }
	
}
echo "</ul>";