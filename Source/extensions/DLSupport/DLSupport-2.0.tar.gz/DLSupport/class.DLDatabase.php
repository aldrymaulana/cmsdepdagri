<?php
 /*
    Class: DLDatabase
        Provides a wrapper around the MySQLi functions.
*/
class DLDatabase {
    /*
        Group: Private Static Data

        Array: $instances
            (array) An array containing different instances of this class.
    */
    private static $instances = array();

    /*
        Group: Private Data

        Object: $mysqli
            (mysqli) An instance of the MySQLi object.
    */
    private $mysqli;

    /*
        Array: $sqls
            (array) An array containing SQLs that will be executed when the
            method <Execute> is called.
    */
    private $sqls = array();

    /*
        Group: Class Construction

        Constructor: __construct
            Create a new instance of DLDatabase.

        Parameters:
            $host - (string) The host to connect to the MySQL server.
            $username - (string) The username to connect to the MySQL server.
            $password - (string) The password to connect to the MySQL server.
            $database - (string) The name of the database to connect to.

        Returns:
            (DLDatabase) An instance of DLDatabase.
    */
    private function __construct($host, $username, $password, $database) {
        // Create the mysql object
        $this->mysqli = @new mysqli($host, $username, $password, $database);
    }

    /*
        Method: ObjectPool
            Retrieve an instance of this class based on the provided login
            information.

        Parameters:
            $host - (string) The host to connect to the MySQL server.
            $username - (string) The username to connect to the MySQL server.
            $password - (string) The password to connect to the MySQL server.
            $database - (string) The name of the database to connect to.

        Returns:
            (mixed) Either an instance of this class if the provided information
            is correct or FALSE if a connection could not be made.
    */
    public static function &ObjectPool($host, $username, $password, $database) {
        // Generate a unique key for the provided data
        $key = md5($host.'|'.$username.'|'.$password.'|'.$database);

        // Create the object if it doesn't already exists
        if(!isset(DLDatabase::$instances[$key])) {
            // Create the object
            DLDatabase::$instances[$key] = new DLDatabase(
                $host, $username, $password, $database
            );

            // Set this to FALSE if we could not connect
            if(mysqli_connect_errno()) {
                DLDatabase::$instances[$key] = FALSE;
            }
        }

        return DLDatabase::$instances[$key];
    }

    /*
        Method: Singleton
            Retrieve an instance of this class using the database information
            stored in the configuration file.

        Returns:
            (DLDatabase) An instance of DLDatabase.
    */
    public static function &Singleton() {
        // Get an instance of DLSupport
        $DLS = DLSupport::Singleton();

        // Retrieve the object
        return DLDatabase::ObjectPool(
            $DLS->config['db_hostname'], $DLS->config['db_username'],
            $DLS->config['db_password'], $DLS->config['db_name']
        );
    }

    /*
        Group: Data Retrieval

        Method: GetAllRows
            Retrieve all the rows in the database that match the given criteria.

            Note that this method will call the method <Execute> before it does
            any retrieval.

        Parameters:
            $table - (mixed) Either a string of the table or an array containing
                all the tables to retrieve from. If it is an array, refer to the
                method <BuildTableClause>.
            $select - (mixed) Either a string of the SELECT clause or an array
                containing all the columns to retrieve. If it is an array, refer
                to the method <BuildSelectClause>.
            $where - (mixed) Either a string of the WHERE clause or an array
                containing all the constraints. If it is an array, refer to the
                method <BuildWhereClause>. Defaults to an empty string.
            $options - (array) An array containing data used in this method.
                Refer to the methods <BuildJoinOnClause> and
                <BuildGroupByClause>, <BuildOrderByClause> for more information
                regarding some of the attributes. Defaults to an empty array.

            The structure of the *$options* parameter, if given, should look
            like the following:
            (code)
            array(
                and_or => {
                    (string) The joining string of the first level in the WHERE
                    clause. Defaults to "AND".
                },
                and_or_join => {
                    (string) The joining string of the first level in the JOIN
                    ON clause. Defaults to "AND".
                },
                distinct => {
                    (boolean) Whether or not the result should be distinct.
                    Defaults to FALSE.
                },
                freeform => {
                    (string) Anything else to be attached at the end of the SQL
                    right before the semicolon. Defaults to an empty string.
                },
                group_by => {
                    (mixed) Either a strinf of the GROUP BY clause or an array
                    containing the grouping. Refer to the method
                    BuildGroupByClause. Defaults to an empty string.
                }
                join => {
                    (mixed) Either a string of the JOIN ON clause or an array
                    containing the joining condition. Refer to the method
                    BuildJoinOnClause. Defaults to an empty string.
                },
                order => {
                    (mixed) Either a string of the ORDER BY clause or an array
                    containing the sorting preference. Refer to the method
                    <BuildOrderByClause>. Defaults to an empty string.
                }
            )
            (end)

        Returns:
            (array) An array containing all the rows in the database that match
            the search criteria. The result array will look something similar to
            the following:
            (code)
            array(
                array(
                    {The name of the column.} => {
                        (string) The value of the column.
                    },
                    ...
                ),
                ...
            )
            (end)
    */
    public function GetAllRows($table, $select, $where = '', $options = array()) {
        // Build the options array
        $options = array_merge(array(
            'and_or'        => 'AND',
            'and_or_join'   => 'AND',
            'distinct'      => FALSE,
            'freeform'      => '',
            'group_by'      => '',
            'join'          => '',
            'order'         => ''
        ), $options);

        // Execute any stored SQLs
        $this->Execute();

        // Build the various clauses
        $table_clause   = DLDatabase::BuildTableClause($table);
        $select_clause  = DLDatabase::BuildSelectClause($select);
        $where_clause   = DLDatabase::BuildWhereClause($where, $options['and_or']);
        $join_clause    = DLDatabase::BuildJoinOnClause($options['join'], $options['and_or_join']);
        $group_clause   = DLDatabase::BuildGroupByClause($options['group_by']);
        $order_clause   = DLDatabase::BuildOrderByClause($options['order']);

        // Generate the SQL
        $sql = sprintf(
            'SELECT %s %s FROM %s %s %s %s %s %s;',
            $options['distinct'] ? 'DISTINCT' : '',
            $select_clause,
            $table_clause,
            empty($join_clause) ? '' : 'ON '.$join_clause,
            empty($where_clause) ? '' : 'WHERE '.$where_clause,
            empty($group_clause) ? '' : 'GROUP BY '.$group_clause,
            empty($order_clause) ? '' : 'ORDER BY '.$order_clause,
            $options['freeform']
        );

        // Query
        $rs = $this->Query($sql);

        // Create the result array
        $result = array();
        while($rs && ($row = $rs->fetch_assoc())) {
            $result[] = $row;
        }

        return $result;
    }

    /*
        Method: GetAllRowsAssoc
            Same as the method <GetAllRows> except that the resulting array will
            be different depending on the number of columns the result set has.

        Parameters:
            $table - (mixed) Refer to the parameter *$table* from the method
                <GetAllRows>.
            $select - (mixed) Refer to the parameter *$select* from the method
                <GetAllRows>.
            $where - (mixed) Refer to the parameter *$where* from the method
                <GetAllRows>.
            $options - (array) Refer to the parameter *$options* from the method
                <GetAllRows>.

        Returns:
            (array) An array containing all the rows in the database that match
            the search criteria. If the result set has only one column, then the
            result will just be a single dimension array like the following:
            (code)
            array(
                {(string) The value of the column.},
                ...
            )
            (end)
            If it has two columns, then the result set will look like the
            following array:
            (code)
            array(
                {The value of the first column.} => {
                    (string) The value of the second column.
                },
                ...
            )
            (end)
            Note that if a value exist more than once for the first column, then
            the later value will overwrite the previous values. If there are
            three or more columns, then the result will be like the following:
            (code)
            array(
                {The value of the first column.} => array(
                    {The name of the second column} => {
                        (string) The value of the second column.
                    },
                    {The name of the third column} => {
                        (string) The value of the third column.
                    },
                    ...
                ),
                ...
            )
            (end)
            Again, the later value of the first column will overwrite the
            previous value so only use this if you are sure the first column is
            unique throughout.

        See:
            <GetAllRows>
    */
    public function GetAllRowsAssoc($table, $select, $where = '', $options = array()) {
        // Get all the rows
        $all_rows = $this->GetAllRows($table, $select, $where, $options);

        // Convert to the desired format
        $result = array();
        foreach($all_rows as $row) {
            switch(count($row)) {
                case 1:
                    $result[] = array_shift($row);
                    break;
                case 2:
                    $result[array_shift($row)] = array_shift($row);
                    break;
                default:
                    $result[array_shift($row)] = $row;
            }
        }

        return $result;
    }

    /*
        Method: GetFirstValue
            Retrieve a value of the first column of the first row.

        Parameters:
            $table - (mixed) Refer to the parameter *$table* from the method
                <GetAllRows>.
            $select - (mixed) Refer to the parameter *$select* from the method
                <GetAllRows>.
            $where - (mixed) Refer to the parameter *$where* from the method
                <GetAllRows>.
            $options - (array) Refer to the parameter *$options* from the method
                <GetAllRows>.

        Returns:
            (mixed) The value of the first column of the first row of the result
            set. This returns NULL if it doesn't exist.

        See:
            <GetAllRows>
    */
    public function GetFirstValue($table, $select, $where = '', $options = array()) {
        // Set the row to get to the first row
        $options['row_to_get'] = 0;

        // Get the first row
        $first_row = $this->GetSingleRow($table, $select, $where, $options);

        // Get the first column if it exists
        if(count($first_row) > 0) {
            return array_shift($first_row);
        } else {
            return NULL;
        }
    }

    /*
        Method: GetLastInsertID
            Returns the auto generated id used in the last query.

            Note that this will call the method <Execute> before it gets the
            last inserted ID.

        Returns:
            (int) The ID of the last inserted ID.
    */
    public function GetLastInsertID() {
        // Execute any stored query
        $this->Execute();

        return $this->mysqli->insert_id;
    }

    /*
        Method: GetSingleRow
            Retrieve a single row of the result set from the database.

        Parameters:
            $table - (mixed) Refer to the parameter *$table* from the method
                <GetAllRows>.
            $select - (mixed) Refer to the parameter *$select* from the method
                <GetAllRows>.
            $where - (mixed) Refer to the parameter *$where* from the method
                <GetAllRows>.
            $options - (array) Refer to the parameter *$options* from the method
                <GetAllRows>.

            The structure of the *$options* parameter, if given, should look
            like the following:
            (code)
            array(
                row_to_get => {
                    (int) The row to get. Note that the row counts begins with 0
                    so 0 is the first row, 1 is the second row, etc. Note that
                    if this is larger than the number rows that was retrieved,
                    then this will return NULL. Defaults to 0.
                }
            )
            (end)

        Returns:
            (mixed) The array containing the requested row or NULL if the given
            row doesn't exist. The resulting array would look something similar
            to the following:
            (code)
            array(
                {The name of the first column.} => {
                    (string) The value of the first column.
                },
                ...
            )
            (end)

        See:
            <GetAllRows>
    */
    public function GetSingleRow($table, $select, $where = '', $options = array()) {
        // Build the options array
        $options = array_merge(array(
            'row_to_get' => 0
        ), $options);

        // Retrieve all the rows
        $all_rows = $this->GetAllRows($table, $select, $where, $options);

        // Return the requested row
        if(isset($all_rows[$options['row_to_get']])) {
            return $all_rows[$options['row_to_get']];
        } else {
            return NULL;
        }
    }

    /*
        Method: RowCount
            See how many rows we would retrieve from the given table if the
            given constraints are set.

            Note that this method will call the method <Execute> before it does
            any retrieval.

        Parameters:
            $table - (mixed) Either a string of the table or an array containing
                all the tables to retrieve from. If it is an array, refer to the
                method <BuildTableClause>.
            $where - (mixed) Either a string of the WHERE clause or an array
                containing all the constraints. If it is an array, refer to the
                method <BuildWhereClause>.
            $options - (array) An array containing data used in this method.
                Refer to the method <BuildJoinOnClause> for more information
                regarding some of the attributes. Defaults to an empty array.

            The structure of the *$options* parameter, if given, should look
            like the following:
            (code)
            array(
                and_or => {
                    (string) The joining string of the first level in the WHERE
                    clause. Defaults to "AND".
                },
                and_or_join => {
                    (string) The joining string of the first level in the JOIN
                    ON clause. Defaults to "AND".
                },
                freeform => {
                    (string) Anything else to be attached at the end of the SQL
                    right before the semicolon. Defaults to an empty string.
                },
                join => {
                    (mixed) Either a string of the JOIN ON clause or an array
                    containing the joining condition. Refer to the method
                    BuildJoinOnClause. Defaults to an empty string.
                },
            )
            (end)

        Returns:
            (int) The number of rows that the query would have returned.
    */
    public function RowCount($table, $where, $options = array()) {
        // Build the options array
        $options = array_merge(array(
            'and_or'        => 'AND',
            'and_or_join'   => 'AND',
            'freeform'      => '',
            'join'          => ''
        ), $options);

        // Execute any stored SQL
        $this->Execute();

        // Build the various clauses
        $table_clause   = DLDatabase::BuildTableClause($table);
        $where_clause   = DLDatabase::BuildWhereClause($where, $options['and_or']);
        $join_clause    = DLDatabase::BuildJoinOnClause($options['join'], $options['and_or_join']);
        $order_clause   = DLDatabase::BuildOrderByClause($options['order']);

        // Generate the SQL
        $sql = sprintf(
            'SELECT COUNT(*) FROM %s %s %s %s %s;',
            $table_clause,
            empty($join_clause) ? '' : 'ON '.$join_clause,
            empty($where_clause) ? '' : 'WHERE '.$where_clause,
            empty($order_clause) ? '' : 'ORDER BY '.$order_clause,
            $options['freeform']
        );

        // Query
        $rs = $this->Query($sql);

        // Make sure we got something
        if($rs) {
            $row = $rs->fetch_row();

            $result = is_numeric($row[0]) ? $row[0] : 0;

            return $result;
        }

        return 0;
    }

    /*
        Group: Miscellaneous

        Method: BuildGroupByClause
            Build the GROUP BY clause.

        Parameters:
            $data - (mixed) An array of data for the grouping condition or the
                string for it.

            The structure of the *$data* parameter, if given, should look like
            the following:
            (code)
            array(
                {(string) The name of the column.},
                array(
                    table => {
                        (string) The alias of the table.
                    },
                    column => {
                        (string) The name of the column.
                    }
                ),
                ...
            )
            (end)

        Returns:
            (string) The GROUP BY clause.
    */
    public static function BuildGroupByClause($data) {
        // Just return an empty string if it is empty
        if(empty($data)) {
            return '';
        }

        // If it is a string, just return it
        if(is_string($data)) {
            return $data;
        }

        // Build the clauses
        $group_by_clauses = array();
        foreach($data as $item) {
            if(is_string($item)) {
                $group_by_clauses[] = sprintf('`%s`', $item);
            } else {
                $group_by_clauses[] = sprintf(
                    '%s.`%s`', $item['table'], addcslashes($item['column'], '"')
                );
            }
        }

        $result = implode(', ', $group_by_clauses);

        return $result;
    }

    /*
        Method: BuildJoinOnClause
            Build the JOIN clause.

        Parameters:
            $data - (mixed) An array of data for the joining condition or the
                string for it.
            $join - (string) Optional and defaults to "AND". What to join the
                constraints with. Note that this will alternate for each inner
                array. Values for this should be either "AND" or "OR".

            The structure of the *$data* parameter, if given, should look like
            the following:
            (code)
            array(
                array(
                    left => array(
                        table => {
                            (string) The alias of the table.
                        },
                        column => {
                            (string) The name of the column.
                        }
                    ),
                    op => {
                        (string) The operator to use. Defaults to "=".
                    },
                    right => array(
                        table => {
                            (string) The alias of the table.
                        },
                        column => {
                            (string) The name of the column.
                        }
                    )
                ),
                array(
                    array(
                        left => array(
                            table => {
                                (string) The alias of the table.
                            },
                            column => {
                                (string) The name of the column.
                            }
                        ),
                        op => {
                            (string) The operator to use. Defaults to "=".
                        },
                        right => array(
                            table => {
                                (string) The alias of the table.
                            },
                            column => {
                                (string) The name of the column.
                            }
                        )
                    ),
                    ...
                ),
                ...
            )
            (end)

        Returns:
            (string) The JOIN clause.
    */
    public static function BuildJoinOnClause($data, $join = 'AND') {
        // Make sure we actually have data to work on
        if(empty($data)) {
            return '';
        }

        // If it is a string, just return it
        if(is_string($data)) {
            return $data;
        }

        $constraint_clauses = array();
        foreach($data as $constraint) {
            // See if this is a single constraint or group of them
            if(isset($constraint[0])) { // Group
                $constraint_clauses[] = DLDatabase::BuildJoinOnClause(
                    $constraint, $join == 'AND' ? 'OR' : 'AND'
                );
            } else { // Single
                $constraint_clauses[] = sprintf(
                    '%s.`%s` %s %s.`%s`',
                    $constraint['left']['table'], $constraint['left']['column'],
                    empty($constraint['op']) ? '=' : $constraint['op'],
                    $constraint['right']['table'], $constraint['right']['column']
                );
            }
        }

        // Join them together
        $result = '('.implode(" $join ", $constraint_clauses).')';

        return $result;
    }

    /*
        Method: BuildOrderByClause
            Build the ORDER BY clause from an array.

        Parameters:
            $data - (mixed) Either the ORDER BY clause itself or an array that
                the ORDER BY clause will be built from.

            The structure of the *$data* parameter, if given, should look like
            the following:
            (code)
            array(
                array(
                    column => {
                        (string) The name of the column.
                    },
                    order => {
                        (string) The order in which the column should be sorted.
                        Possible values are "ASC" and "DESC".
                    }
                ),
                array(
                    column => array(
                        table => {
                            (string) The alias of the table.
                        },
                        column => {
                            (string) The name of the column.
                        }
                    ),
                    order => {
                        (string) The order in which the column should be sorted.
                        Possible values are "ASC" and "DESC".
                    }
                )
                ...
            )
            (end)

        Returns:
            (string) The ORDER BY clause.
    */
    public static function BuildOrderByClause($data) {
        // Make sure we actually have data to work on
        if(empty($data)) {
            return '';
        }

        // If it is a string, just return it
        if(is_string($data)) {
            return $data;
        }

        $order_by_clauses = array();
        foreach($data as $item) {
            if(is_array($item['column'])) {
                $item['column'] = sprintf(
                    '%s.`%s`', $item['column']['table'],
                    $item['column']['column']
                );
            } else {
                $item['column'] = sprintf('`%s`', $item['column']);
            }

            $order_by_clauses[] = sprintf(
                '%s %s', $item['column'], $item['order']
            );
        }

        // Join them together
        $result = implode(', ', $order_by_clauses);

        return $result;
    }

    /*
        Method: BuildSelectClause
            Build the SELECT clause from an array.

        Parameters:
            $data - (mixed) The array that the SELECT clause will be built from
                or a string for it.

            The structure of the *$data* parameter, if given, should look like
            the following:
            (code)
            array(
                {(string) The name of the column.},
                array(
                    type => 'freeform',
                    value => {
                        (string) The value for the select.
                    }
                ),
                array(
                    type => 'column',
                    column => {
                        (string) The name of the column. This is the default
                        type if the type is not given. Note that this is the
                        same as just specifying the column name as a string.
                    }
                ),
                array(
                    type => 'alias',
                    column => {
                        (string) The name of the column.
                    },
                    alias => {
                        (string) The alias for the column.
                    }
                ),
                array(
                    type => 'table',
                    table => {
                        (string) The alias of the table.
                    },
                    column => {
                        (string) The name of the column.
                    }
                ),
                array(
                    type => 'table_alias',
                    table => {
                        (string) The alias of the table.
                    },
                    column => {
                        (string) The name of the column.
                    },
                    alias => {
                        (string) The alias for the column.
                    }
                ),
                array(
                    type => 'function'
                    function => {
                        (string) The MySQL function.
                    },
                    column => {
                        (string) The name of the column.
                    },
                    alias => {
                        (string) The alias for the result of the function.
                    }
                ),
                array(
                    type => 'function_table'
                    function => {
                        (string) The MySQL function.
                    },
                    table => {
                        (string) The alias of the table.
                    },
                    column => {
                        (string) The name of the column.
                    },
                    alias => {
                        (string) The alias for the result of the function.
                    }
                ),
                ...
            )
            (end)

        Returns:
            (string) The SELECT clause.
    */
    public static function BuildSelectClause($data) {
        // If it is a string, just return it
        if(is_string($data)) {
            return $data;
        }

        $select_clauses = array();
        foreach($data as $column) {
            // if it is a string, just use it
            if(is_string($column)) {
                $select_clauses[] = sprintf('`%s`', $column);
                continue;
            }

            // We do different things depending on the type
            switch($column['type']) {
                case 'alias':
                    $select_clauses[] = sprintf(
                        '`%s` AS "%s"', $column['column'],
                        addcslashes($column['alias'], '"')
                    );
                    break;
                case 'freeform':
                    $select_clauses[] = (string) $column;
                case 'function':
                    $select_clauses[] = sprintf(
                        '%s(`%s`) AS "%s"', $column['function'],
                        $column['column'], addcslashes($column['alias'], '"')
                    );
                    break;
                case 'function_table':
                    $select_clauses[] = sprintf(
                        '%s(%s.`%s`) AS "%s"', $column['function'],
                        $column['table'], $column['column'],
                        addcslashes($column['alias'], '"')
                    );
                    break;
                case 'table':
                    $select_clauses[] = sprintf(
                        '%s.`%s`', $column['table'], $column['column']
                    );
                    break;
                case 'table_alias':
                    $select_clauses[] = sprintf(
                        '%s.`%s` AS "%s"', $column['table'], $column['column'],
                        addcslashes($column['alias'], '"')
                    );
                    break;
                default:
                    $select_clauses[] = sprintf('`%s`', $column['column']);
            }
        }

        // Join them together
        $result = implode(', ', $select_clauses);

        return $result;
    }

    /*
        Method: BuildTableClause
            Build the table clause.

        Parameters:
            $tables - (mixed) An array of tables or the string for it.

            The structure of the *$tables* parameter, if given, should look like
            the following:
            (code)
            array(
                {(string) The name of the table.},
                array(
                    table => {
                        (string) The name of the table.
                    },
                    alias => {
                        (string) The alias for the table.
                    }
                ),
                ...
            )
            (end)

        Returns:
            (string) The table clause.
    */
    public static function BuildTableClause($tables) {
        // If it is a string, things are more simple
        if(is_string($tables)) {
            return sprintf('`%s`', $tables);
        }

        if(is_array($tables)) {
            $tpt = '`%s` AS %s';

            // Get the first table
            $first_table = array_shift($tables);

            // Generate the first result
            $result = sprintf(
                $tpt, $first_table['table'], $first_table['alias']
            );

            // If there is more, we need an INNER JOIN clause
            if(!empty($tables)) {
                $tmp = array();
                foreach($tables as $table) {
                    $tmp[] = sprintf(
                        '`%s` AS %s', $table['table'], $table['alias']
                    );
                }

                $result .= ' INNER JOIN '.implode(', ', $tmp);
            }
        }

        return $result;
    }

    /*
        Method: BuildWhereClause
            Build the WHERE clause from an array. This will alternate between OR
            and AND as it goes further in the array.

        Parameters:
            $data - (mixed) The array that the WHERE clause will be built from
                or a string for it.
            $join - (string) Optional and defaults to "AND". What to join the
                constraints with. Note that this will alternate for each inner
                array. Values for this should be either "AND" or "OR".

            The structure of the *$data* parameter, if given, should look like
            the following:
            (code)
            array(
                array(
                    column => {
                        (string) The name of the column.
                    },
                    op => {
                        (string) The operator to use. Defaults to "=".
                    },
                    value => {
                        (string) The value to compare against.
                    }
                ),
                array(
                    column => array(
                        table => {
                            (string) The alias of the table.
                        },
                        column => {
                            (string) The name of the column.
                        }
                    ),
                    op => {
                        (string) The operator to use. Defaults to "=".
                    },
                    value => {
                        (string) The value to compare against.
                    }
                ),
                array(
                    array(
                        column => {
                            (string) The name of the column.
                        },
                        op => {
                            (string) The operator to use. Defaults to "=".
                        },
                        value => {
                            (string) The value to compare against.
                        }
                    ),
                    ...
                ),
                ...
            )
            (end)

        Returns:
            (string) The body of the WHERE clause.
    */
    public static function BuildWhereClause($data, $join = 'AND') {
        // Make sure we actually have data to work on
        if(empty($data)) {
            return '';
        }

        // If it is a string, just return it
        if(is_string($data)) {
            return $data;
        }

        $constraint_clauses = array();
        foreach($data as $constraint) {
            // See if this is a single constraint or group of them
            if(isset($constraint[0])) { // Group
                $constraint_clauses[] = DLDatabase::BuildWhereClause(
                    $constraint, $join == 'AND' ? 'OR' : 'AND'
                );
            } else { // Single
                if(is_array($constraint['column'])) {
                    $constraint['column'] = sprintf(
                        '%s.`%s`', $constraint['column']['table'],
                        $constraint['column']['column']
                    );
                } else {
                    $constraint['column'] = sprintf(
                        '`%s`', $constraint['column']
                    );
                }

                $constraint_clauses[] = sprintf(
                    '%s %s "%s"', $constraint['column'],
                    empty($constraint['op']) ? '=' : $constraint['op'],
                    addcslashes($constraint['value'], '"')
                );
            }
        }

        // Join them together
        $result = '('.implode(" $join ", $constraint_clauses).')';

        return $result;
    }

    /*
        Method: GetSQLs
            Retrieve the currently stored SQLs.

        Returns:
            (array) An array of the SQLs to be executed.
    */
    public function GetSQLs() {
        return $this->sqls;
    }

    /*
        Group: Row Manipulation

        Method: DeleteData
            Delete data from the database.

        Parameters:
            $table - (string) The table where the data should be updated.
            $where - (mixed) Either a string of the WHERE clause or an array
                containing all the constraints. If it is an array, refer to the
                method <BuildWhereClause>. Defaults to an empty string.
            $options - (array) An array containing data used in this method.
                Defaults to an empty array.

            The structure of the *$options* parameter, if given, should look
            like the following:
            (code)
            array(
                and_or => {
                    (string) The joining string of the first level in the WHERE
                    clause. Defaults to "AND".
                },
                freeform => {
                    (string) Anything else to be attached at the end of the SQL
                    right before the semicolon. Defaults to an empty string.
                }
            )
            (end)
    */
    public function DeleteData($table, $where = '', $options = array()) {
        // Build the options array
        $options = array_merge(array(
            'and_or'    => 'AND',
            'freeform'  => ''
        ), $options);

        // Build the where clauses
        $where_clause   = DLDatabase::BuildWhereClause($where, $options['and_or']);

        // Generate the SQL
        $sql = sprintf(
            'DELETE FROM `%s` %s %s;',
            addslashes($table),
            empty($where_clause) ? '' : 'WHERE '.$where_clause,
            $options['freeform']
        );

        // Append to execution list
        $this->sqls[] = $sql;
    }

    /*
        Method: InsertData
            Insert data into the database.

            Note that this method will not actually execute until the method
            <Execute> is called.

        Parameters:
            $table - (string) The table where the data should be updated.
            $data - (array) An associative array of the data to be inserted. The
                key should correspond to the column name.

            The structure of the *$data* parameter, if given, should look like
            the following:
            (code)
            array(
                {The name of the column.} => {
                    (string) The value for the column.
                },
                {The name of the column.} => array(
                    value => {
                        (string) The value for the column. The difference
                        between this and the string only is that this will not
                        be surrounded by quotes. Use this if you need to call
                        a MySQL function.
                    }
                ),
                ...
            )
            (end)
    */
    public function InsertData($table, $data) {
        // Get the column names
        $keys = array_keys($data);

        // Build the column string
        $columns = '`'.implode('`, `', $keys).'`';

        // Add slashes to the values
        foreach($data as $key => $item) {
            if(is_string($item)) {
                $data[$key] = '"'.addcslashes($item, '"').'"';
            } else {
                $data[$key] = $item['value'];
            }
        }

        // Build the values string
        $values = implode(', ', $data);

        // Generate the SQL
        $sql = sprintf(
            'INSERT INTO `%s` (%s) VALUES(%s);',
            addslashes($table), $columns, $values
        );

        // Add SQL to execution list
        $this->sqls[] = $sql;
    }

    /*
        Method: UpdateData
            Update existing data in the database.

            Note that this method will not actually execute until the method
            <Execute> is called.

        Parameters:
            $table - (string) The table where the data should be updated.
            $data - (array) An associative array of the data to be updated. The
                key should correspond to the column name.
            $where - (mixed) Either a string of the WHERE clause or an array
                containing all the constraints. If it is an array, refer to the
                method <BuildWhereClause>.

            The structure of the *$data* parameter, if given, should look like
            the following:
            (code)
            array(
                {The name of the column.} => {
                    (string) The value for the column.
                },
                {The name of the column.} => array(
                    {
                        (string) The value for the column. The difference
                        between this and the string only is that this will not
                        be surrounded by quotes. Use this if you need to call
                        a MySQL function.
                    }
                ),
                ...
            )
            (end)
    */
    public function UpdateData($table, $data, $where) {
        // Get the individual update field
        $fields = array();
        foreach($data as $key => $value) {
            if(is_string($value)) {
                $fields[] = '`'.$key.'` = "'.addslashes($value).'"';
            } else {
                $fields[] = '`'.$key.'` = '.$value;
            }
        }

        // Build the update string
        $update = implode(', ', $fields);

        // Generate the SQL
        $sql = sprintf(
            'UPDATE `%s` SET %s WHERE %s;',
            addslashes($table), $update, DLDatabase::BuildWhereClause($where)
        );

        // Add SQL to execution list
        $this->sqls[] = $sql;
    }

    /*
        Group: SQL Execution

        Method: Execute
            Execute all of the currently stored SQLs.
    */
    public function Execute() {
        // No need to do anything if we don't have any SQL statements
        if(empty($this->sqls)) { return; }

        foreach($this->sqls as $sql) {
            $this->Query($sql);
        }

        // Clear the execution list
        $this->sqls = array();
    }

    /*
        Method: Query
            Query the database with the given SQL.

        Parameters:
            $sql - (string) The SQL statement to query.

        Returns:
            (mixed) The result of the query.
    */
    public function &Query($sql) {
        $result = $this->mysqli->query($sql);

        if(!$result) {
            error_log('SQL: '.$sql.'<br />Error: '.$this->mysqli->error);
            exit(0);
        }

        return $result;
    }

    /*
        Group: Table Manipulation

        Method: CreateTable
            Create a new table in the database. Note that this method will not
            actually execute until the method <Execute> is called.

        Parameters:
            $table - (string) The name of the table to create.
            $columns - (array) An associative array containing columns for the
                given table.
            $options - (array) An associative array containing various options
                used by this method. Defaults to an empty array.

            The structure of the *$columns* parameter, if given, should look
            like the following:
            (code)
            array(
                {The name of the column.} => array(
                    auto_increment => {
                        (boolean) Whether or not the column should have the auto
                        increment property. Defaults to FALSE.
                    },
                    default => {
                        (string) The default value for the column if it is not
                        given. Defaults to an empty string.
                    },
                    default_quotes => {
                        (boolean) Whether or not the default value should be
                        surrounded by double quotes. Defaults to TRUE.
                    }
                    index => {
                        (boolean) Whether or not the column should be indexed.
                        Defaults to FALSE.
                    },
                    null => {
                        (boolean) Whether or not the column can be null.
                        Defaults to FALSE.
                    },
                    primary => {
                        (boolean) Whether or not the column should be the
                        primary key. Defaults to FALSE.
                    },
                    type => {
                        (string) The type of the column. Default to "VARCHAR".
                    },
                    unique => {
                        (boolean) Whether or not the column's data should be
                        unique. Defaults to FALSE.
                    },
                    value => {
                        (string) The value or length for the column. Default to
                        an empty string.
                    }
                ),
                ...
            )
            (end)

            The structure of the *$options* parameter, if given, should look
            like the following:
            (code)
            array(
                drop => {
                    (boolean) Drop the table if it already exists. Defaults to
                    FALSE.
                },
                if_no_exists => {
                    (boolean) Only create the table if it does not already
                    exists. Defaults to TRUE.
                }
            )
            (end)

        Returns:
            (boolean) Returns TRUE if successful, FALSE, otherwise.
    */
    public function CreateTable($table, $columns, $options = array()) {
        // Make sure the columns are given
        if(empty($columns)) { return FALSE; }

        // Merge the user options with the default options
        $options = array_merge(array(
            'if_not_exists' => TRUE,
            'drop'          => FALSE
        ), $options);

        // See if we want to drop the table
        if($options['drop']) {
            $this->DropTable($table);
        }

        // Template for table creation
        // if not exists, table name, columns, indexes
        $tpt = 'CREATE TABLE %s `%s` (%s%s) ENGINE = MYISAM;';

        // Prepare the columns
        $the_columns = array();
        $the_indexes = array();
        foreach($columns as $column => $data) {
            // Merge the column options with default options
            $data = array_merge(array(
                'type' => 'VARCHAR', 'value' => '', 'null' => FALSE,
                'default' => '', 'default_quotes' => TRUE,
                'auto_increment' => FALSE, 'primary' => FALSE,
                'index' => FALSE, 'unique' => FALSE
            ), $data);

            // Column name
            $tmp = '`'.addslashes($column).'` ';

            // Type
            $tmp .= $data['type'];
            if(empty($data['value'])) {
                $tmp .= ' ';
            } else {
                $tmp .= '('.addslashes($data['value']).') ';
            }

            // Nullness
            $tmp .= $data['null'] ? 'NULL ' : 'NOT NULL ';

            // Auto increment
            $tmp .= $data['auto_increment'] ? 'AUTO_INCREMENT ' : '';

            // Default values
            if(!empty($data['default'])) {
                if($data['default_quotes']) {
                    $tmp .= 'DEFAULT "'.addslashes($data['default']).'" ';
                } else {
                    $tmp .= 'DEFAULT '.addslashes($data['default']).' ';
                }
            }

            // Primary key
            $tmp .= $data['primary'] ? 'PRIMARY KEY ' : '';

            // Unique
            $tmp .= $data['unqiue'] ? 'UNIQUE ' : '';

            // Set the column data
            $the_columns[] = $tmp;

            // Index
            if($data['index']) {
                $the_indexes[] = addslashes($column);
            }
        }

        // Generate the sql
        $sql = sprintf(
            $tpt,
            ($options['if_not_exists'] ? 'IF NOT EXISTS ' : ''),
            addslashes($table),
            implode(', ', $the_columns),
            (empty($the_indexes) ? '' : ', INDEX (`'.implode('`, `', $the_indexes).'`)')
        );

        // Append to execution list
        $this->sqls[] = $sql;

        return TRUE;
    }

    /*
        Method: DropTable
            Drop the given table from the database. Note that this method will
            not actually execute until the method <Execute> is called.

        Parameters:
            $table - (string) The name of the table to drop.
    */
    public function DropTable($table) {
        // Generate sql
        $sql = sprintf('DROP TABLE IF EXISTS `%s`;', addslashes($table));

        // Append to execution list
        $this->sqls[] = $sql;
    }
}
?>