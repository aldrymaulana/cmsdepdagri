<?php
if(!($this instanceof DLComments)) { exit; }

// Result array to be sent back
$response = array( 'success' => FALSE, 'hide_html_area' => FALSE, 'message' => '', 'html' => '');

// Get user inputs
$comments   = filter_var_array($params['selections'], FILTER_VALIDATE_INT);
$action     = DLSupport::SanitizeString($params['submit']);
$group      = DLSupport::SanitizeString($params['group']);
$type       = ($action == $this->Lang('approve')) ? 'approval' : 'modify';

// Make sure comments is an array of ids
$ids = array();
if(is_array($comments)) {
    foreach($comments as $comment) {
        if(is_numeric($comment)) { $ids[] = $comment; }
    }
}

// Validation
if(empty($ids)) {
    $response['message'] = $this->GetIcon('remove', $this->Lang('error_message').': ').$this->Lang('failure_missing_ids_'.$type);
    DLSupport::CleanExit(json_encode($response));
}

// Get the database object
$db =& $this->GetDb();

// SQL Templates
$update = 'UPDATE %smodule_dlcomments SET `approved` = 1%s WHERE `id` = %s; ';
$remove = 'DELETE FROM %smodule_dlcomments WHERE %s;';

// Process appropriately depending on the action
switch($action) {
    case $this->Lang('approve'):
    case $this->Lang('save'):
        // Update each comment individually
        foreach($ids as $value) {
            // Get data from post
            $user_info = DLSupport::SanitizeString('DLComments_user_'.$value, INPUT_POST);
            $comment_info = DLSupport::SanitizeString('DLComments_comment_'.$value, INPUT_POST);

            // Prepare SQL
            $extra = '';
            if(!empty($user_info)) {
                $extra .= ', `user` = "'.$user_info.'"';
            }
            if(!empty($comment_info)) {
                $extra .= ', `comment` = "'.$comment_info.'"';
            }
            $sql = sprintf($update, cms_db_prefix(), $extra, $value);

            // Execute SQL
            $db->Execute($sql);
        }
        break;
    case $this->Lang('remove'):
        // Prepare SQL
        foreach($ids as $key => $value) { $ids[$key] = "`id` = $value"; }
        $where_clause = implode(' OR ', $ids);
        $sql = sprintf($remove, cms_db_prefix(), $where_clause);

        // Execute SQL
        $db->Execute($sql);
        break;
    default:
        $response['message'] = $this->GetIcon('remove', $this->Lang('error_message').': ').$this->Lang('failure_invalid_action_'.$type);
        DLSupport::CleanExit(json_encode($response));
}

// If we made it here, it was a success
$response['success'] = TRUE;
$response['message'] = $this->GetIcon('accept', $this->Lang('success_message').': ').$this->Lang('success_update_'.$type);

// Get the updated group listing
$updated_listing = $this->GetCommentsListing($id, $returnid, $params);
if($updated_listing['success'] && !empty($updated_listing['html'])) {
    $response['html'] = $updated_listing['html'];
} else {
    // Hide the listing area if no comments were found
    $response['hide_html_area'] = TRUE;
}

DLSupport::CleanExit(json_encode($response));
?>