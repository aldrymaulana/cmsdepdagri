<?php // No sense in declaring this class if it is already declared
if(!class_exists('DLEncryption_Two')) {

/*
    Class: DLEncryption_Two
        Encryption class based of MD5 64. Originally written by Agus Hariyanto
        <iam_emc2@yahoo.com>.
*/
class DLEncryption_Two extends DLEncryption {
    /*
        Group: Inherit Methods

        Method: Decrypt
            Decrypt the given data using the given key.

        See:
            <DLEncryption->Decrypt>
    */
    public function Decrypt($key, $data) {
        // Hash the given key
        $key = $this->Hash($key);

        // Base64 Decode
        $tmp = base64_decode($data);

        // Start decrypting
        $key = md5($key);
        $x   = 0;
        $l   = strlen($tmp);

        for($i = 0; $i < $l; ++$i) {
            if($x == strlen($key)) { $x = 0; }

            $char .= substr($key, $x, 1);
            $x++;
        }

        for($i = 0; $i < $l; ++$i) {
            if(ord(substr($tmp, $i, 1)) < ord(substr($char, $i, 1))) {
                $charx .= chr((ord(substr($tmp, $i, 1)) + 256) - ord(substr($char, $i, 1)));
            } else {
                $charx .= chr(ord(substr($tmp, $i, 1)) - ord(substr($char, $i, 1)));
            }
        }

        // Base64 Decode
        $result = base64_decode($charx);

        // Unserialize
        $result = unserialize($result);

        return $result;
    }

    /*
        Method: Encrypt
            Encrypt the given data using the given key.

        See:
            <DLEncryption->Encrypt>
    */
    public function Encrypt($key, $data) {
        // Hash the given key
        $key = $this->Hash($key);

        // Serialize
        $tmp = serialize($data);

        // Base64 Encode
        $tmp = base64_encode($tmp);

        // Start encrypting
        $key = md5($key);
        $x   = 0;
        $l   = strlen($tmp);

        for($i = 0; $i < $l; ++$i) {
            if($x == strlen($key)) { $x = 0; }

            $char .= substr($key, $x, 1);
            ++$x;
        }

        for($i = 0; $i < $l; ++$i) {
            $charx .= chr(ord(substr($tmp, $i, 1)) + (ord(substr($char, $i, 1))) % 256);
        }

        // Base64 Encode again
        $result = base64_encode($charx);

        return $result;
    }
}

}
?>