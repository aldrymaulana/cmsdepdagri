/*
    Class: DLSupport.Viewport
        Contains information regarding the current viewport.

        This is used when we cannot use Prototype.
*/
DLSupport.Viewport = {
    /*
        Method: getDimensions
            Retrieve the size of the viewport.

        Returns:
            (object) An object with the following properties: height & width.
    */
    getDimensions: function() {
        var result = {};
        if(DLSupport.Browser.WebKit && !document.evaluate) {
            result.height = self.innerHeight;
            result.width = self.innerWidth;
        } else if(DLSupport.Browser.Opera) {
            result.height = document.body.clientHeight;
            result.width = document.body.clientWidth;
        } else {
            result.height = document.documentElement.clientHeight;
            result.width = document.documentElement.clientWidth;
        }

        return result;
    },

    /*
        Method: getOffsets
            Retrieve the offsets of the viewport from the top left corner.

        Returns:
            (object) An object with the following properties: left & top.
    */
    getOffsets: function() {
        return {
            left: window.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft,
            top: window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop
        };
    }
};