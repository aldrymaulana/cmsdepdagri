<?php

$query = "DELETE FROM {$this->table_base}javascript WHERE javascript_id = ?";
$this->db->Execute($query, array($params['javascript_id']));

$redir_params = array('tab_message'=> 'deleted_javascript', 'active_tab' => 'javascripts');
$this->Redirect($id, 'defaultadmin', '', $redir_params);

?>