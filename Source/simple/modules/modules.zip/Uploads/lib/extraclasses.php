<?php

class UploadsException extends Exception {}

?>