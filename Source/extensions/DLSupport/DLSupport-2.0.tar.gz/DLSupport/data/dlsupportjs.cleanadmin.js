/*
    Class: DLSupportJS.CleanAdmin
        Sub class of <DLSupportJS> providing support for the clean admin.
*/
DLSupportJS.CleanAdmin = {
    /*
        Method: AlertError
            Alert an error message.

        Parameters:
            type - (string) The type of error to alert. Possible values are type
                are: *freeform* ~ The message to be alerted will be whatever is
                the value of the _message_ attribute of the parameter *options*.
                *invalid_data* ~ The alerted message will let the user know that
                the response from the server results in an invalid data.
                *openlink* ~ The alerted message will let the user know that the
                requested page could not be reached. *submitform* ~ The alerted
                message will let the user know the form could not be submitted.
            options - (object) An object containing various options used in the
                execution of this method. Defaults to an empty object.

            The structure of the *options* parameter, if given, should look like
            the following:
            (code)
            Object(
                message: {
                    (string) The message to be alerted to the user. Defaults to
                    an empty string.
                }
            )
            (end)

        Returns:
            (boolean) This method will always return true.
    */
    AlertError: function(type) {
        // Get the options
        var options = Object.extend({
            message: ''
        }, arguments[1] || {});

        // Process appropriately depending on the type
        var message;
        switch(type) {
            case 'freeform':
                message = options.message;
                break;
            case 'invalid_data':
                message = 'The response from the server could not be processed.'
                        + ' Please contact site administrator for help.';
                break;
            case 'submitform':
                message = 'The form could not be submitted. Please try again.';
                break;
        }

        // Get the alert message box
        var container = $('AlertMessageData');

        // Update the error message
        container.update(message);

        // Make sure it is ready for alerting an error message
        container.addClassName('error_message');

        // Show the alert message box
        $('AlertMessage').show();

        return true;
    },

    /*
        Method: Initialize
            Initialize the script.
    */
    Initialize: function() {
        Event.observe(window, 'load', DLSupportJS.CleanAdmin._Initialize);
    },
    _Initialize: function() {
        // First update links for the menu
        var links = $$('.CleanAdminPages a');

        for(var i = 0; i < links.length; ++i) {
            if(links[i].href != 'javascript:void(0);') {
                Event.observe(
                    links[i], 'click',
                    DLSupportJS.CleanAdmin.OpenPage.curry(links[i].href, true)
                );

                links[i].writeAttribute('TheHREF', links[i].href);
                links[i].href = 'javascript:void(0);';
            }
        }

        // Now do it for other links that needs to be changed
        links = $$('.ChangeToCleanAdminLink a');

        for(var i = 0; i < links.length; ++i) {
            if(links[i].href != 'javascript:void(0);') {
                Event.observe(
                    links[i], 'click',
                    DLSupportJS.CleanAdmin.OpenPage.curry(links[i].href, false)
                );

                links[i].writeAttribute('TheHREF', links[i].href);
                links[i].href = 'javascript:void(0);';
            }
        }
    },

    /*
        Method: OpenPage
            Open up a new page.

        Parameters:
            href - (string) The URL of the page to open.
            is_menu - (boolean) Whether or not the link is a menu link
    */
    OpenPage: function(href, is_menu) {
        if(is_menu) {
            // Get all the pages links
            var pages = $$('.CleanAdminPages a');

            // Set to the "selected" page
            for(var i = 0; i < pages.length; ++i) {
                if(pages[i].readAttribute('TheHREF') == href) {
                    pages[i].addClassName('selected');
                } else {
                    pages[i].removeClassName('selected');
                }
            }
        }

        // Hide the alert error box
        $('AlertMessage').hide();

        // Show the loading image
        DLSupportJS.ShowLoadingImage({
            finish: function(href) {
                // Open the page
                new Ajax.Request(href, {
                    onSuccess: DLSupportJS.CleanAdmin.ServerResponse
                });
            }.curry(href)
        });
    },

    /*
        Method: ServerResponse
            Process the server response.

        Parameters:
            transport - (object) The AJAX transport.
    */
    ServerResponse: function(transport) {
        // Process the json
        try {
            var data = transport.responseText.evalJSON();

            DLSupportJS.CleanAdmin._ServerResponse(data);
        } catch(e) {
            DLSupportJS.CleanAdmin.AlertError('invalid_data');
        }

        // Hide the loading image
        DLSupportJS.HideLoadingImage();
    },
    _ServerResponse: function(data) {
        // Process appropriately depending on the action
        switch(data.action) {
            case 'alert_error':
                DLSupportJS.CleanAdmin.AlertError(
                    'freeform', {message: data.message}
                );
                break;
            case 'function':
                var funct = eval(data.funct);
                funct.apply(window, [data.parameters]);
                break;
            case 'new_page':
                DLSupportJS.CleanAdmin.UpdatePage(data.content);
                DLSupportJS.CleanAdmin._Initialize();
                break;
        }
    },

    /*
        Method: SetAction
            Set the action for the form of the given button.

        Parameters:
            button - (mixed) Either the ID of the button or the DOM element for
                the button itself.

        Returns:
            (boolean) This method will always return true.
    */
    SetAction: function(button) {
        // Make sure it is an object
        button = $(button);

        // Get the form
        var form = button.form;

        // Set the action to the value of the button
        form.writeAttribute('TheAction', button.value);

        return true;
    },

    /*
        Method: SubmitForm
            Submit a form.

        Parameters:
            form - (object) The form object.

        Returns:
            (boolean) This method will always return false.
    */
    SubmitForm: function(form) {
        form = $(form);

        // Hide the alert error box
        $('AlertMessage').hide();

        // Show the loading image
        DLSupportJS.ShowLoadingImage({
            finish: function(form) {
                // Get the parameters
                var parameters = form.serialize(true);

                // Set the action if the form has it
                if(form.readAttribute('TheAction')) {
                    parameters.the_action = form.readAttribute('TheAction');
                }

                // Make the request
                new Ajax.Request(form.action, {
                    parameters: parameters,
                    onSuccess: DLSupportJS.CleanAdmin.ServerResponse
                });
            }.curry(form)
        });

        return false;
    },

    /*
        Method: UpdatePage
            Update a page.

        Parameters:
            content - (string) The HTML of the page.
    */
    UpdatePage: function(content) {
        // Get the page object
        var page = $('Data');

        // Update the content of the page surrounded by a span
        page.update('<span>'+content+'</span>');
    }
};