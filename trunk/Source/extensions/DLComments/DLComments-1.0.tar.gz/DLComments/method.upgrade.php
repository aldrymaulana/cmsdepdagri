<?php
if(!($this instanceof DLComments)) { exit; }

// Whether or not the upgrade has failed
$failed_upgrade = FALSE;

// Counter of upgrade made
$upgrade_counter = 0;

// Try to upgrade the module
switch($oldversion) {
    case '0.1':
        // Check dependencies
        if(DLSupport::CompareVersions('DLSupport', '1.1', $failed_upgrade)) {
            break;
        }
    case '0.2':
        // Check dependencies
        if(!DLSupport::CompareVersions('DLSupport', '2.0RC2', $failed_upgrade) &&
           !DLSupport::CompareVersions('CMSMailer', '1.73.14', $failed_upgrade)) {
            $this->Upgrade0();
            ++$upgrade_counter;
        } else {
            break;
        }
    case '1.0RC1':
        if(!DLSupport::CompareVersions('DLSupport', '2.0RC3', $failed_upgrade)) {
            $this->Upgrade1();
            ++$upgrade_counter;
        } else {
            $this->Degrade(0, $upgrade_counter);
            break;
        }
    case '1.0RC2':
        if(!DLSupport::CompareVersions('DLSupport', '2.0', $failed_upgrade)) {
            $this->Upgrade2();
            ++$upgrade_counter;
        } else {
            $this->Degrade1(0, $upgrade_counter);
            break;
        }
    case '1.0':
        break;
}

// If upgrade failed, let user know
if($failed_upgrade) {
    redirect('listmodules.php?action=missingdeps&module=DLComments&'.CMS_SECURE_PARAM_NAME.'='.$_SESSION[CMS_USER_KEY]);
    exit;
}
?>