<?php
if (!cmsms()) exit;
return $this->WYSIWYGTextarea('','','','','','', $params);

?>