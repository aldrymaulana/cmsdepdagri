<?php
/*
    Class: DLForm
        Provides a framework for management of forms.
*/
class DLForm {
    /*
        Group: Constants

        Constants: Fields
            InputButton - (string) Represents an Input Button field.
            InputCheckbox - (string) Represents an Input Checkbox field.
            InputCheckboxGroup - (string) Represents an Input Checkbox field
                that is part of a group.
            InputFile - (string) Represents an Input File field.
            InputHidden - (string) Represents an Input Hidden field.
            InputPassword - (string) Represents an Input Password field.
            InputRadio - (string) Represents an Input Radio field.
            InputRadioGroup - (string) Represents an Input Radio field that is
                part of a group.
            InputReset - (string) Represents an Input Reset field.
            InputSubmit - (string) Represents an Input Submit field.
            InputText - (string) Represents an Input Text field.
            Option - (string) Represents an Option field.
            Select - (string) Represents a Select field.
            Textarea - (string) Represents a Textarea field.
    */
    const InputButton = 'input_button';
    const InputCheckbox = 'input_checkbox';
    const InputCheckboxGroup = 'input_checkbox_group';
    const InputFile = 'input_file';
    const InputHidden = 'input_hidden';
    const InputPassword = 'input_password';
    const InputRadio = 'input_radio';
    const InputRadioGroup = 'input_radio_group';
    const InputReset = 'input_reset';
    const InputSubmit = 'input_submit';
    const InputText = 'input_text';
    const Option = 'option';
    const Select = 'select';
    const Textarea = 'textarea';

    /*
        Constants: Validation
            ValidateCustom - (int) Using a user defined function.
            ValidateEmail - (int) An e-mail address.
            ValidateRequired - (int) Non-empty string.
    */
    const ValidateCustom = 102;
    const ValidateEmail = 100;
    const ValidateRequired = 101;

    /*
        Group: Private Data

        Array: $fields
            (array) An array containing all of the form fields.
    */
    private $fields;

    /*
        Boolean: $hasUpload
            (boolean) Specifies whether or not there is an upload field.
    */
    private $hasUpload;

    /*
        Group: Class Construction

        Constructor: __construct
            Create a new instance of DLForm.

        Returns:
            (DLForm) An instance of DLForm.
    */
    public function __construct() {
        $this->fields    = array();
        $this->hasUpload = FALSE;
    }

    /*
        Group: Data Retrieval

        Method: GetAttributes
            Retrieve a string representation of the attributes for the given
            field.

            Note that this will not return the 'text' or 'value' attribute. Use
            the method <GetText> and <GetValue> for that. The attribute
            'selected' is also omitted from this and is retrieved via the method
            <GetValue> as well.

        Parameters:
            $field - (array) An associative array that contains the field
                information.

        Returns:
            (string) All of the attributes for the given field.
    */
    private function GetAttributes($field) {
        // If the data is for the field InputCheckboxGroup or InputRadioGroup,
        // just return an empty string
        switch($field['type']) {
            case DLForm::InputCheckboxGroup:
            case DLForm::InputRadioGroup:
                 return '';
        }

        // Create the string
        $result = '';
        foreach($field['attributes'] as $attribute => $value) {
            switch($attribute) {
                case 'checked': case 'selected': case 'text': case 'value':
                    break;
                default:
                    $result .= sprintf('%s="%s" ', $attribute, htmlspecialchars($value));
            }
        }

        return $result;
    }

    /*
        Method: GetText
            Retrieve the text for the given field.

            By default, if the attribute 'text' exist for the given field, it is
            returned, otherwise, the value of the attribute 'value' will be used
            instead. If 'value' is also empty, then use the 'name' of the field,
            capitalizing the first letter.

        Parameters:
            $field - (array) The field in which the text should be retrieved
                for.

        Returns:
            (string) The text for the given field.
    */
    private function GetText($field) {
        // Get the text from the attributes
        $result = $field['attributes']['text'];

        // Make sure we have a non-empty string, otherwise, get the value
        if(empty($result)) {
            $result = $this->GetValue($field, array('value_only' => TRUE));
            $result = $result['value'];
        }

        // If we still have a empty string, get the name
        if(empty($result)) {
            $result = ucfirst($field['name']);
        }

        return $result;
    }

    /*
        Method: GetValue
            Retrieve the value for the given field.

        Parameters:
            $field - (array) The field in which the value should be retrieved
                for.
            $options - (array) Optional and defaults an empty array. This
                specifies configurations for this method.

            The structure of the *$options* parameter, if given, should look
            like the following:
            (code)
            array(
                value_only => {
                    (boolean) If set to TRUE, then only the value will be
                    returned, otherwise, the value will be wrapped around by the
                    value attribute. Defaults to FALSE.
                }
            )
            (end)

        Returns:
            (array) The returned array will look similar to:
            (code)
            array(
                'is_post' => {whether or not the value is from POST},
                'value' => {the actual value iteself}
            )
            (end)
    */
    private function GetValue($field, $options = array()) {
        // Merge default options with given options
        $options = array_merge(array('value_only' => FALSE), $options);

        // Depending on the field type, process appropriately
        $use_post = $field['options']['use_post'];
        switch($field['type']) {
            case DLForm::InputCheckbox:
            case DLForm::InputRadio:
                $result['is_post'] = FALSE;
                $result['value']   = $field['attributes']['value'];

                // See if the value is the same as the POST
                if($use_post && isset($_POST[$field['name']])) {
                    $result['is_post'] =
                        $result['value'] == $_POST[$field['name']];
                }
                break;
            case DLForm::InputButton:
            case DLForm::InputFile:
            case DLForm::InputHidden:
            case DLForm::InputPassword:
            case DLForm::InputReset:
            case DLForm::InputSubmit:
            case DLForm::Option:
                // These can never use post data to have its value overwritten
                $result['is_post'] = FALSE;
                $result['value']   = $field['attributes']['value'];
                break;
            case DLForm::InputCheckboxGroup:
            case DLForm::InputRadioGroup:
            case DLForm::InputText:
            case DLForm::Select:
                // These could read data from post
                // See if we should be using the post value and it exist
                if($use_post && isset($_POST[$field['name']])) {
                    $result['is_post'] = TRUE;
                    $result['value']   = $_POST[$field['name']];
                } else {
                    $result['is_post'] = FALSE;
                    $result['value']   = $field['attributes']['value'];
                }
                break;
            case DLForm::Textarea:
                // These can read from post but should be html entified
                if($use_post && isset($_POST[$field['name']])) {
                    $result['is_post'] = TRUE;
                    $result['value']   = $_POST[$field['name']];
                } else {
                    $result['is_post'] = FALSE;
                    $result['value']   = $field['attributes']['value'];
                }

                $result['value'] = htmlentities($result['value']);
                break;
        }

        // Return the value only if it is requested and it isn't a TEXTAREA
        if(!$options['value_only'] && ($field['type'] !== DLForm::Textarea)) {
            $result['value'] = sprintf('value="%s" ', htmlspecialchars($result['value']));
        }

        return $result;
    }

    /*
        Group: HTML Retrieval

        Method: GetCleanField
            Retrieve the HTML for a certain field type using the provided
            information.

        Parameters:
            $name - (string) The name of the form field.
            $type - (string) The type of the field.
            $options - (array) An associative array containing various options
                used by this method. Defaults to an empty array.

            The structure for the *$options* parameter, if it is given, should
            look like the following:
            (code)
            array(
                'attributes' => {
                    (array) An associative array containing any other attributes
                    to be set for the field. The structure of this array should
                    look like the following:

                    array(
                        {attribute's name} => {attribute's value},
                        ...
                    )

                    Defaults to an empty array.
                },
                'id' => {
                    (string) The identifier for the field. Defaults to an
                    randomly generated string.
                },
                'options' => {
                    (array) An associative array containing values for all
                    options field if the given $type is DLForm::Select. The
                    structure of this array should look like the following:

                    array(
                        {option's value} => {option's text},
                        ...
                    )
                },
                'value' => {
                    (mixed) The value that should be the default value for the
                    field. If the given $type is DLForm::Select, this can be
                    an array containing all values that should be pre-selected.
                    Defaults to an empty string.
                }
            )
            (end)
    */
    public function GetCleanField($name, $type, $options = array()) {
        // Get the options
        $options = array_merge(array(
            'attributes'    => array(),
            'id'            => uniqid(),
            'options'       => array(),
            'value'         => ''
        ), $options);

        // Get an instance of DLSupport
        $DLS = DLSupport::Singleton();

        // Get the templates
        $tpt1 = 'DLForm.field.'.$type.'.tpl';
        $tpt2 = '%s="%s" ';

        // Data to be passed to Smarty
        $DLForm = array(
            'attributes'    => '',
            'children'      => '',
            'id'            => $options['id'],
            'name'          => $name,
            'value'         => ''
        );

        // Process differently depending on type of field.
        switch($type) {
            case DLForm::InputButton:
            case DLForm::InputCheckbox:
            case DLForm::InputFile:
            case DLForm::InputHidden:
            case DLForm::InputPassword:
            case DLForm::InputRadio:
            case DLForm::InputReset:
            case DLForm::InputSubmit:
            case DLForm::InputText:
                // Set the value
                $DLForm['attributes'] = sprintf(
                    $tpt2, 'value', htmlentities($options['value'])
                );
                break;
            case DLForm::Select:
                // Convert the selected value to an array if it isn't
                if(!is_array($options['value'])) {
                    $options['value'] = array($options['value']);
                }

                // Build the OPTION elements
                foreach($options['options'] as $option_value => $option_text) {
                    // Set the value
                    $attributes = sprintf(
                        $tpt2, 'value', htmlentities($option_value)
                    );

                    // Should it be selected?
                    if(in_array($option_value, $options['value'])) {
                        $attributes .= sprintf($tpt2, 'selected', 'selected');
                    }

                    // Set data to Smarty
                    $DLS->smarty->assign('DLForm', array(
                        'attributes'    => $attributes,
                        'id'            => uniqid(),
                        'text'          => $option_text
                    ));

                    // Process and store result
                    $DLForm['children'] .= $DLS->ProcessTemplate('DLForm.field.option.tpl');
                }
                break;
            case DLForm::Textarea:
                // Set the value
                $DLForm['value'] = htmlentities($options['value']);
                break;
        }

        // Set the attributes
        foreach($options['attributes'] as $key => $value) {
            $DLForm['attributes'] .= sprintf($tpt2, $key, $value);
        }

        // Set data to Smarty
        $DLS->smarty->assign('DLForm', $DLForm);

        // Process and return result
        return $DLS->ProcessTemplate($tpt1);
    }

    /*
        Method: GetField
            Retrieve the HTML for the given field name.

        Parameters:
            $name - (string) The name of the form field.
            $options - (array) Optional and defaults to an empty array. This
                specifies configurations for this method.

            The structure of the *$options* parameter, if given, should look
            like the following:
            (code)
            array(
                label => {
                    (boolean) Whether or not a label tag should be included with
                    the resulting HTML. Defaults to TRUE.
                }
            )
            (end)

        Returns:
            (string) The HTML for the requested field.
    */
    public function GetField($name, $options = array()) {
        // Merge default options with given options
        $options = array_merge(array('label' => TRUE), $options);

        // Get an instance of DLSupport
        $DLS = DLSupport::Singleton();

        // Get the field
        $field = $this->fields[$name];

        // Smarty Data
        $DLForm = array();

        // Template
        $tpt = 'DLForm.field.'.$field['type'].'.tpl';

        // Depending on the field type, process appropriately
        $result = '';
        switch($field['type']) {
            case DLForm::InputCheckbox:
            case DLForm::InputRadio:
                $value = $this->GetValue($field);

                // See if post data match up
                if($value['is_post'] || (!$value['is_post'] && !empty($field['attributes']['checked']))) {
                    $attribute = sprintf('checked="%s" ', $field['attributes']['checked']);
                }
            case DLForm::InputButton:
            case DLForm::InputFile:
            case DLForm::InputHidden:
            case DLForm::InputPassword:
            case DLForm::InputReset:
            case DLForm::InputSubmit:
            case DLForm::InputText:
                // Make sure attribute is a string
                if(!is_string($attribute)) { $attribute = ''; }

                // Set some data
                $value      = $this->GetValue($field);
                $attribute .= $this->GetAttributes($field).$value['value'];

                // Set Smarty Data
                $DLForm['id']         = empty($field['attributes']['id']) ? uniqid('DLForm_') : $field['attributes']['id'];
                $DLForm['name']       = $name;
                $DLForm['text']       = $this->GetText($field);
                $DLForm['attributes'] = $attribute;
                $DLS->smarty->assign('DLForm', $DLForm);

                // Process
                $show_label = $options['label'] &&
                              !in_array($field['type'], array(
                                DLForm::InputHidden, DLForm::InputButton,
                                DLForm::InputReset, DLForm::InputSubmit
                              ));
                if($show_label) {
                    $result = $DLS->ProcessTemplate('DLForm.label.tpl');
                }
                $result .= $DLS->ProcessTemplate($tpt);

                break;
            case DLForm::InputCheckboxGroup:
                // See if we have any post data we want to use
                $parentValue = $this->GetValue($field, array('value_only' => TRUE));

                // First get the HTML for the children
                foreach($field['children'] as $child) {
                    // Get some data
                    $attributes = $this->GetAttributes($child);
                    $text       = $this->GetText($child);
                    $value      = $this->GetValue($child, array('value_only' => TRUE));

                    // If we have post data & the data match
                    if($parentValue['is_post'] && in_array($value['value'], $parentValue['value'])) {
                        $checked = 'checked="checked" ';
                    } elseif(!$parentValue['is_post'] && $child['attributes']['checked']) {
                        $checked = sprintf('checked="%s" ', $child['attributes']['checked']);
                    } else { $checked = ''; }

                    // Set Smarty Data
                    $value = $this->GetValue($child);
                    $DLForm['id']         = empty($field['attributes']['id']) ? uniqid('DLForm_') : $field['attributes']['id'];
                    $DLForm['name']       = $name.'[]';
                    $DLForm['text']       = $text;
                    $DLForm['attributes'] = $attributes.$checked.$value['value'];
                    $DLS->smarty->assign('DLForm', $DLForm);

                    // Process
                    if($options['label']) {
                        $result .= $DLS->ProcessTemplate('DLForm.label.tpl');
                    }
                    $result .= $DLS->ProcessTemplate('DLForm.field.input_checkbox.tpl');
                }

                break;
            case DLForm::InputRadioGroup:
                // See if we have any post data we want to use
                $parentValue = $this->GetValue($field, array('value_only' => TRUE));

                // First get the HTML for the children
                foreach($field['children'] as $child) {
                    // Get some data
                    $attributes = $this->GetAttributes($child);
                    $text       = $this->GetText($child);
                    $value      = $this->GetValue($child, array('value_only' => TRUE));

                    // If we have post data
                    if($parentValue['is_post'] && ($value['value'] == $parentValue['value'])) {
                        $checked = 'checked="checked" ';
                    } elseif(!$parentValue['is_post'] && $child['attributes']['checked']) {
                        $checked = sprintf('checked="%s" ', $child['attributes']['checked']);
                    } else { $checked = ''; }

                    // Set some data
                    $value = $this->GetValue($child);
                    $DLForm['id']         = empty($field['attributes']['id']) ? uniqid('DLForm_') : $field['attributes']['id'];
                    $DLForm['name']       = $name;
                    $DLForm['text']       = $text;
                    $DLForm['attributes'] = $attributes.$checked.$value['value'];
                    $DLS->smarty->assign('DLForm', $DLForm);

                    // Process
                    if($options['label']) {
                        $result .= $DLS->ProcessTemplate('DLForm.label.tpl');
                    }
                    $result .= $DLS->ProcessTemplate('DLForm.field.input_radio.tpl');
                }

                break;
            case DLForm::Select:
                // See if we have any post data we want to use
                $parentValue = $this->GetValue($field, array('value_only' => TRUE));

                // First get the HTML for the children
                $children = '';
                foreach($field['children'] as $child) {
                    // Get some data
                    $attributes = $this->GetAttributes($child);
                    $text       = $this->GetText($child);
                    $value      = $this->GetValue($child, array('value_only' => TRUE));

                    // If we have post data
                    if($parentValue['is_post'] && is_string($parentValue['value']) && ($value['value'] == $parentValue['value'])) {
                        // And there is only one selected value
                        $selected = 'selected="selected" ';
                    } elseif($parentValue['is_post'] && is_array($parentValue['value']) && in_array($value['value'], $parentValue['value'])) {
                        // And there are multiple selections
                        $selected = 'selected="selected" ';
                    } elseif(!$parentValue['is_post'] && !empty($child['attributes']['selected'])) {
                        $selected = sprintf('selected="%s" ', $child['attributes']['selected']);
                    } else { $selected = ''; }

                    // Set Smarty Data
                    $value = $this->GetValue($child);
                    $DLForm['id']         = empty($field['attributes']['id']) ? uniqid('DLForm_') : $field['attributes']['id'];
                    $DLForm['text']       = $text;
                    $DLForm['attributes'] = $attributes.$selected.$value['value'];
                    $DLS->smarty->assign('DLForm', $DLForm);

                    // Process
                    $children .= $DLS->ProcessTemplate('DLForm.field.option.tpl');
                }

                // Could this SELECT field have more than one value?
                if($field['attributes']['size'] > 1) { $name .= '[]'; }

                // Set Smarty Data
                $DLForm['id']         = empty($field['attributes']['id']) ? uniqid('DLForm_') : $field['attributes']['id'];
                $DLForm['name']       = $name;
                $DLForm['attributes'] = $this->GetAttributes($field);
                $DLForm['text']       = $this->GetText($field);
                $DLForm['children']   = $children;
                $DLS->smarty->assign('DLForm', $DLForm);

                // Process
                if($options['label']) {
                    $result = $DLS->ProcessTemplate('DLForm.label.tpl');
                }
                $result .= $DLS->ProcessTemplate($tpt);

                break;
            case DLForm::Textarea:
                // Set some data
                $value = $this->GetValue($field);
                $DLForm['id']         = empty($field['attributes']['id']) ? uniqid('DLForm_') : $field['attributes']['id'];
                $DLForm['name']       = $name;
                $DLForm['attributes'] = $this->GetAttributes($field);
                $DLForm['text']       = $this->GetText($field);
                $DLForm['value']      = $value['value'];
                $DLS->smarty->assign('DLForm', $DLForm);

                // Process
                if($options['label']) {
                    $result = $DLS->ProcessTemplate('DLForm.label.tpl');
                }
                $result .= $DLS->ProcessTemplate($tpt);

                break;
        }

        return $result;
    }

    /*
        Method: GetFooter
            Retrieve the HTML for the footer of the form.

        Returns:
            (string) The HTML for the footer.
    */
    public function GetFooter() {
        // Get an instance of DLSupport
        $DLS = DLSupport::Singleton();

        // Process
        $result = $DLS->ProcessTemplate('DLForm.footer.tpl');

        return $result;
    }

    /*
        Method: GetHeader
            Retrieve the HTML for the header of the form.

        Parameters:
            $action - (string) The action URL for the form.
            $options - (array) Optional and defaults to an empty array. This
                specifies configurations for this method.

            The structure of the *$options* parameter, if given, should look
            like the following:
            (code)
            array(
                class => {
                    (string) The class name for the FORM tag. Defauls to
                    "DLForm".
                },
                method => {
                    (string) The method to submit the form. Defaults to "POST".
                }
            )
            (end)

        Returns:
            (string) The HTML for the header.
    */
    public function GetHeader($action, $options = array()) {
        // Merge default options with given options
        $options = array_merge(array('class' => 'DLForm', 'method' => 'post'), $options);

        // Get an instance of DLSupport
        $DLS = DLSupport::Singleton();

        // Smarty Data
        $DLForm = array('action' => $action, 'class' => $options['class'], 'method' => $options['method']);

        // See if this form has an upload field
        if($this->hasUpload) {
            $upload = sprintf(
                '<input type="hidden" name="%s" value="%s" />',
                'UPLOAD_IDENTIFIER', uniqid('DLForm_')
            );
        } else {
            $upload = '';
        }
        $DLForm['upload'] = $upload;

        // See if this form has been submitted
        if(DLSupport::SanitizeString('DLForm_submitted', INPUT_POST)) {
            $submitted = 'true';
        } else {
            $submitted = 'false';
        }
        $DLForm['submitted'] = $submitted;

        // Set other attributes
        $DLForm['attributes'] = '';
        if(isset($options['attributes']) && is_array($options['attributes'])) {
            $attributes = array();
            foreach($options['attributes'] as $key => $value) {
                $attributes[] = $key.'="'.$value.'"';
            }

            $DLForm['attributes'] = implode(' ', $attributes);
        }

        // Process
        $DLS->smarty->assign('DLForm', $DLForm);
        $result = $DLS->ProcessTemplate('DLForm.header.tpl');

        return $result;
    }

    /*
        Group: Miscellaneous

        Method: AddField
            Add a form field.

        Parameters:
            $name - (string) The name of the field.
            $type - (string) The type of the form fields. Use the provided
                constants for this parameters.
            $attributes - (array) Optional and defaults to an empty array. Any
                extra attributes for the field. The key of the array will be the
                attribute and its value is the attribute's value. Also note that
                the value will be surrounded by double quotes so be sure to add
                slashes appropriately. For all OPTION fields, the attribute of
                'text' will be the text between the opening and closing option
                tags if it is given, otherwise 'value' will be used. For all
                TEXTAREA fields, the attribute 'value' will be the text between
                the opening and closing textarea tags and won't be surrounded by
                double quotes. It will also be passed through the function
                htmlentities. All other type of fields, if the attribute 'text'
                isn't given, then 'value' will be used as part of the label.
                Note that a label will not be included for a OPTION or SELECT
                field.
            $options - (array) Optional and defaults to an empty array. This
                specifies configurations for this method.

            The structure of the *$options* parameter, if given, should look
            like the following:
            (code)
            array(
                custom => {
                    (callback) This is only used be the option *validate* is set
                    to DLForm::ValidateCustom. The function to be used to
                    validate the field. Defaults to an empty string.
                },
                use_post => {
                    (boolean) When this is set to TRUE, if there is a POST
                    variable with the same name as the given "$name", then the
                    value of that POST variable will be used as the value.
                },
                validate => {
                    (int) Specify whether or not the given field should be
                    validated. Defaults to 0.
                }
            )
            (end)

        Returns:
            (boolean) Returns TRUE if successful, FALSE, otherwise.
    */
    public function AddField($name, $type, $attributes = array(), $options = array()) {
        // Merge default options with given options
        $options = array_merge(
            array('custom' => '', 'use_post' => TRUE, 'validate' => 0),
            $options
        );

        // Depending on the type, process appropriately
        switch($type) {
            case DLForm::Option:
                // Make sure that a select field exist, if not create it
                if(!is_array($this->fields[$name]) || ($this->fields[$name]['type'] !== DLForm::Select)) {
                    $this->AddField($name, DLForm::Select, array(), $options);
                }

                // Get all of the option fields for the given select
                if(is_array($this->fields[$name]['children'])) {
                    $children = $this->fields[$name]['children'];
                } else {
                    $children = array();
                }

                // Add the field
                $this->fields[$name]['children'][] = array(
                    'name'       => $name,       'type'    => $type,
                    'attributes' => $attributes, 'options' => $options
                );
                break;
            case DLForm::InputCheckboxGroup:
                // Add the field
                $this->fields[$name]['name']    = $name;
                $this->fields[$name]['type']    = $type;
                $this->fields[$name]['options'] = $options;
                $this->fields[$name]['children'][] = array(
                    'name'       => $name,       'type'    => DLForm::InputCheckbox,
                    'attributes' => $attributes, 'options' => $options
                );
                break;
            case DLForm::InputRadioGroup:
                // Add the field
                $this->fields[$name]['name']    = $name;
                $this->fields[$name]['type']    = $type;
                $this->fields[$name]['options'] = $options;
                $this->fields[$name]['children'][] = array(
                    'name'       => $name,       'type'    => DLForm::InputRadio,
                    'attributes' => $attributes, 'options' => $options
                );
                break;
            case DLForm::InputFile:
                $this->hasUpload = TRUE;
            case DLForm::InputButton:
            case DLForm::InputCheckbox:
            case DLForm::InputHidden:
            case DLForm::InputPassword:
            case DLForm::InputRadio:
            case DLForm::InputReset:
            case DLForm::InputSubmit:
            case DLForm::InputText:
            case DLForm::Select:
            case DLForm::Textarea:
                // Add the field
                $this->fields[$name] = array(
                    'name'       => $name,       'type'    => $type,
                    'attributes' => $attributes, 'options' => $options
                );
                break;
            default:
                return FALSE;
        }

        return TRUE;
    }

    /*
        Method: Validate
            Validate this form.

        Returns:
            (mixed) Returns an array of all the fields that fails validation. If
            no errors were found, then this will return FALSE.
    */
    public function Validate() {
        // Only validate if the form has been submitted
        if(DLSupport::SanitizeString('DLForm_submitted', INPUT_POST)) {
            return array();
        }

        // Validate the fields
        $result = array();
        foreach($this->fields as $field) {
            // Get the post data
            $post = filter_input(INPUT_POST, $field['name']);

            // Depending on the type of validation, process appropriately
            switch($field['options']['validate']) {
                case DLForm::ValidateCustom:
                    // Call the user function
                    if(!call_user_func($field['options']['custom'],
                                       $field['name'], $post)) {
                        $result[] = $field['name'];
                    }
                    break;
                case DLForm::ValidateRequired:
                    // Call the user function
                    if(empty($post)) { $result[] = $field['name']; }
                    break;
            }
        }

        // If the array is empty, then no errors were found
        if(empty($result)) { $result = FALSE; }

        return $result;
    }
}
?>