<?php
if(!($this instanceof DLComments)) { exit; }

// Result array to be sent back
$response = array( 'success' => FALSE, 'hide_html_area' => FALSE, 'message' => '', 'html' => '');

// Get user inputs
$missing_group      = $params['missing_group'];
$missing_required   = $params['missing_required'];
$success_add        = $params['success_add'];
$show_icon          = DLSupport::SanitizeString($params['show_icon']);
$icon_success       = filter_var($params['icon_success'], FILTER_SANITIZE_URL);
$icon_warning       = filter_var($params['icon_warning'], FILTER_SANITIZE_URL);
$icon_error         = filter_var($params['icon_error'], FILTER_SANITIZE_URL);
$auto_approve       = $params['auto_approve'];
$use_captcha        = $params['use_captcha'];
$send_email         = $params['send_email'];
$email_address      = filter_var($params['email_address'], FILTER_SANITIZE_EMAIL);

// Validation
$error_message = '';
if(empty($missing_group)) {
    $error_message = $this->Lang('failure_missing_group_frontend');
}
if(empty($missing_required)) {
    $error_message = ' '.$this->Lang('failure_missing_required_frontend');
}
if(empty($success_add)) {
    $error_message = ' '.$this->Lang('failure_success_add_frontend');
}
if(!in_array($show_icon, array('Yes', 'No'))) {
    $error_message = ' '.$this->Lang('failure_show_icon_frontend');
}
if(!in_array($auto_approve, array('Yes', 'No'))) {
    $error_message = ' '.$this->Lang('failure_auto_approve_frontend');
}
if(!in_array($use_captcha, array('Yes', 'No'))) {
    $error_message = ' '.$this->Lang('failure_use_captcha_frontend');
}
if(!in_array($send_email, array('Yes', 'No'))) {
    $error_message = ' '.$this->Lang('failure_send_email_frontend');
}
if(($send_email == 'Yes') && empty($email_address)) {
    $error_message = ' '.$this->Lang('failure_email_address_frontend');
}

if(!empty($error_message)) {
    $response['message'] = $this->GetIcon('remove', 'Error Message: ').$error_message;
    DLSupport::CleanExit(json_encode($response));
}

// Update the settings
$this->SetPreference('missing_group', $missing_group);
$this->SetPreference('missing_required', $missing_required);
$this->SetPreference('success_add', $success_add);
$this->SetPreference('show_icon', $show_icon);
$this->SetPreference('icon_success', $icon_success);
$this->SetPreference('icon_warning', $icon_warning);
$this->SetPreference('icon_error', $icon_error);
$this->SetPreference('auto_approve', $auto_approve);
$this->SetPreference('use_captcha', $use_captcha);
$this->SetPreference('send_email', $send_email);
$this->SetPreference('email_address', $email_address);

// If we made it here, it was a success
$response['success'] = TRUE;
$response['message'] = $this->GetIcon('accept', $this->Lang('success_message').': ').$this->Lang('success_update_settings');
$response['html'] = $this->GetSettingsHTML($id, $returnid, $params);

DLSupport::CleanExit(json_encode($response));
?>