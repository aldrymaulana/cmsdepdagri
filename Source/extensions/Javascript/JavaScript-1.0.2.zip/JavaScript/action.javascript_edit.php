<?php

$query = "SELECT * FROM {$this->table_base}javascript WHERE javascript_id = ?;";
$rsjavascript = $this->db->Execute($query, array($params['javascript_id']));

echo $this->CreateFormStart($id, 'javascript_save', $returnid, 'post', '', false, '', array('save_type' => 'edit', 'javascript_id' => $params['javascript_id']));

echo "<table>";

echo "<tr>";
echo "<td valign=\"top\">";
echo $this->CreateLabelForInput($id, 'javascript_name', $this->Lang('name'));
echo "</td>";
echo "<td valign=\"top\">";
echo $this->CreateInputText($id, 'javascript_name', $rsjavascript->fields['javascript_name'], '10', '100');
echo "</td>";
echo "</tr>";

echo "<tr>";
echo "<td valign=\"top\">";
echo $this->CreateLabelForInput($id, 'javascript_content', $this->Lang('content'));
echo "</td>";
echo "<td valign=\"top\">";
echo $this->CreateTextArea(false, $id, $rsjavascript->fields['javascript_content'], 'javascript_content');
echo "</td>";
echo "</tr>";

echo "<tr>";
echo "<td valign=\"top\">";
echo $this->CreateLabelForInput($id, 'javascript_external_include', $this->Lang('external'));
echo "</td>";
echo "<td valign=\"top\">";
echo $this->CreateInputCheckbox($id, 'javascript_external_include', '1', (string)$rsjavascript->fields['javascript_external_include']);
echo "</td>";
echo "</tr>";

echo "<tr>";
echo "<td valign=\"top\">";
echo $this->CreateLabelForInput($id, 'javascript_compress', $this->Lang('minify'));
echo "</td>";
echo "<td valign=\"top\">";
echo $this->CreateInputCheckbox($id, 'javascript_compress', '1', (string)$rsjavascript->fields['javascript_compress']);
echo "</td>";
echo "</tr>";

echo "<tr>";
echo "<td valign=\"top\">";
echo $this->CreateLabelForInput($id, 'javascript_pack', $this->Lang('pack'));
echo "</td>";
echo "<td valign=\"top\">";
echo $this->CreateInputCheckbox($id, 'javascript_pack', '1', (string)$rsjavascript->fields['javascript_pack']);
echo "</td>";
echo "</tr>";

echo "<tr>";
echo "<td valign=\"top\">";
echo $this->CreateLabelForInput($id, 'javascript_global', $this->Lang('global'));
echo "</td>";
echo "<td valign=\"top\">";
echo $this->CreateInputCheckbox($id, 'javascript_global', '1', (string)$rsjavascript->fields['javascript_global']);
echo "</td>";
echo "</tr>";

echo "<tr>";
echo "<td valign=\"top\">";
echo $this->CreateLabelForInput($id, 'javascript_sort_order', $this->Lang('order'));
echo "</td>";
echo "<td valign=\"top\">";
echo $this->CreateInputText($id, 'javascript_sort_order', $rsjavascript->fields['javascript_sort_order']);
echo "</td>";
echo "</tr>";

echo "<tr>";
echo "<td valign=\"top\" colspan=\"2\">";
echo $this->CreateInputSubmit($id, 'javascript_submit', $this->Lang('save_javascript'));
echo "</td>";
echo "</tr>";

echo "</table>";

echo $this->CreateFormEnd();

?>