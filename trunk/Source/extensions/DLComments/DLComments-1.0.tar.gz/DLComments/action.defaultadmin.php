<?php
if(!($this instanceof DLComments)) { exit; }

// Start of JavaScript includes
echo $this->IncludeAdmin();
// End of JavaScript includes

// Start of the tab headers
echo $this->StartTabHeaders();
echo $this->SetTabHeader('approval', $this->Lang('approve_comments'));
echo $this->SetTabHeader('modify', $this->Lang('modify_comments'));
echo $this->SetTabHeader('css', $this->Lang('modify_css'));
echo $this->SetTabHeader('comments', $this->Lang('modify_comments_templates'));
echo $this->SetTabHeader('submission_form', $this->Lang('modify_submission_form_templates'));
echo $this->SetTabHeader('settings', $this->Lang('settings'));
echo $this->EndTabHeaders();
// End of the tab headers

// Start of the tab contents
echo $this->StartTabContent();

    // Start of the approval tab
    echo $this->StartTab('approval');
    echo $this->ShowFilterArea($id, $returnid, $params, 'approval');
    echo $this->ShowListingArea($id, $returnid, $params, 'approval');
    echo $this->EndTab();
    // End of the approval tab

    // Start of the modify tab
    echo $this->StartTab('modify');
    echo $this->ShowFilterArea($id, $returnid, $params, 'modify');
    echo $this->ShowListingArea($id, $returnid, $params, 'modify');
    echo $this->EndTab();
    // End of the modify tab

    // Start of the css tab
    echo $this->StartTab('css');
    echo $this->ShowTemplateArea($id, $returnid, $params, 'css');
    echo $this->EndTab();
    // End of the css tab

    // Start of the comments tab
    echo $this->StartTab('comments');
    echo $this->ShowTemplateArea($id, $returnid, $params, 'comments');
    echo $this->EndTab();
    // End of the comments tab

    // Start of the submission form tab
    echo $this->StartTab('submission_form');
    echo $this->ShowTemplateArea($id, $returnid, $params, 'submission_form');
    echo $this->EndTab();
    // End of the submission form tab

    // Start of the settings tab
    echo $this->StartTab('settings');
    echo $this->ShowSettingsArea($id, $returnid, $params);
    echo $this->EndTab();
    // End of the settings tab

echo $this->EndTabContent();
// End of the tab contents
?>