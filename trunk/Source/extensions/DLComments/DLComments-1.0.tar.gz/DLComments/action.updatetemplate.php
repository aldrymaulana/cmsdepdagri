<?php
if(!($this instanceof DLComments)) { exit; }

// Result array to be sent back
$response = array( 'success' => FALSE, 'hide_html_area' => FALSE, 'message' => '', 'html' => '');

// Get user inputs
$action     = DLSupport::SanitizeString($params['submit']);
$type       = DLSupport::SanitizeString($params['type']);
$old_name   = DLSupport::SanitizeString($params['old_name']);
$name       = DLSupport::SanitizeString($params['name']);
$default    = DLSupport::SanitizeString($params['default']);
$content    = $params['content'];

// Validate user input
if(!in_array($type, array('css', 'comments', 'submission_form'))) {
    $response['message'] = $this->Lang('missing_type');
    DLSupport::CleanExit(json_encode($response));
}

// Get CSS templates information
$templates = explode('|', $this->GetPreference('list_of_'.$type.'_templates'));

// More validation
$error_message = '';
if(!in_array($action, array($this->Lang('add'), $this->Lang('remove'), $this->Lang('save')))) {
    $error_message .= $this->Lang('failure_invalid_action_'.$type);
}
if(empty($name)) {
    $error_message .= ' '.$this->Lang('failure_missing_name_'.$type);
}
if(($action == $this->Lang('add')) && in_array($name, $templates)) {
    $error_message .= ' '.$this->Lang('failure_template_exist_'.$type);
}
if(($action == $this->Lang('remove')) && !in_array($name, $templates)) {
    $error_message .= ' '.$this->Lang('failure_template_nonexist_'.$type);
}
if(($action == $this->Lang('remove')) && (count($templates) < 2)) {
    $error_message .= ' '.$this->Lang('failure_last_template_'.$type);
}
if(($action == $this->Lang('save')) && ($old_name != $name) && in_array($name, $templates)) {
    $error_message .= ' '.$this->Lang('failure_template_exist_'.$type);
}

if(isset($error_message[0])) {
    $response['message'] = $this->GetIcon('remove', $this->Lang('error_message').': ').$error_message;
    DLSupport::CleanExit(json_encode($response));
}

// Process appropriately depending on the action
$full_name = $type.'_'.$name;
switch($action) {
    case $this->Lang('add'):
        // Save template data to database
        $this->SetTemplate($full_name, $content);
        if(!empty($default)) { $this->SetPreference('default_'.$type.'_template', $full_name); }

        // Update $templates array
        $templates[] = $name;
        sort($templates, SORT_STRING);

        // Set the successful message
        $success_message = $this->Lang('success_update_add_'.$type);
        break;
    case $this->Lang('remove'):
        // Remove template from database
        $this->DeleteTemplate($full_name);

        // Update $templates array
        $key = array_search($name, $templates);
        unset($templates[$key]);
        sort($templates, SORT_STRING);

        // If the default template was removed, set first template as default
        if($full_name == $this->GetPreference('default_'.$type.'_template')) {
            $this->SetPreference('default_'.$type.'_template', $type.'_'.$templates[0]);
        }

        // Set the successful message
        $success_message = $this->Lang('success_update_remove_'.$type);
        break;
    case $this->Lang('save'):
        // We do things differently if the template name was changed
        if($old_name == $name) {
            // Save template data to database
            $this->SetTemplate($full_name, $content);
        } else {
            // Remove old template name and set the new content
            $this->DeleteTemplate($type.'_'.$old_name);
            $this->SetTemplate($full_name, $content);

            // Update $templates array
            $key = array_search($old_name, $templates);
            unset($templates[$key]);
            $templates[] = $name;
            sort($templates, SORT_STRING);
        }

        if(!empty($default)) { $this->SetPreference('default_'.$type.'_template', $full_name); }

        // Set the successful message
        $success_message = $this->Lang('success_update_save_'.$type);
        break;
}

// Store list of templates to database
$this->SetPreference('list_of_'.$type.'_templates', implode('|', $templates));

// If we made it here, it was a success
$response['success'] = TRUE;
$response['message'] = $this->GetIcon('accept', $this->Lang('success_message').':').$success_message;

// Get the new template listing
$response['html'] = $this->GetStoredTemplates($id, $returnid, $params, $type);

DLSupport::CleanExit(json_encode($response));
?>