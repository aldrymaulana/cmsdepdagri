<?php
if(!($this instanceof DLComments)) { exit; }

// Make sure the user got the dependencies
$failed_install = !method_exists('DLSupport', 'ValidateDependency') ||
                  !method_exists('DLSupport', 'CompareVersions');
if(!$failed_install) {
    DLSupport::ValidateDependency('DLSupport', '2.0', $failed_install);
    DLSupport::CompareVersions('CMSMailer', '1.73.14', $failed_install);
}
if($failed_install) {
    redirect('listmodules.php?action=missingdeps&module=DLComments&'.CMS_SECURE_PARAM_NAME.'='.$_SESSION[CMS_USER_KEY]);
    exit;
}

// Create Permissions
$this->CreatePermission('DL Suite: Comments', 'DL Suite: Comments - Administration');

// Prepare for the creation of a table in the database
$db =& $this->GetDb();
$dictionary = NewDataDictionary($db);
$fields = '
    `id` I PRIMARY AUTO,
    `posted_date` I NOTNULL DEFAULT "0",
    `approved` I1(1) NOTNULL DEFAULT "0",
    `group` C(100) NOTNULL,
    `user` C(50) NOTNULL,
    `comment` X NOTNULL
';
$table_options = array('mysql' => 'TYPE=MYISAM');

// Create the table
$sql = $dictionary->CreateTableSQL(cms_db_prefix().'module_dlcomments', $fields, $table_options);
$dictionary->ExecuteSQLArray($sql);

// Store default templates
$css = file_get_contents($this->GetModulePath().'/templates/original_css.tpl');
$this->SetTemplate('css_Sample', $css);
$this->SetPreference('default_css_template', 'css_Sample');
$this->SetPreference('list_of_css_templates', 'Sample');

$comments = file_get_contents($this->GetModulePath().'/templates/original_comments.tpl');
$this->SetTemplate('comments_Sample', $comments);
$this->SetPreference('default_comments_template', 'comments_Sample');
$this->SetPreference('list_of_comments_templates', 'Sample');

$submission_form = file_get_contents($this->GetModulePath().'/templates/original_submission_form.tpl');
$this->SetTemplate('submission_form_Sample', $submission_form);
$this->SetPreference('default_submission_form_template', 'submission_form_Sample');
$this->SetPreference('list_of_submission_form_templates', 'Sample');

// Set default preferences
$this->SetPreference('missing_group', 'Your submission was not successful because a comment group was not specified.');
$this->SetPreference('missing_required', 'Your submission was not successful because not all of the required fields were filled out.');
$this->SetPreference('success_add', 'Your submission was a success. Once it is approved, it will start to appear on the web site.');
$this->SetPreference('show_icon', 'Yes');
$this->SetPreference('icon_success', '');
$this->SetPreference('icon_warning', '');
$this->SetPreference('icon_error', '');
$this->SetPreference('auto_approve', 'No');
$this->SetPreference('send_email', 'No');
$this->SetPreference('email_address', '');
$this->SetPreference('use_captcha', 'Yes');

// Add entry to admin log
$this->Audit(0, $this->GetFriendlyName(), 'Installed DL Suite: Comments');
?>