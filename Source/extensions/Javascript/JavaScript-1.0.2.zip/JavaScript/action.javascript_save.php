<?php

$javascript_compress = isset($params['javascript_compress']);
$javascript_external_include = isset($params['javascript_external_include']);
$javascript_global = isset($params['javascript_global']);
$javascript_pack = isset($params['javascript_pack']);

switch($params['save_type']) {
	case 'new':
		$query = "INSERT INTO {$this->table_base}javascript VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, current_timestamp(), current_timestamp());";
		$alias_count = 1;
		
		$alias = munge_string_to_url(strtolower($params['javascript_name']));
		while ($this->db->Execute("SELECT * FROM {$this->table_base}javascript WHERE javascript_alias = ?", array($alias))->RecordCount()) {
			$alias_count++;
			$alias = munge_string_to_url(strtolower($params['javascript_name']) . ' ' . $alias_count);
		}
		$this->db->Execute($query, array($this->db->GenId($this->table_base . 'javascript_seq'), $params['javascript_name'], $alias, $params['javascript_content'], $params['javascript_sort_order'], $javascript_compress, $javascript_external_include, $javascript_global, $javascript_pack));
		$redir_params = array('tab_message'=> 'created_javascript', 'active_tab' => 'javascript');
		break;
	case 'edit':
		$query = "UPDATE {$this->table_base}javascript SET javascript_name = ?, javascript_content = ?, javascript_sort_order = ?, javascript_compress = ?, javascript_external_include = ?, javascript_global = ?, javascript_pack = ? WHERE javascript_id = ?;";
		$this->db->Execute($query, array($params['javascript_name'], $params['javascript_content'], $params['javascript_sort_order'], $javascript_compress, $javascript_external_include, $javascript_global, $javascript_pack, $params['javascript_id']));
		$redir_params = array('tab_message'=> 'saved_javascript', 'active_tab' => 'javascript');
		break;
	default:
		break;
}

$this->Redirect($id, 'defaultadmin', '', $redir_params);

?>