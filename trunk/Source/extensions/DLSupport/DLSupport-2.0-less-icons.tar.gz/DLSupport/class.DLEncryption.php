<?php // No sense in declaring this class if it is already declared
if(!class_exists('DLEncryption')) {

/*
    Class: DLEncryption
        Parent class of all encryption algorithms.
*/
abstract class DLEncryption {
    /*
        Group: Private Static Data

        Array: $instances
            (array) An array containing instances of subclasses.
    */
    private static $instances = array();

    /*
        Group: Public Static Data

        Array: $algorithms
            (array) The available encryption algorithms.

            The available algorithms are:
                One - AzDGCrypt.
                Two - MD5 64.
                Three - AES.
    */
    public static $algorithms = array('One', 'Two', 'Three');

    /*
        Group: Class Construction

        Constructor: __construct
            Create a new instance of DLEncryption. Use <ObjectPool> to get the
            necessary instances is recommended.

        Returns:
            (DLEncryption) An instance of DLEncryption.
    */
    protected function __construct() {}

    /*
        Method: ObjectPool
            Retrieve an instance of the request algorithm.

        Parameters:
            $algorithm - (string) The algorithm instance to retrieve.

        Returns:
            (DLEncryption) An instance of the selected algorithm, returning NULL
            if the algorithm doesn't exist.
    */
    public static function &ObjectPool($algorithm) {
        // Get the full algorithm class name
        $class = 'DLEncryption_'.$algorithm;

        if(!class_exists($class)) {
            return NULL;
        }

        // Create the algorithm if it doesn't exists
        if(!(DLEncryption::$instances[$class] instanceof $class)) {
            // Create the instance and store it
            DLEncryption::$instances[$class] = new $class();
        }

        return DLEncryption::$instances[$class];
    }

    /*
        Group: Abstract Methods

        Method: Decrypt
            Decrypt the given data using the given key.

        Parameters:
            $key - (string) The key that was used to encrypt the data.
            $data - (string) The data to be decrypted.

        Returns:
            (mixed) The data after it has been decrypted.
    */
    abstract public function Decrypt($key, $data);

    /*
        Method: Encrypt
            Encrypt the given data using the given key.

        Parameters:
            $key - (string) The key to be used to decrypt the data.
            $data - (mixed) The data to be encrypted.

        Returns:
            (string) The data after it has been encrypted.
    */
    abstract public function Encrypt($key, $data);

    /*
        Group: Hashing

        Method: Hash
            Hash the given element using the sha256 algorithm.

        Parameters:
            $data - (string) The data to be hashed.
            $length - (int) Optional and defaults to 0. The requested length of
            the returned hashed string. If this is greater than 0, then the
            returned string will be of this given length, otherwise, it will be
            whatever the result of the hash function.

        Returns:
            (string) The data after it has been hashed.
    */
    protected function Hash($data, $length = 0) {
        // Hash the data
        $result = hash('sha256', $data);

        // If we want the result to be of certain length
        if($length > 0) {
            // Get the current length of the hash
            $current_length = strlen($result);

            // Keep adding to the hash if we don't have enough characters for
            // the requested length
            while($current_length != $length) {
                // If we have enough characters, substr away
                if($length <= $current_length) {
                    $result = substr($result, 0, $length);
                } else {
                    // Add to the hash
                    $result .= hash('sha256', $result);
                }

                // Update the current length
                $current_length = strlen($result);
            }
        }

        return $result;
    }
}

// Include dependents
require_once('DLEncryption'.DIRECTORY_SEPARATOR.'class.DLEncryption_One.php');
require_once('DLEncryption'.DIRECTORY_SEPARATOR.'class.DLEncryption_Two.php');
require_once('DLEncryption'.DIRECTORY_SEPARATOR.'class.DLEncryption_Three.php');

}