Examples

  slider() — get slider object

  slider('value') — return scope of values
  slider('value', 100 ) — set first pointer to 1
  slider('value', 100, 200 ) — set first pointer to 1, second pointer to 2

  slider('prc') — return scope of values in prc
  slider('prc', 10 ) — set first pointer to 10%
  slider('prc', 10, 90 ) — set first pointer to 10%, second pointer to 90%

  slider('calculatedValue') — return value scope from "calculate" function

  slider('skin', "plastic") — set skin to slider



