<?php

$this->OutputJSExternal($params);

?>