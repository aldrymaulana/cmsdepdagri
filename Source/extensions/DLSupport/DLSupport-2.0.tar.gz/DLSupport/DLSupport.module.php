<?php
/*
    Class: DLSupport
        An auxilary class providing functionalities to other modules.

    About: Author
        Duc Tri Le <cmsmadesimple---at---email.tiger-inc.com>

    About: License
        This class is released under the GNU General Public License.

    About: Changelog
        * 2.0 (April 19, 2009): Added the method <UploadPageResponse>.
            Abstract out <DLSupportJS.CleanAdmin.ServerResponse>. Fixed a couple
            of spelling errors. Remove realpath from the method <ModulePath>.
        * 2.0RC4 (January 16, 2008): Separate the Clean Admin into its own
            class. However, the old functions will still work. They will be
            removed by version 3.0. Also, I have changed <DLEncryption_Three> to
            use a different implementation since the previous one is not
            consistently producing appropriate results. This will be the final
            release candidate before version 2.0 is released.
        * 2.0RC3 (December 12, 2008): So much has changed in this update that I
            don't even know where to begin. With that in mind, consider this
            like a completely new version. This version isn't completely
            backwards compatible either but all modules that I developed have
            been upgraded so that it still works.
        * 2.0RC2 (August 15, 2008): [PHP] MD5 given data to Hash function of
            DLEncryption for safe hashing to prevent possible bug with AES
            encryption and decryption. Added the method CompareVersions to
            DLSupport. Give DLForm::GetHeader the ability to include extra
            attributes to the FORM tag. [JavaScript] Updated DLSupport.Form to
            handle a select box with multiple values.
        * 2.0RC1 (July 25, 2008): Huge update including an encryption and
            decryption class, a form class, a tab collection class and more.
        * 1.3 (May 30, 2008): [JavaScript] Added the property
            DLSupport.ErrorLog. Updates were made to the following methods in
            DLSupport: checkboxSelectAllToggle, curry, defaultValues,
            delayFunction, inArray, removeElement, toggleDisplay, and
            windowOnload. The following methods has been added to DLSupport:
            addErrorLog, humanReadable, and newEvent. Updated
            DLSupport.AJAX.monitor.
        * 1.2 (May 23, 2008: [PHP] Updates were made to the following methods:
            GetPageInfo and ListDirectories. The following methods were added:
            GetCSSFromTemplate and moduleInstance.
        * 1.1 (May 9, 2008): [PHP] Deprecated DLSupport->DLSupport_data. Updates
            were made to following methods: __construct, ParseCSS, and Singleton.
            The following methods were added: Captcha, CaptchaRemove,
            CaptchaValidate, CleanExit, ConvertBytes, GetIcon, GetPageInfo,
            IncludeJavaScript, ListDirectories, ListFiles, ModulePath,
            ModuleUrl, NewFormStart, SanitizeString, and ValidateDependency.
            [JavaScript] Added the property DLSupport.ModuleUrl. The following
            methods were updated in DLSupport: curry and windowOnload. The
            following methods were added to DLSupport: checkboxSelectAllToggle,
            cloneArray, combineArray, defaultValues, delayFunction,
            hideLoadingImage, inArray, isArray, isNumeric, propertyNames,
            reverseArray, showLoadingImage, toggleDisplay, toQueryString, and
            uniqueArray. Added the subclass DLSupport.AJAX.
        * 1.0 (April 4, 2008): Make version 1.0RC1 the first stable version. No
            changes to the codebase were made.
        * 1.0RC1 (March 28, 2008): Removed files that are no longer used by this
            module. [JavaScript] Updated DLSupport.windowOnload so that it
            actually runs when the page loads.
        * 0.1 (March 15, 2008): Initial release of module.
        * 0.0 (March 10, 2008): Start of module creation.
*/
class DLSupport extends CMSModule {
    /*
        Group: Private Static Data

        Object: $instance
            (DLSupport) An instance of this class.
    */
    private static $instance;

    /*
        Group: Protected Static Data

        Array: $smarty_methods
            (array) An array containing methods that can be called through
            Smarty using {DLSupport}.

            For more information regarding how the parameters for the methods
            are set, refer to the method <CreateParameters>.

            The structure of this protected variable should look like the
            following:
            (code)
            array(
                {The name of the method.} => array(
                    parameters => {
                        (array) An array containing the parameters information
                        for this method. Refer to the $structure parameter of
                        the method CreateParameters for more information.
                    },
                    static => {
                        (boolean) Whether or not the method is static. Set this
                        to FALSE if it is an instance method.
                    }
                ),
                ...
            )
            (end)
    */
    protected static $smarty_methods = array(
        'CleanExit' => array(
            'static' => TRUE,
            'parameters' => array('message' => array())
        ),
        'ConvertBytes' => array(
            'static' => TRUE,
            'parameters' => array('bytes' => array(), 'type' => array())
        ),
        'Decrypt' => array(
            'static' => TRUE,
            'parameters' => array('key' => array(), 'data' => array())
        ),
        'Encrypt' => array(
            'static' => TRUE,
            'parameters' => array(
                'key' => array(),
                'data' => array(),
                'algorithm' => array('optional' => TRUE, 'default' => FALSE)
            )
        ),
        'GetCleanFooter' => array(
            'static' => TRUE,
            'parameters' => array()
        ),
        'GetCleanHeader' => array(
            'static' => TRUE,
            'parameters' => array(
                'page_title' => array(),
                'header_content' => array('optional' => TRUE, 'default' => '')
            )
        ),
        'GetIcon' => array(
            'static' => TRUE,
            'parameters' => array(
                'size' => array(),
                'icon' => array(),
                'alt' => array('optional' => TRUE, 'default' => ''),
                'theme' => array('optional' => TRUE, 'default' => 'aesthetica2')
            )
        ),
        'GetPageInfo' => array(
            'static' => TRUE,
            'parameters' => array('info' => array())
        ),
        'IncludeJavaScript' => array(
            'static' => TRUE,
            'parameters' => array(
                'force' => array('optional' => TRUE, 'default' => FALSE)
            )
        ),
        'ModulePath' => array(
            'static' => TRUE,
            'parameters' => array('module' => array())
        ),
        'ModuleURL' => array(
            'static' => TRUE,
            'parameters' => array('module' => array())
        ),
        'Protoaculous' => array(
            'static' => TRUE,
            'parameters' => array()
        ),
        'RemoveCookie' => array(
            'static' => TRUE,
            'parameters' => array('key' => array())
        ),
        'SetCookie' => array(
            'static' => TRUE,
            'parameters' => array(
                'key' => array(),
                'value' => array(),
                'days' => array()
            )
        )
    );

    /*
        Group: Class Construction

        Constructor: __construct
            Create a new instance of DLSupport.

        Returns:
            (DLSupport) An instance of DLSupport.
    */
    public function __construct() {
        parent::__construct();

        // Set this instance
        DLSupport::$instance = $this;

        // Register this module to smarty
        $this->RegisterModulePlugin();
    }

    /*
        Method: ModuleInstance
            Get an instance of the given module unqiue name.

        Parameters:
            $module - (string) The unique name of the module.

        Returns:
            (CMSModule) The module instance.
    */
    public static function &ModuleInstance($module) {
        // Get an instance of this module
        $DLS = DLSupport::Singleton();

        // Get the requested module
        $result = $DLS->GetModuleInstance($module);

        // Make sure it is the correct module
        if(!($result instanceof $module)) {
            // Try to include the class source
            $module_path = cms_join_path(DLSupport::ModulePath($module), $module.'.module.php');
            if(file_exists($module_path)) { require_once($module_path); }

            // Create the class if it exist
            if(class_exists($module, FALSE)) {
                $result = new $module();
            }
        }

        return $result;
    }

    /*
        Method: MySQLi
            Retrieve an instance of the database class.

        Returns:
            (DLDatabase) An instance of <DLDatabase>.
    */
    public static function &MySQLi() {
        return DLDatabase::Singleton();
    }

    /*
        Method: NewFormCollection
            Retreive a new form collection.

        Returns:
            (DLForm) The <DLForm> object.
    */
    public static function &NewFormCollection() {
        return new DLForm();
    }

    /*
        Method: NewTabCollection
            Create a new tab collection.

        Parameters:
            $tab_wrapper - (string) Optional and defaults to a randomly
                generated string. The ID of the tab wrapper.
            $content_wrapper - (string) Optional and defaults to a randomly
                generated string. The ID of the content wrapper.

        Returns:
            (DLTab) The <DLTab> object.
    */
    public static function &NewTabCollection($tab_wrapper = '', $content_wrapper = '') {
        // Generate a random string if the wrapper IDs are not given
        if(empty($tab_wrapper)) { $tab_wrapper = uniqid(); }
        if(empty($content_wrapper)) { $content_wrapper = uniqid(); }

        return new DLTab($tab_wrapper, $content_wrapper);
    }

    /*
        Method: Singleton
            This method will return an instance of this class. This method will
            also return the object by reference so when you call it, you should
            always save the result as a reference.

        Returns:
            (DLSupport) An instance of this class.
    */
    public static function &Singleton() {
        // See if we have it in the static variable
        if(!(DLSupport::$instance instanceof DLSupport)) {
            global $gCms;

            // See if the object already exist in the global object, otherwise
            // create it
            if(isset($gCms->modules['DLSupport']) &&
               $gCms->modules['DLSupport']['installed'] == TRUE &&
               $gCms->modules['DLSupport']['active'] == TRUE) {
                DLSupport::$instance = $gCms->modules['DLSupport']['object'];
            } else {
                DLSupport::$instance = new DLSupport();
            }
        }

        return DLSupport::$instance;
    }

    /*
        Group: Override Methods

        Methods:
            GetAbout             - Get about information.
            GetAuthor            - Get the author.
            GetAuthorEmail       - Get the author e-mail address.
            GetChangeLog         - Get the changelog.
            GetDescription       - Get a description of module.
            GetFriendlyName      - Get module friendly name.
            GetHelp              - Get help information.
            GetName              - Get module name.
            GetParameters        - Get parameters.
            GetVersion           - Get version number of module.
            HasAdmin             - Whether or not module has admin panel.
            InstallPostMessage   - Message to be displayed after installation.
            IsPluginModule       - Whether or not this is a plugin module.
            MinimumCMSVersion    - Minimum CMS version to run this module.
            UninstallPostMessage - Message to be displayed after uninstall.
            UninstallPreMessage  - Message to be alerted before uninstall.
    */
    function GetAbout() { return $this->Lang('about'); }
    function GetAuthor() { return 'Duc Tri Le'; }
    function GetAuthorEmail() { return 'cmsmadesimple@email.tiger-inc.com'; }
    function GetChangeLog() { return $this->Lang('changelog'); }
    function GetDescription() { return $this->Lang('about'); }
    function GetFriendlyName() { return 'DL Suite: Support'; }
    function GetHelp() { return $this->Lang('help'); }
    function GetName() { return __CLASS__; }
    function GetParameters() { return array(); }
    function GetVersion() { return '2.0'; }
    function HasAdmin() { return FALSE; }
    function InstallPostMessage() { return $this->Lang('postinstall'); }
    function IsPluginModule() { return TRUE; }
    function MinimumCMSVersion() { return '1.5.1'; }
    function UninstallPostMessage() { return $this->Lang('postuninstall'); }
    function UninstallPreMessage() { return $this->Lang('preuninstall'); }

    /*
        Group: Captcha Generation

        Method: Captcha
            Generate a new captcha image.

        Parameters:
            $hours - (int) Optional and defaults to 2. The maximum number of
                hours the created captcha remains valid.

        Returns:
            (array) The returned array will have its structure similar to the
            following:
            (code)
            array(
                image => {
                    (string) The HTML to display the captcha image.
                },
                field => {
                    (string) The HTML to display the input field.
                }
            )
            (end)
    */
    public static function Captcha($hours = 2) {
        // Remove old captcha images
        DLSupport::CaptchaRemove($hours);

        static $backgrounds = array(
            array('bg' => 'bg1.jpg', 'red' => 255, 'green' => 0, 'blue' => 0),
            array('bg' => 'bg2.jpg', 'red' => 0, 'green' => 0, 'blue' => 0),
            array('bg' => 'bg3.jpg', 'red' => 0, 'green' => 0, 'blue' => 0),
            array('bg' => 'bg4.jpg', 'red' => 0, 'green' => 0, 'blue' => 0),
            array('bg' => 'bg5.jpg', 'red' => 0, 'green' => 0, 'blue' => 0),
            array('bg' => 'bg6.jpg', 'red' => 0, 'green' => 0, 'blue' => 0),
            array('bg' => 'bg7.jpg', 'red' => 40, 'green' => 40, 'blue' => 115),
            array('bg' => 'bg8.jpg', 'red' => 0, 'green' => 0, 'blue' => 0),
            array('bg' => 'bg9.jpg', 'red' => 0, 'green' => 0, 'blue' => 0),
            array('bg' => 'bg10.jpg', 'red' => 0, 'green' => 0, 'blue' => 0),
        );
        static $fonts = array(
            array('font' => 'aardvark_cafe.ttf', 'size' => 18, 'x' => 10, 'y' => 23),
            array('font' => 'acquaintance.ttf', 'size' => 18, 'x' => 10, 'y' => 20),
            array('font' => 'arial_bold.ttf', 'size' => 16, 'x' => 10, 'y' => 20),
            array('font' => 'techno_overload.ttf', 'size' => 20, 'x' => 12, 'y' => 22),
            array('font' => 'vaporbyte_phat.ttf', 'size' => 18, 'x' => 3, 'y' => 20),
            array('font' => 'xpressive_bold.ttf', 'size' => 20, 'x' => 7, 'y' => 22)
        );

        // Generate the captcha string
        $key = str_pad(mt_rand(0, 99), 2, 0, STR_PAD_LEFT);
        $value = str_pad(mt_rand(0, 9999), 4, 0, STR_PAD_LEFT);

        // Combine the key and value for the user input
        $full_value = $key.$value;

        // Store string to session
        $_SESSION['DLSupport_'.md5($key)] = md5($full_value);

        // Randomly select a background image
        $background = $backgrounds[array_rand($backgrounds)];
        $background_path = cms_join_path(DLSupport::ModulePath('DLSupport'), 'images', 'captcha', 'backgrounds', $background['bg']);

        // Create the image and text color
        $image = imagecreatefromjpeg($background_path);
        $text_color = imagecolorallocate($image, $background['red'], $background['green'], $background['blue']);

        // Make sure we were successful, if not, create on white background
        if(!$image) {
            $image = imagecreatetruecolor(100, 25);
            $bg_color = imagecolorallocate($image, 255, 255, 255);
            imagefill($image, 0, 0, $bg_color);

            // Make the text color black
            $text_color = imagecolorallocate($image, 0, 0, 0);
        }

        // Randomly select a font
        $font = $fonts[array_rand($fonts)];
        $font_path = cms_join_path(DLSupport::ModulePath('DLSupport'), 'data', 'captcha', 'fonts', $font['font']);

        // Now add the text to the image
        imagettftext($image, $font['size'], 0, $font['x'], $font['y'], $text_color, $font_path, $full_value);
        imagejpeg($image, cms_join_path(DLSupport::ModulePath('DLSupport'), 'images', 'captcha', 'text', md5($value).'.jpg'));

        // Generate a unique ID
        $unique_id = uniqid();

        $result['image'] = '<img src="'.DLSupport::ModuleUrl('DLSupport').'/images/captcha/text/'.md5($value).'.jpg" id="'.$unique_id.'" />';
        $result['field'] = '<input type="text" name="DLSupport_captcha" />';

        return $result;
    }

    /*
        Method: CaptchaRemove
            Remove images created for captcha purposes that is older than the
            given number of hours.

        Parameters:
            $hours - (int) The number of hours in which if an image is older
                than this, it is removed.
    */
    public static function CaptchaRemove($hours) {
        // Get a listing of the files
        $files = DLSupport::ListFiles(cms_join_path(DLSupport::ModulePath('DLSupport'), 'images', 'captcha', 'text'));
        $cutoff = time() - ($hours*60*60);

        foreach($files as $file) {
            if(file_exists($file->full_path) && ($file->modified_time < $cutoff)) {
                unlink($file->full_path);
            }
        }
    }

    /*
        Method: CaptchaValidate
            See if the user has entered the correct value for the captcha
            generated by the method <Captcha>.

        Parameters:
            $hours - (int) Optional and defaults to 2. The maximum number of
                hours the created captcha remains valid.

        Returns:
            (boolean) Returns TRUE if the value is correct, FALSE, otherwise.
    */
    public static function CaptchaValidate($hours = 2) {
        // Remove old captcha images
        DLSupport::CaptchaRemove($hours);

        // Get value
        $full_value = DLSupport::SanitizeString('DLSupport_captcha', INPUT_POST);

        // Make sure it is a string and has 6 characters
        if(is_string($full_value) && (strlen($full_value) == 6)) {
            // Split it into the key and value
            $key = substr($full_value, 0, 2);
            $value = substr($full_value, 2);

            // Get testing data
            $md5_key = md5($key);
            $md5_value = md5($value);
            $md5_full_value = md5($full_value);
            $file = cms_join_path(DLSupport::ModulePath('DLSupport'), 'images', 'captcha', 'text', $md5_value.'.jpg');

            // Validate
            if(($_SESSION['DLSupport_'.$md5_key] == $md5_full_value) && (file_exists($file))) {
                unlink($file);
                unset($_SESSION['DLSupport_'.$md5_key]);

                return TRUE;
            }
        }

        return FALSE;
    }

    /*
        Group: Clean Admin - Deprecated

        Method: GetCleanBreadcrumb
            Retrieve the breadcrumb for a clean admin page.

        Parameters:
            $data - (array) An array of pages containing the breadcrumb
                information.
            $clean_object - (string) The name of the clean object that will
                call the <DLSupportJS.CleanAdmin.LinkToJavaScript>.

            The structure of the *$data* parameter, if given, should look like
            the following:
            (code)
            array(
                array(
                    url => {
                        (string) The URL of the page. This can be an empty
                        string in which case, no link is created.
                    },
                    text => {
                        (string) The title of the page.
                    }
                ),
                ...
            )
            (end)

        Returns:
            (string) The HTML for the breadcrumb.
    */
    public static function GetCleanBreadcrumb($data, $clean_object) {
        // Get an instance of this class
        $DLS = DLSupport::Singleton();

        // Set the data to Smarty
        $DLS->smarty->assign('DLSupport', array(
            'breadcrumb' => $data,
            'clean_object' => $clean_object
        ));

        // Process
        return $DLS->ProcessTemplate('DLSupport.clean_breadcrumb.tpl');
    }

    /*
        Method: GetCleanFooter
            Retrieve the HTML for the footer of the clean admin page.

            As of right now, this doesn't really do anything but for consistency
            sake, it will process a template.
    */
    public static function GetCleanFooter() {
        // Get an instance of this class.
        $DLS = DLSupport::Singleton();

        // Process and return result
        return $DLS->ProcessTemplate('DLSupport.clean_footer.tpl');
    }

    /*
        Method: GetCleanHeader
            Retrieve the HTML for the header of the clean admin page.

        Parameters:
            $page_title - (string) The title of the page.
            $header_content - (string) Any content to be put inside of the HEAD
                tag.

        Returns:
            (string) The HTML for the header.
    */
    public static function GetCleanHeader($page_title, $header_content = '') {
        // Get an instance of this class
        $DLS = DLSupport::Singleton();

        // Set data to Smarty
        $DLS->smarty->assign('DLSupport', array(
            'page_title' => $page_title,
            'header_content' => $header_content
        ));

        // Process and return result
        return $DLS->ProcessTemplate('DLSupport.clean_header.tpl');
    }

    /*
        Group: Cookies

        Method: RemoveCookie
            Remove the given cookie.

        Parameters:
            $key - (string) The key for the cookie.

        Smarty Usage:
            (code)
            {DLSupport
                method='RemoveCookie'
                key={ Corresponds to the parameter $key. }
            }
            (end)
    */
    public static function RemoveCookie($key) {
        setcookie($key, FALSE, time() - 3600, '/', $_SERVER['SERVER_NAME']);
        unset($_COOKIE[$key]);
    }

    /*
        Method: SetCookie
            Store the given information with the given key in the cookie for the
            given number of days.

        Parameters:
            $key - (string) The key for the cookie.
            $value - (string) The value of the cookie
            $days - (int) The number of days in which the cookie should last.

        Smarty Usage:
            (code)
            {DLSupport
                method='SetCookie'
                key={ Corresponds to the parameter $key. }
                value={ Corresponds to the parameter $value. }
                days={ Corresponds to the parameter $days. }
            }
            (end)
    */
    public static function SetCookie($key, $value, $days) {
        $expire = ($days > 0) ? time() + 60*60*24*$days : 0;

        setcookie($key, $value, $expire, '/', $_SERVER['SERVER_NAME']);
        $_COOKIE[$key] = $value;
    }

    /*
        Group: Cryptography

        Method: Decrypt
            Decrypt the given data using the given key.

        Parameters:
            $key - (string) The key for decrypting the data.
            $data - (string) The data to be decrypted.

        Returns
            (mixed) The data after it has been decrypted.

        Smarty Usage:
            (code)
            {DLSupport
                method='Decrypt'
                key={ Corresponds to the parameter $key. }
                data={ Corresponds to the parameter $data. }
            }
            (end)
    */
    public static function Decrypt($key, $data) {
        // Make sure the data was provided
        if(empty($data)) {
            DLSupport::LogError('The provided data cannot be empty.');
        }

        // Split the data up
        $split = explode('|', $data);

        // The algorithm is the last item
        $algorithm = base64_decode(array_pop($split));

        // Retrieve that algorithm's instance
        $instance = DLEncryption::ObjectPool($algorithm);

        // Decrypt the data
        return $instance->Decrypt($key, implode('|', $split));
    }

    /*
        Method: Encrypt
            Encrypt the given data using the given key.

        Parameters:
            $key - (string) The key for encrypting the data.
            $data - (mixed) The data to be encrypted.
            $algorithm - (mixed) Optional and defaults to FALSE. If given is a
                string, it should be the algorithm to use.

        Returns:
            (string) The data after it has been encrypted into a string.

        Smarty Usage:
            (code)
            {DLSupport
                method='Encrypt'
                key={ Corresponds to the parameter $key. }
                data={ Corresponds to the parameter $data. }
                algorithm={ Corresponds to the parameter $algorithm. }
            }
            (end)
    */
    public static function Encrypt($key, $data, $algorithm = FALSE) {
        // Randomly selects an algorithm if the algorithm is not given
        if(!$algorithm) {
            $algorithm = DLEncryption::$algorithms[array_rand(DLEncryption::$algorithms)];
        }

        // Retrieve an instance of that algorithm
        $instance = DLEncryption::ObjectPool($algorithm);

        // Encrypt the data
        $result = $instance->Encrypt($key, $data);

        // Add the algorithm to the result
        $result .= '|'.base64_encode($algorithm);

        return $result;
    }

    /*
        Group: CSS

        Method: GetCSSFromTemplate
            Get all of the CSS that is attached to the given template.

        Paramters:
            $template_id - (int) The ID of the template.

        Returns:
            (string) All of the CSS associated with the given template.
    */
    public static function GetCSSFromTemplate($template_id) {
        // Get an instance of this class
        $DLS = DLSupport::Singelton();

        // Get the database object
        $db = $DLS->GetDb();

        // Prepare the SQL
        $tpt = '
            SELECT css_text FROM %scss AS c
            INNER JOIN %scss_assoc AS a
            ON a.assoc_css_id = c.css_id
            WHERE
                a.assoc_to_id = %s AND
                a.assoc_type LIKE "template"
        ';
        $sql = sprintf($tpt, cms_db_prefix(), cms_db_prefix(), $template_id);

        // Retrieve the CSS
        $db->SetFetchMode(ADODB_FETCH_ASSOC);
        $css = $db->GetCol($sql) or array();

        // Generate result
        return implode("\n\n", $css);
    }

    /*
        Method: ParseCSS
            Parse the given CSS to retrieve the class names. Note that this will
            only return class names, no IDs, tags, etc.

        Parameters:
            $css - (string) The CSS to parse.
            $period - (boolean) Optional and defaults to TRUE. If this is set to
                FALSE, then the period in front of the class name will be
                removed.

        Returns:
            (array) An array containing all of the CSS class names in the given
            class sorted in alphabetical order.
    */
    public static function ParseCSS($css, $period = TRUE) {
        $result = array();

        // Make sure it is a string
        if(is_string($css) && !empty($css)) {
            // Remove the comments
            $css = preg_replace('/\/\*(.|\r|\n)*?\*\//', '', $css);

            // Remove the definition
            $css = preg_replace('/\{(.|\r|\n)*?\}/', ',', $css);

            // Split on commas
            $css = explode(',', $css);

            // For each rule
            foreach($css as $rule) {
                $item = trim($rule);

                if(!empty($item)) {
                    // Get all the class names
                    $matches = array();
                    preg_match_all('/\.[\w]+/', $rule, $matches);

                    // Add in the class names
                    foreach($matches[0] as $match) {
                        // Whether or not we should remove the period
                        if(!$period) { $match = substr($match, 1); }

                        $result[] = $match;
                    }
                }
            }

            // Keep only unique class names and sort it
            $result = array_unique($result);
            sort($result, SORT_STRING);
        }

        return $result;
    }

    /*
        Group: Database

        Method: AutoExecute
            Create the necessary SQL query and execute the command.

            Note that this will use the ADOdb Lite object.

        Parameters:
            $table - (string) The name of the table where the query should take
                place.
            $parameters - (array) The parameters to be inserted/updated.
            $type - (string) The type of SQL to create. Possible values are:
                "INSERT" and "UPDATE".
            $where - (string) Optional and defaults to an empty string. If
                given, this should be the body of the WHERE clause.
    */
    public static function AutoExecute($table, $parameters, $type, $where = '') {
        // Get an instance of this class
        $DLS = DLSupport::Singleton();

        // Get the database object
        $db = $DLS->GetDb();

        // Depending on the type, create the appropriate SQL
        if($type == 'INSERT') {
            $tpt_sql = 'INSERT INTO `%s` (%s) VALUES(%s);';

            // Get the column names
            $keys = array_keys($parameters);

            // Add slashes to key
            foreach($keys as $key => $item) {
                $keys[$key] = addslashes($item);
            }

            // Build the column string
            $columns = '`'.implode('`, `', $keys).'`';

            // Add slashes to the values
            foreach($parameters as $key => $item) {
                $parameters[$key] = addslashes($item);
            }

            // Build the values string
            $values = '"'.implode('", "', $parameters).'"';

            $sql = sprintf($tpt_sql, addslashes($table), $columns, $values);
        } elseif($type == 'UPDATE') {
            $tpt_sql = 'UPDATE `%s` SET %s %s;';

            // Get the individual update field
            $fields = array();
            foreach($parameters as $key => $value) {
                $fields[] = '`'.addslashes($key).'` = "'.addslashes($value).'"';
            }

            // Build the update string
            $update = implode(', ', $fields);

            // If we got a where body, use it
            if(!empty($where)) {
                $where = 'WHERE '.$where;
            }

            $sql = sprintf($tpt_sql, addslashes($table), $update, $where);
        } else {
            return;
        }

        // Execute the query
        $db->Execute($sql);
    }

    /*
        Group: Directory and Files

        Method: ListDirectories
            Retrieve a list of all direct sub directories of the given
            directory.

            Note that the returned array will not contain the given directory or
            the parent directory.

        Parameters:
            $path - (string) The absolute path to the base directory.
            $options - (array) An associative array containing various options
                used by this method. Refer to the method <ConvertBytes> for more
                information regarding some of the attributes. Defaults to an
                empty array.

            The structure of the *$options* parameter, if given, should look
            like the following:
            (code)
            array(
                bytes => {
                    (string) Refer to the parameter "$type" from the method
                    "ConvertBytes" for more information.
                },
                ignore_hidden => {
                    (boolean) Whether or not hidden directories should be
                    ignored. Defaults to TRUE.
                },
                reverse => {
                    (boolean) Whether or not the result should be inverted.
                    Defaults to FALSE.
                },
                sort => {
                    (string) The way the result should be sorted. Possible
                    values are: "name" and "total_space". Defaults to "name".
                }
            )
            (end)

        Returns:
            (array) The returned array will have its structure similar to the
            following:
            (code)
            array(
                Object(
                    name => {
                        (string) The name of the directory.
                    },
                    path => {
                        (string) The absolute path to the directory.
                    }
                    sub_dirs => {
                        (array) An array similar to this containing sub
                        directories of this directory.
                    },
                    total_space => {
                        (int) The size of all the files in directory.
                    }
                ),
                ...
            )
            (end)

    */
    public static function ListDirectories($path, $options = array()) {
        // Set options
        $options = array_merge(array(
            'bytes'         => 'b',
            'ignore_hidden' => TRUE,
            'reverse'       => FALSE,
            'sort'          => 'name'
        ), $options);

        // Cache of result
        static $cache = array();

        // Retrieve listing if we don't have it already
        if(!isset($cache[$path])) {
            // Get the listing
            $listing = scandir($path);

            // Build cache data
            $tmp = array(
                'name'          => array(),
                'path'          => array(),
                'sub_dirs'      => array(),
                'total_space'   => array()
            );
            foreach($listing as $item) {
                // Get the full path
                $full_path = cms_join_path($path, $item);

                // We only work on directories
                if(is_dir($full_path) && !in_array($item, array('.', '..'))) {
                    // Get and set data about the directory
                    $tmp['name'][$item] = $item;
                    $tmp['path'][$item] = $full_path;
                    $tmp['sub_dirs'][$item] = DLSupport::ListDirectories($full_path, $options);

                    // Calculate the total space
                    $total_space = exec('du -sb '.$full_path);
                    $total_space = explode("\t", $total_space);
                    $tmp['total_space'][$item] = $total_space[0];
                }
            }

            // Sort all of the arrays
            natsort($tmp['name']);
            natsort($tmp['total_space']);

            // Store to cache
            $cache[$path] = $tmp;

            // Clear up some memory
            unset($tmp);
        }

        // Get the data from cache
        $name = $cache[$path]['name'];
        $full_path = $cache[$path]['path'];
        $sub_dirs = $cache[$path]['sub_dirs'];
        $total_space = $cache[$path]['total_space'];

        // Convert the bytes
        foreach($total_space as $key => $value) {
            $total_space[$key] = DLSupport::ConvertBytes($value, $options['bytes']);
        }

        // Should we reverse the result?
        if($options['reverse']) {
            $$options['sort'] = array_reverse($$options['sort'], TRUE);
        }

        // Build the result
        $result = array();
        $keys = array_keys($$options['sort']);
        foreach($keys as $key) {
            // Do we want to ignore hidden directories?
            if($options['ignore_hidden'] && (strpos($key, '.') === 0)) {
                continue;
            }

            $dir = new stdClass();
            $dir->name = $name[$key];
            $dir->path = $full_path[$key];
            $dir->sub_dirs = $sub_dirs[$key];
            $dir->total_space = $total_space[$key];

            $result[] = $dir;
        }

        return $result;
    }

    /*
        Method: ListFiles
            Retrieve a list of all the files in the given directory. Note that
            this will not include any files in sub directories.

        Parameters:
            $path - (string) The absolute path to the base directory.
            $options - (array) An associative array containing various options
                used by this method. Refer to the method <ConvertBytes> for more
                information regarding some of the attributes. Defaults to an
                empty array.

            The structure of the *$options* parameter, if given, should look
            like the following:
            (code)
            array(
                bytes => {
                    (string) Refer to the parameter "$type" of the method
                    ConvertBytes for more information.
                },
                ignore_hidden => {
                    (boolean) Whether or not hidden directories should be
                    ignored. Defaults to TRUE.
                },
                reverse => {
                    (boolean) Whether or not the result should be inverted.
                    Defaults to FALSE.
                },
                sort => {
                    (string) The way the result should be sorted. Possible
                    values are: "access_time", "filename", "file_size", and
                    "modified_time". Defaults to "filename".
                }
            )
            (end)

        Returns:
            (array) The returned array will have its structure similar to the
            following:
            (code)
            array(
                Object(
                    access_time => {
                        (int) The time of last access as a UNIX timestamp.
                    },
                    filename => {
                        (string) The filename.
                    },
                    file_size => {
                        (int) The size of the file.
                    },
                    modified_time => {
                        (int) The time of last modification as a UNIX timestamp.
                    },
                    full_path => {
                        (string) The absolute path to the file.
                    }
                ),
                ...
            )
            (end)
    */
    public static function ListFiles($path, $options = array()) {
        // Set options
        $options = array_merge(array(
            'bytes'         => 'b',
            'ignore_hidden' => TRUE,
            'reverse'       => FALSE,
            'sort'          => 'filename'
        ), $options);

        // Cache of result
        static $cache = array();

        // Retrieve listing if we don't have it already
        if(!isset($cache[$path])) {
            // Get the listing
            $listing = scandir($path);

            // Build cache data
            $tmp = array(
                'access_time'   => array(),
                'filename'      => array(),
                'file_size'     => array(),
                'full_path'     => array(),
                'modified_time' => array()
            );
            foreach($listing as $item) {
                // Get the full path
                $full_path = cms_join_path($path, $item);

                // We only work on files
                if(is_file($full_path)) {
                    // Get and set data about the file
                    $tmp['access_time'][$item] = fileatime($full_path);
                    $tmp['filename'][$item] = $item;
                    $tmp['file_size'][$item] = filesize($full_path);
                    $tmp['full_path'][$item] = $full_path;
                    $tmp['modified_time'][$item] = filemtime($full_path);
                }
            }

            // Sort all of the arrays
            natsort($tmp['access_time']);
            natsort($tmp['filename']);
            natsort($tmp['file_size']);
            natsort($tmp['modified_time']);

            // Store to cache
            $cache[$path] = $tmp;

            // Clear up some memory
            unset($tmp);
        }

        // Get the data from cache
        $access_time = $cache[$path]['access_time'];
        $filename = $cache[$path]['filename'];
        $file_size = $cache[$path]['file_size'];
        $full_path = $cache[$path]['full_path'];
        $modified_time = $cache[$path]['modified_time'];

        // Convert the bytes
        foreach($file_size as $key => $value) {
            $file_size[$key] = DLSupport::ConvertBytes($value, $options['bytes']);
        }

        // Should we reverse the result?
        if($options['reverse']) {
            $$options['sort'] = array_reverse($$options['sort'], TRUE);
        }

        // Build the result
        $result = array();
        $keys = array_keys($$options['sort']);
        foreach($keys as $key) {
            // Do we want to ignore hidden directories?
            if($options['ignore_hidden'] && (strpos($key, '.') === 0)) {
                continue;
            }

            $file = new stdClass();
            $file->access_time = $access_time[$key];
            $file->filename = $filename[$key];
            $file->file_size = $file_size[$key];
            $file->modified_time = $modified_time[$key];
            $file->full_path = $full_path[$key];

            $result[] = $file;
        }

        return $result;
    }

    /*
        Group: Miscellaneous

        Method: CleanExit
            Clear all the currently opened output buffer then terminate
            execution with the given message.

        Parameters:
            $message - (string) The message to be outputted.

        Smarty Usage:
            (code)
            {DLSupport
                method='CleanExit'
                message={ Corresponds to the parameter $message. }
            }
            (end)
    */
    public static function CleanExit($message) {
        // Get how many level of output buffering there currently is
        $level = ob_get_level();

        // Clear all output buffering
        for($i = 0; $i < $level; ++$i) { ob_end_clean(); }

        // Output message and terminate script
        exit((string)$message);
    }

    /*
        Method: ConvertBytes
            Convert the given bytes to the specified type.

        Parameters:
            $bytes - (numeric) The bytes to be converted.
            $type - (string) The type to be converted to. This can be any of the
                following: "b" for bytes (stays the same), "k" for kilobytes,
                "m" for megabytes, "g" for gigabytes, and "t" for terrabytes.

        Returns:
            (numeric) The given bytes after it has been converted to the
            specified type.

        Smarty Usage:
            (code)
            {DLSupport
                method='ConvertBytes'
                bytes={ Corresponds to the parameter $bytes. }
                type={ Corresponds to the parameter $type. }
            }
            (end)
    */
    public static function ConvertBytes($bytes, $type) {
        $result = $bytes;

        // Start the conversion
        switch($type) {
            case 't':
                $result /= 1024;
            case 'g':
                $result /= 1024;
            case 'm':
                $result /= 1024;
            case 'k':
                $result /= 1024;
        }

        // Format the number
        $result = number_format($result, 2, '.', '');

        return $result;
    }

    /*
        Method: ExecuteCommand
            Execute the given list of commands.

        Parameters:
            $dir - (string) The directory where the given list of commands
                should be executed in.
            $commands - (array) An array containing the list of commands.
    */
    public static function ExecuteCommand($dir, $commands) {
        // Get the current directory
        $current_dir = getcwd();
        chdir($dir);

        // Execute each of the command
        $content = array();
        foreach($commands as $command) {
            exec($command, $content);
        }

        // Revert to old working directory
        chdir($current_dir);
    }

    /*
        Method: GetIcon
            Retrieve the HTML for an icon.

        Parameters:
            $size - (numeric) This is the dimension of the icon. Note that not
                all dimensions exist. Be sure to check that the dimension folder
                you are requesting exist.
            $icon - (string) The filename of the icon to get without its file
                extension. Note that not all icons exist. Be sure to check that
                they exist first.
            $alt - (string) Optional and defaults to an empty string. The text
                to be placed in the "alt" attribute of the IMG tag. If it is not
                given or empty, it will use the $icon value with underscores
                converted to whitespace and the first letter of each word would
                be capitalize.
            $theme - (string) Optional and defaults to "aesthetica2". The theme
                of the icon to get.

        Returns:
            (string) The HTML for the IMG tag with approropriate information for
            displaying the icon.

        Smarty Usage:
            (code)
            {DLSupport
                method='GetIcon'
                size={ Corresponds to the parameter $size. }
                icon={ Corresponds to the parameter $icon. }
                alt={ Corresponds to the parameter $alt. }
                theme={ Corresponds to the parameter $theme. }
            }
            (end)
    */
    public static function GetIcon($size, $icon, $alt = '', $theme = 'aesthetica2') {
        static $tpt = '<img src="%s/images/icons/%s/%sx%s/%s.png" alt="%s" class="DLSupport_icon %s" />';

        // Determine which alt message to use
        if(empty($alt)) {
            $alt = ucwords(str_replace('_', ' ', $icon));
        }

        // Get the icon
        $result = sprintf($tpt, DLSupport::ModuleUrl('DLSupport'), $theme, $size, $size, $icon, $alt, $icon);

        return $result;
    }

    /*
        Method: GetPageInfo
            Retrieve information about the current page.

        Parameters:
            $info - (string) The piece of information that is requested.
                Supported values are: alias, content_id, create_date, menu_text,
                modified_date, root_path, root_url, template_id, title,
                uploads_path, and uploads_url.

        Returns:
            (string) The value of the requested information.

        Smarty Usage:
            (code)
            {DLSupport
                method='GetPageInfo'
                info={ Corresponds to the parameter $info. }
            }
            (end)
    */
    public static function GetPageInfo($info) {
        // Cache
        static $page_info;
        static $get_page_info = TRUE;
        static $get_config = TRUE;

        if($get_page_info || $get_config) {
            // Get an instance of this class
            $DLS = DLSupport::Singleton();

            // Set the page information
            if(isset($DLS->cms->variables['pageinfo']) && $get_page_info) {
                $page_info['alias'] = $DLS->cms->variables['pageinfo']->content_alias;
                $page_info['content_id'] = $DLS->cms->variables['pageinfo']->content_id;
                $page_info['create_date'] = $DLS->cms->variables['pageinfo']->content_create_date;
                $page_info['menu_text'] = $DLS->cms->variables['pageinfo']->content_menutext;
                $page_info['modified_date'] = $DLS->cms->variables['pageinfo']->content_modified_date;
                $page_info['template_id'] = $DLS->cms->variables['pageinfo']->template_id;
                $page_info['title'] = $DLS->cms->variables['pageinfo']->content_title;

                $get_page_info = FALSE;
            }

            // Set the configs
            if(isset($DLS->config) && $get_config) {
                $page_info['admin_dir'] = $DLS->config['admin_dir'];
                $page_info['page_extension'] = $DLS->config['page_extension'];
                $page_info['root_path'] = $DLS->config['root_path'];
                $page_info['root_url'] = $DLS->config['root_url'];
                $page_info['uploads_path'] = $DLS->config['uploads_path'];
                $page_info['uploads_url'] = $DLS->config['uploads_url'];

                $get_config = FALSE;
            }
        }

        $result = isset($page_info[$info]) ? $page_info[$info] : NULL;

        return $result;
    }

    /*
        Method: IncludeJavaScript
            Include the JavaScript support file.

            This method has been deprecated in favor of using Prototype's
            framework but for the sake of backwards compatibility and the lack
            of flexibility on CMS's front of a truly flexible framework, this
            will be kept indefinitely.

        Parameters:
            $force - (boolean) Optional and defaults to FALSE. Technically,
                this should only be outputted once to the screen. For that
                reason, this will only return the result once. Any other time,
                it will just return an empty string. However, you can force the
                return of the output if you set this to TRUE.

        Returns:
            (string) The HTML that will include the neccessary JavaScript.

        Smarty Usage:
            (code)
            {DLSupport
                method='IncludeJavaScript'
                force={ Corresponds to the parameter $force. }
            }
            (end)
    */
    public static function IncludeJavaScript($force = FALSE) {
        static $result;

        if(is_null($result)) {
            $result = sprintf(
                '<link rel="stylesheet" type="text/css" href="%s" media="screen" />'.
                '<script type="text/javascript" src="%s"></script>'.
                '<script type="text/javascript">DLSupport.ModuleUrl = "%s";</script>',
                DLSupport::ModuleUrl('DLSupport').'/data/styles.css',
                DLSupport::ModuleUrl('DLSupport').'/data/dlsupport.js.php',
                DLSupport::ModuleUrl('DLSupport')
            );

            // Make this output
            $force = TRUE;
        }

        if($force) { return $result; }
        else { return ''; }
    }

    /*
        Method: JSON
            Terminate the execution of the script but outputting the given array
            as a JSON.

        Parameters:
            $data - (array) The array of data to be encoded and outputted.
    */
    public static function JSON($data) {
        DLSupport::CleanExit(json_encode($data));
    }

    /*
        Method: ModulePath
            Retrieve the absolute path to the given module.

        Parameters:
            $module - (string) The unique name of the module.

        Returns:
            (mixed) The absolute path to the module. If the path to the module
            does not exist, this returns FALSE.

        Smarty Usage:
            (code)
            {DLSupport
                method='ModulePath'
                module={ Corresponds to the parameter $module. }
            }
            (end)
    */
    public static function ModulePath($module) {
        // Cache
        static $result = array();

        // Only generate the path if it doesn't already exist
        if(empty($result[$module])) {
            $path = cms_join_path(DLSupport::GetPageInfo('root_path'), 'modules', $module);

            $result[$module] = $path;
        }

        return $result[$module];
    }

    /*
        Method: ModuleURL
            Retrieve the absolute url to the given module.

        Parameters:
            $module - (string) The unique name of the module.

        Returns:
            (string) The absolute url to the module.

        Smarty Usage:
            (code)
            {DLSupport
                method='ModuleURL'
                module={ Corresponds to the parameter $module. }
            }
            (end)
    */
    public static function ModuleURL($module) {
        $result = DLSupport::GetPageInfo('root_url').'/modules/'.$module;

        return $result;
    }

    /*
        Method: NewFormStart
            This is very similar to the method CreateFormStart except that it
            does not encode the content of the extras array.

        Parameters:
            $module - (CMSModule) The module object that is calling this method.
            $id - (string) The id given to the module on execution.
            $action - (string) Optional and defaults to "default". The action
                that this form should do when it is submitted.
            $returnid - (string) Optional and defaults to an empty string. The
                ID to eventually return to when the module is finished with its
                task.
            $method - (string) Optional and defaults to "post". The form method
                to use.
            $params - (array) Optional and defaults to an empty array. This
                should be an associative array containing any extra parameters
                to be sent as a hidden input field. The key of the array should
                be the field name and the value of the array should be the value
                of the input field.
            $extras - (array) Optional and defaults to an empty array. An array
                containing any other attributes to be included within the FORM
                tag.

        Returns:
            (string) The HTML for the start of a form. This will include the
            FORM tag along hidden INPUT tags if other fields are given.
    */
    public static function NewFormStart(&$module, $id, $action = 'default', $returnid = '', $method = 'post', $params = array(), $extras = array()) {
        static $tpt1 = '<form action="%s" method="%s" id="%s" %s>';
        static $tpt2 = '<input type="hidden" name="%s" value="%s" />';

        global $gCms;
        $count =& $gCms->variables['formcount'];
        if(!is_numeric($count)) { $count = 1; }

        // Get the template data
        $admin_or_frontend = $returnid == '';
        $url = $admin_or_frontend ? 'moduleinterface.php' : 'index.php';
        $form_id = $id.'moduleform_'.$count++;
        $attributes = implode(' ', $extras);
        $mact = sprintf($tpt2, 'mact', $module->GetName().','.$id.','.$action.','.($admin_or_frontend ? '0' : '1'));
        $return = $admin_or_frontend ? '' : sprintf($tpt2, $id.'returnid', $returnid);
        $security_key = sprintf($tpt2, CMS_SECURE_PARAM_NAME, $_SESSION[CMS_USER_KEY]);

        $parameters = '';
        foreach($params as $key => $value) {
            if(!in_array($key, array('module', 'action', 'id'))) {
                $parameters .= sprintf($tpt2, $id.$key, cms_htmlentities($value));
            }
        }

        $result = sprintf($tpt1, $url, $method, $form_id, $attributes).$mact.$return.$security_key.$parameters;
        return $result;
    }

    /*
        Method: OutputUploadResponse
            Output the response page for the uploaded of a file.

        Parameters:
            $data - (array) An associative array containing any data that should
                be returned as a JSON so that a function can use it. Defaults to
                an empty array.

        Returns:
            (string) The HTML for the server response.
    */
    public static function OutputUploadResponse($data) {
        DLSupport::CleanExit(
            '<html><head></head><body>'.
            DLSupport::UploadFileResponse($data).
            '</body></html>'
        );
    }

    /*
        Method: Protoaculous
            Retrieve the HTML for including Prototype, script.aculo.us from
            Google as well as the supporting JS frameworking.

        Returns:
            (string) The HTML for including the JS framework.

        Smarty Usage:
            (code)
            {DLSupport
                method='Protoaculous'
            }
            (end)
    */
    public static function Protoaculous() {
        static $result;

        if(is_null($result)) {
            $tpt1 = '<script type="text/javascript" src="%s">%s</script>';
            $tpt2 = '<link rel="stylesheet" type="text/css" href="%s" media="screen" />';

            $result = sprintf($tpt1, 'http://ajax.googleapis.com/ajax/libs/prototype/1.6.0.3/prototype.js', '');
            $result .= sprintf($tpt1, 'http://ajax.googleapis.com/ajax/libs/scriptaculous/1.8.1/scriptaculous.js', '');
            $result .= sprintf($tpt1, DLSupport::ModuleUrl('DLSupport').'/data/dlsupportjs.js.php', '');
            $result .= sprintf($tpt2, DLSupport::ModuleUrl('DLSupport').'/data/dlsupport.css');
        }

        return $result;
    }

    /*
        Method: SanitizeString
            Wrapper method for the function "filter_var" with the filter
            FILTER_SANITIZE_STRING and the options FILTER_FLAG_ENCODE_LOW and
            FILTER_FLAG_ENCODE_HIGH.

        Parameters:
            $data - (mixed) The data to be filtered.
            $input - (mixed) Optional and defaults to FALSE. If this is given,
                it would use this value as the input type and use the function
                "filter_input" instead of "filter_var".

        Returns:
            (mixed) The string after the data has been filtered. This will
            return FALSE if it failed.
    */
    public static function SanitizeString($data, $input = FALSE) {
        $options = FILTER_FLAG_ENCODE_LOW & FILTER_FLAG_ENCODE_HIGH;

        // See if we want to use filter_var or filter_input
        if($input === FALSE) {
            $result = filter_var($data, FILTER_SANITIZE_STRING, $options);
        } else {
            $result = filter_input($input, $data, FILTER_SANITIZE_STRING, $options);
        }

        return $result;
    }

    /*
        Method: UploadFileResponse
            Retrieve the HTML for the response from the server.

        Parameters:
            $data - (array) An associative array containing any data that should
                be returned as a JSON so that a function can use it. Defaults to
                an empty array.

        Returns:
            (string) The HTML for the server response.
    */
    public static function UploadFileResponse($data = array()) {
        // Get an instance of this class
        $DLS = DLSupport::Singleton();

        // Set data to Smarty
        $DLS->smarty->assign('DLSupport', array(
            'json' => addcslashes(json_encode($data), '\'')
        ));

        // Process and return
        return $DLS->ProcessTemplate('DLSupport.upload_response.tpl');
    }

    /*
        Method: UploadPageResponse
            Output the upload response page.

        Parameters:
            $data - (array) An associative array containing any data that should
                be returned as a JSON so that a function can use it. Defaults to
                an empty array.
    */
    public static function UploadPageResponse($data) {
        DLSupport::CleanExit(
            '<html><head><title>Upload Response</title></head><body>'.
            DLSupport::UploadFileResponse($data).
            '</body></html>'
        );
    }

    /*
        Group: Module Dependency

        Method: CompareVersions
            See if the installed version of the given module is less than the
            given version.

            The checking scheme is: 2 = 2.0.0.0 > 2.0.0.0RC12 > 2.0.0.0RC2 >
            1.11.12.34 > 1.2.12.43.

        Parameters:
            $module - (string) The name of the module to test.
            $version - (string) The version to test against.
            $valide_failed - (boolean) The current result of the validation.
                If TRUE, then validation has failed, FALSE otherwise.

        Returns:
            (boolean) Returns TRUE if the installed version is less than the
            given version, FALSE otherwise.
    */
    public static function CompareVersions($module, $version, &$validate_failed) {
        // If validation already failed, no need to check
        if($validate_failed) { return $validate_failed; }

        // Get an instance of this class
        $DLS = DLSupport::Singleton();

        // First, make sure the given module exists and we have the object
        $continue = isset($DLS->cms->modules[$module]) &&
                    ($DLS->cms->modules[$module]['installed'] == 1) &&
                    ($DLS->cms->modules[$module]['object'] instanceof $module);
        if($continue) {
            // Get an instance of the module
            $object = DLSupport::ModuleInstance($module);

            // Get the version from the database, relying on GetVersion if we
            // cannot get it from the database
            $DB = $DLS->GetDb();
            $sql = sprintf(
                'SELECT `version` FROM %smodules WHERE `module_name` LIKE "%s" LIMIT 1;',
                cms_db_prefix(), addcslashes($module, '"')
            );
            $installed_version = $DB->GetOne($sql) or $object->GetVersion();

            // Split on RC
            $installed_split = explode('RC', $installed_version);
            $check_split = explode('RC', $version);

            // Split on dots
            $installed_split[0] = explode('.', $installed_split[0]);
            $check_split[0] = explode('.', $check_split[0]);

            // Get the counts
            $count = max(count($installed_split[0]), count($check_split[0]));

            // Compare left part
            $failed = FALSE;
            for($i = 0; ($i < $count) && !$failed; ++$i) {
                $t1 = isset($installed_split[0][$i]);
                $t2 = isset($check_split[0][$i]);

                if($t1 && $t2) {
                    if($installed_split[0][$i] > $check_split[0][$i]) {
                        return FALSE;
                    }

                    $failed = $installed_split[0][$i] < $check_split[0][$i];
                } elseif($t1) {
                    $failed = $installed_split[0][$i] > 0;
                } else {
                    $failed = $check_split[0][$i] > 0;
                }
            }

            // Compare the RC if need be
            if(!$failed) {
                $t1 = isset($installed_split[1]) ? $installed_split[1] : 9999;
                $t2 = isset($check_split[1]) ? $check_split[1] : 9999;

                $failed = $t1 < $t2;
            }

            if(!$failed) {
                return FALSE;
            }
        }

        // If we made it here, validation has failed
        $validate_failed = TRUE;
        return TRUE;
    }

    /*
        Group: Smarty Related Methods

        Method: CreateParameters
            Create the appropriate parameters array to be send to the function
            *call_user_func_array*.

        Parameters:
            $structures - (array) An associative array containing how the
                parameters array should be built.
            $data - (array) An associative array containing the data for the
                parameters.

            The structure of the *$structures* parameters, if given, should look
            like the following:
            (code)
            array(
                {The name of the parameter.} => array(
                    default => {
                        (mixed) The default value to use for this parameter if
                        it is optional and wasn't provided by the user. Defaults
                        to NULL.
                    },
                    is_array => {
                        (boolean) Whether or not this parameter is expected to
                        be an array. Defaults to FALSE.
                    },
                    optional => {
                        (boolean) Whether or not this parameter is optional.
                        Defaults to FALSE.
                    },
                    sub_elements => {
                        (array) If "is_array" is TRUE, then this should be
                        similar to the overlying array. Defaults to an empty
                        array.
                    }
                ),
                ...
            )
            (end)

        Returns:
            (array) The parameters array.
    */
    public static function CreateParameters($structures, $data) {
        $result = array();

        foreach($structures as $param => $structure) {
            $structure = array_merge(array(
                'default' => NULL,
                'is_array' => FALSE,
                'optional' => FALSE,
                'sub_elements' => array()
            ), $structure);

            if($structure['is_array']) {
                $result[$param] = DLSupport::CreateParameters(
                    $structure['sub_elements'], $data
                );
            } elseif($structure['optional']) {
                $result[$param] = isset($data[$param]) ? $data[$param] : $structure['default'];
            } else {
                if(!isset($data[$param])) {
                    DLSupport::CleanExit('CreateParameters: A required parameter was not provided.');
                } else {
                    $result[$param] = $data[$param];
                }
            }
        }

        return $result;
    }

    /*
        Group: Deprecated Data

        Array: $DLSupport_data
            (array) An array contain various data.

            Note that this will be removed complete by version 3.0.
    */
    private $DLSupport_data;

    /*
        Group: Deprecated Methods

        Method: ValidateDependency
            Determine whether or not the given module name has been installed up
            to at least the given version.

            The checking scheme is: 2.0 > 1.2 > 1.12 > 1.1 > 1.1RC2 > 1.1RC1 >
            1.0

            Note that this kind of validation checking scheme is not really wide
            used so this is now considered deprecated.

        Parameters:
            $module - (string) The name of the module to test.
            $version - (string) The minimum version required to pass the test.
            $validate_failed - (boolean) The current result of the validation.
                If TRUE, then validation has failed, FALSE otherwise.

        Returns:
            (boolean) Returns TRUE if the validation has failed, FALSE
            otherwise. Basically, this will have the same value as
            $validate_failed.
    */
    public static function ValidateDependency($module, $version, &$validate_failed) {
        static $tpt = 'SELECT `version` FROM %smodules WHERE `module_name` LIKE "%s" LIMIT 1;';

        // If validation already failed, no need to check
        if($validate_failed) { return $validate_failed; }

        // Get the global CMS object
        global $gCms;

        // First, make sure given module exist and we have the object
        if(isset($gCms->modules[$module]) &&
           ($gCms->modules[$module]['installed'] == 1) &&
           ($gCms->modules[$module]['object'] instanceof $module)) {
            // Get the object
            $object = $gCms->modules[$module]['object'];

            // Get the version from the database, relying on GetVersion if we
            // cannot get it from the database
            $db = $gCms->GetDb();
            $sql = sprintf($tpt, cms_db_prefix(), $module);
            $object_version = $db->GetOne($sql) or $object->GetVersion();

            // If version has "RC" in it, get that number
            if(is_numeric($pos = strpos($version, 'RC'))) {
                $rc = substr($version, $pos+2);
                $version = substr($version, 0, $pos);
            }

            // If object version has "RC" in it, get that number
            if(is_numeric($pos = strpos($object_version, 'RC'))) {
                $object_rc = substr($object_version, $pos+2);
                $object_version = substr($object_version, 0, $pos);
            }

            // Now, check their version
            if($object_version > $version) { return FALSE; }

            // If the versions are equal, check their RC numbers
            if($object_version == $version) {
                // If they are truly equal
                if(!isset($object_rc) && !isset($rc)) { return FALSE; }

                // Example: 1.0 > 1.0RC1
                if(!isset($object_rc) && isset($rc)) { return FALSE; }

                // Example: 1.0RC2 >= 1.0RC1
                if(isset($object_rc) && isset($rc) && ($object_rc >= $rc)) { return FALSE; }
            }
        }

        // If we made it here, then validation has failed
        $validate_failed = TRUE;
        return $validate_failed;
    }
}

// Include auxilary classes
require_once('class.DLCleanAdmin.php');
require_once('class.DLDatabase.php');
require_once('class.DLEncryption.php');
require_once('class.DLForm.php');
require_once('class.DLTab.php');
?>