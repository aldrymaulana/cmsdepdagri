<?php
/* Start: Core */
$lang['about'] = <<<EOT
<p>
    DL Suite: Comments is a heavy AJAX dependent module for user comments. If
    allows the user to submit a comment to the webmaster for approval before it
    is posted on the web site. It is easy to use and customizable via CSS.
</p>
<p>
    Some key features includes the usage of browser compatiable AJAX for easy
    and seemless integration with almost any web site. This has been tested on
    Firefox 2.0+, Internet Explorer 7.0+, Safari 3.0+, and Opera 9.25+. The
    usage of captcha to prevent bots from submitting the form and easy flow
    of comments management. The person in change of approving the comment can
    also edit the comments to prevent any unwanted words. Simply click on
    the comment and a textarea will appear to allow editing. The same goes
    for the provided username.
</p>
<p>
    <b>Author:</b> Duc Tri Le<br />
    <b>Website:</b> <a href="http://tiger-inc.com" target="blank">Tiger Inc.</a><br />
    <b>Module Homepage:</b> <a href="http://tiger-inc.com/cms-made-simple/dlcomments/" target="_blank">DL Suite: Comments</a>
</p>
EOT;

$lang['changelog'] = <<<EOT
<pre>
    * 1.0RC2 (December 12, 2008): Switched comments to NaturalDocs and moved
            methods back into file. Hence, the method __call is removed. Fixed
            bug with the display of the CSS not showing another CSS template.
            Changed the way some data are stored in the database.
    * 1.0RC1 (August 15, 2008): Added the ability to auto approve comments
        and sending an e-mail to let you know a comment was submitted.
    * 0.3 (May 30, 2008): Second try at bug fix for Module Manager.
    * 0.2 (May 30, 2008): Fixed bug when installing via Module Manager.
    * 0.1 (May 16, 2008): Initial release.
    * 0.0 (April 10, 2008): Started.
</pre>
EOT;

$lang['help'] = <<<EOT
<p>
    For usage information regarding DL Suite: Comments, please refer to the
    module homepage.
</p>
<p>
    <b>Author:</b> Duc Tri Le<br />
    <b>Website:</b> <a href="http://tiger-inc.com" target="blank">Tiger Inc.</a><br />
    <b>Module Homepage:</b> <a href="http://tiger-inc.com/cms-made-simple/dlcomments/" target="_blank">DL Suite: Comments</a>
</p>
EOT;
/* End: Core */

/* Start: Installation */
$lang['postinstall'] = <<<EOT
<p>
    The installation of DL Suite: Comments was a success. Please go to this
    module's web site for usage information.
</p>
<p>
    <b>Author:</b> Duc Tri Le<br />
    <b>Website:</b> <a href="http://tiger-inc.com" target="blank">Tiger Inc.</a><br />
    <b>Module Homepage:</b> <a href="http://tiger-inc.com/cms-made-simple/dlcomments/" target="_blank">DL Suite: Comments</a>
</p>
EOT;

$lang['postuninstall'] = 'DL Suite: Comments has been successfully uninstalled.';
$lang['preuninstall']  = 'Are you sure you want to uninstall DL Suite: Comments?';
/* End: Installation */

/* Start: Text */
$lang['add']            = 'Add';
$lang['approve']        = 'Approve';
$lang['no']             = 'No';
$lang['remove']         = 'Remove';
$lang['save']           = 'Save';
$lang['settings']       = 'Settings';
$lang['submit']         = 'Submit';
$lang['yes']            = 'Yes';
/* End: Text */

/* Start: Phrases */
$lang['approve_comments']                   = 'Approve Comments';
$lang['error_image']                        = 'Error Image';
$lang['error_message']                      = 'Error Message';
$lang['invalid_captcha']                    = 'Invalid Captcha';
$lang['modify_comments']                    = 'Modify Comments';
$lang['modify_css']                         = 'Modify CSS';
$lang['modify_comments_templates']          = 'Modify Comments Templates';
$lang['modify_submission_form_templates']   = 'Modify Submission Form Templates';
$lang['show_all']                           = 'Show All';
$lang['success_image']                      = 'Success Image';
$lang['success_message']                    = 'Success Message';
$lang['warning_image']                      = 'Warning Image';
$lang['warning_message']                    = 'Warning Message';
/* End: Phrases */

/* Start: Messages */
$lang['mail_body']                                  = 'A new comment has been submitted and is awaiting your approval. The comment was added to the comment group';
$lang['mail_subject']                               = 'DL Suite: Comments - Comment awaiting approval';

$lang['failure_auto_approve_frontend']              = 'The value provided for whether or not the comment should automatically be approved is invalid.';
$lang['failure_use_captcha_frontend']               = 'The value provided for whether or not the CAPTCHA should be used is invalid.';
$lang['failure_email_address_frontend']             = 'The provided e-mail address is invalid.';
$lang['failure_group']                              = 'The provided comment group does not exist.';
$lang['failure_invalid_action_approval']            = 'The request could not be complete because an invalid action was sent.';
$lang['failure_invalid_action_modify']              = $lang['failure_invalid_action_approval'];
$lang['failure_invalid_action_css']                 = $lang['failure_invalid_action_approval'];
$lang['failure_last_template_css']                  = 'You must have at least one CSS so the request to remove the selected CSS could not be completed.';
$lang['failure_last_template_comments']             = 'You must have at least one comment template so the request to remove the selected comment template could not be completed.';
$lang['failure_last_template_submission_form']      = 'You must have at least one submission form template so the request to remove the selected submission form template could not be completed.';
$lang['failure_missing_ids_approval']               = 'At least one comment must be selected for approval.';
$lang['failure_missing_ids_modify']                 = 'At least one comment must be selected for modification.';
$lang['failure_missing_group_frontend']             = 'Please provide a message to be shown to the user when they are submitting a comment that is missing a comment group.';
$lang['failure_missing_required_frontend']          = 'Pleae provide a message to be shown to the user when they are submitting a comment but did not fill out all of the fields.';
$lang['failure_show_icon_frontend']                 = 'The value provided for whether or not the icon should be shown on the frontend is invalid.';
$lang['failure_success_add_frontend']               = 'Please provide a message to be shown to the user when they have successfully submitted a comment.';
$lang['failure_missing_name_css']                   = 'Please provide a name for the selected CSS.';
$lang['failure_missing_name_comments']              = 'Please provide a name for the selected comment template.';
$lang['failure_missing_name_submission_form']       = 'Please provide a name for the selected submission form template.';
$lang['failure_template_exist_css']                 = 'The provided name for the selected CSS already exist. Please specify a different name.';
$lang['failure_template_exist_comments']            = 'The provided name for the selected comment template already exist. Please specify a different name.';
$lang['failure_template_exist_submission_form']     = 'The provided name for the selected submission form template already exist. Please specify a different name.';
$lang['failure_template_nonexist_css']              = 'The request could not be complete because the selected CSS does not exist.';
$lang['failure_template_nonexist_comments']         = 'The request could not be complete because the selected comment template does not exist.';
$lang['failure_template_nonexist_submission_form']  = 'The request could not be complete because the selected submission form template does not exist.';
$lang['failure_type']                               = 'The provided request type is invalid.';
$lang['failure_send_email_frontend']                = 'The value provided for whether or not an e-mail should be sent upon submission is invalid.';

$lang['success_show_approval']                      = 'The following are all the comments for the selected comment group that requires approval before it is shown on the frontend:';
$lang['success_show_modify']                        = 'The following are all the comments for the selected comment group that you can modify:';
$lang['success_update_add_css']                     = 'The provided CSS was successfully added.';
$lang['success_update_add_comments']                = 'The provided comment template was successfully added.';
$lang['success_update_add_submission_form']         = 'The provided submission form template was successfully added.';
$lang['success_update_approval']                    = 'The selected comments has been set to approved.';
$lang['success_update_modify']                      = 'The selected comments has been successfully modified.';
$lang['success_update_remove_css']                  = 'The selected CSS was successfully removed.';
$lang['success_update_remove_comments']             = 'The selected comment template was successfully removed.';
$lang['success_update_remove_submission_form']      = 'The selected sumission form template was successfully removed.';
$lang['success_update_save_css']                    = 'The selected CSS was successfully modified.';
$lang['success_update_save_comments']               = 'The selected comment template was successfully modified.';
$lang['success_update_save_submission_form']        = 'The selected submission form template was successfully modified.';
$lang['success_update_settings']                    = 'Your settings has been successfully updated.';

$lang['warning_no_comments_approval']               = 'There are no more comment that needs approval for the selected comment group.';
$lang['warning_no_comments_modify']                 = 'No comment is available for editing for the selected comment group.';
/* End: Messages */
?>