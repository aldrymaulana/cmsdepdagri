tinyMCE.addI18n('ca.paste_dlg',{
text_title:"Utilitza CTRL+V al teclat per enganxar el text a la finestra.",
text_linebreaks:"Mantingues els salts de l\u00EDnia",
word_title:"Utilitza CTRL+V al teclat per enganxar el text a la finestra."
});