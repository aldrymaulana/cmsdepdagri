/*
    Class: DLSupport.Form
        Handle form submissions.

        This is used when we cannot use Prototype.
*/
DLSupport.Form = {
    /*
        Method: addParameter
            Add the given element into the given parameters object based on some
            pre-set rules.

        Parameters:
            parameters - (object) The parameter object.
            element - (object) The element to try to add to the parameters
                object.
            is_array - (boolean) Whether or not the value should be considered
                as an array.
    */
    addParameter: function(parameters, element, is_array) {
        // If the element is a checkbox or radio and it is checked, no need to
        // do anything
        if((element.type == 'checkbox') || (element.type == 'radio')) {
            if(!element.checked) {
                return;
            }
        }

        // If the element is a select with multiple value, or the value is
        // expected to be an array, we do things differently
        if(element.type == 'select-multiple') {
            parameters[element.name] = new Array();

            for(var i = 0; i < element.options.length; ++i) {
                if(element.options[i].selected) {
                    parameters[element.name].push(element.options[i].value);
                }
            }
        } else if(is_array) {
            parameters[element.name].push(element.value);
        } else {
            parameters[element.name] = element.value;
        }
    },

    /*
        Method: disableSubmitFields
            Disable all of the submit fields of the given form.

        Parameters:
            form - (object) The form for which all of its submit fields will be
                disabled.
    */
    disableSubmitFields: function(form) {
        // Traverse all of the form elements and disable the submit fields
        var element;
        for(var i = 0; i < form.elements.length; ++i) {
            element = form.elements[i];

            if(element.type == 'submit') {
                element.disabled = true;
            }
        }
    },

    /*
        Method: enableSubmitFields
            Enable all of the submit fields for the given form.

        Parameters:
            form - (object) The form for which all of its submit fields will be
                enabled.
    */
    enableSubmitFields: function(form) {
        // Traverse all of the form elements and enable the submit fields
        var element;
        for(var i = 0; i < form.elements.length; ++i) {
            element = form.elements[i];

            if(element.type == 'submit') {
                element.disabled = false;
            }
        }
    },

    /*
        Method: fieldCount
            Retrieve an object with its property names being all the named
            fields of the given form and its value being how many fields have
            that name.

        Parameters:
            form - (object) The form for which the data is to be retrieved from.

        Returns:
            (object) An associative array with the field name as the property
            and the number of fields with the same name as the value.
    */
    fieldCount: function(form) {
        // For each element with a name, add their count to result
        var result = {}, element;
        for(var i = 0; i < form.elements.length; ++i) {
            element = form.elements[i];

            // Make sure element has a name
            if(element.name.length > 0) {
                // If element has not been added before, initialize it
                if(!result[element.name]) {
                    result[element.name] = 0;
                }

                ++result[element.name];
            }
        }

        return result;
    },

    /*
        Method: submitValue
            Set the value of the given element as the submit value for the
            element's form. This is useful for forms to be sent via AJAX that
            has multiple submit buttons.

        Parameters:
            element - (object) The element that contains the submit value. Note
                that the element must be a DOM element with the property "form"
                which points to the form for which the element belongs to.

        Returns:
            (boolean) Returns true if successful, false, otherwise.
    */
    submitValue: function(element) {
        try {
            element.form.DLSupport_SubmitValue = element.value;

            return true;
        } catch(e) {
            // Add error message to error log
            DLSupport.addErrorLog('DLSupport.Form.submitValue', [element], e.message);

            return false;
        }
    },

    /*
        Method: toQueryString
            Convert the given form data to a query string. Although this will
            handle fields that can have multiple values like checkboxes, make
            sure you name it appropriately however.

        Parameters:
            form - (object) The form for which the data is to be retrieved from.

        Returns:
            (string) The given form data as a query string.
    */
    toQueryString: function(form) {
        // Get the field's count for the given form
        var field_count = DLSupport.Form.fieldCount(form);

        // Prepare the object with the form data
        var parameters = {}, gotSubmit = false, element;
        for(var i = 0; i < form.elements.length; ++i) {
            element = form.elements[i];

            // Only continue if the element has a name
            if(element.name.length < 1) {
                continue;
            }

            // If an element has more than 1 field count, its value should be
            // store as an array unless it is a submit type
            if((field_count[element.name] > 1)) {
                // There can only be one submit button, so handle this case
                if((element.type == 'submit') || (element.type == 'image')) {
                    // If the submit value stored in the form equals the given
                    // element's value, then it is the value we want to send
                    if(form.DLSupport_SubmitValue == element.value) {
                        gotSubmit = true;
                        DLSupport.Form.addParameter(parameters, element, false);
                    } else if(!gotSubmit) {
                        // Otherwise, just add current one as later ones will
                        // overwrite this value
                        DLSupport.Form.addParameter(parameters, element, false);
                    }

                    continue;
                }

                // Create the array if needed
                if(!DLSupport.isArray(parameters[element.name])) {
                    parameters[element.name] = new Array();
                }

                DLSupport.Form.addParameter(parameters, element, true);
            } else {
                DLSupport.Form.addParameter(parameters, element, false);
            }
        }

        // Convert the parameters object to a query string
        var result = DLSupport.toQueryString(parameters);

        return result;
    }
};