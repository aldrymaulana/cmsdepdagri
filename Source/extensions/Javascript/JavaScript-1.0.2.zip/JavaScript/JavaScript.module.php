<?php

class JavaScript extends CMSModule {
	var $table_base = '';
	var $db;
	
	function GetName() {
		return 'JavaScript';
	}

	function GetFriendlyName() {
		return $this->Lang('friendly_name');
	}

	function GetVersion() {
		return '1.0.2';
	}

	function GetHelp() {
		return $this->Lang('help');
	}

	function GetAuthor() {
		return 'Jonathan Nichols';
	}

	function GetAuthorEmail() {
		return 'nichols.jonathan.r@gmail.com';
	}
	
	function MinimumCMSVersion() {
		return '1.7';
	}
	
	function IsPluginModule() {
		return true;
	}
	
	function HasAdmin() {
		return true;
	}
	
    function GetAdminSection() {
		return 'layout';
	}
	
	function SetParameters() {
		$this->RegisterModulePlugin();
	}
	
	function JavaScript() {
		$this->table_base = cms_db_prefix() . 'module_';
		$this->db = &$this->GetDb();
	}
	
	function OutputJSExternal( $params ) {
		global $config;
		
		$url = $config['root_url'] . $this->GetModulePath() . "/scripts.php";
		
		$query = "SELECT * FROM {$this->table_base}javascript WHERE javascript_external_include <> 0;";
		$rsExternal = $this->db->Execute($query);
		
		while ( ($rsExternal) && (!$rsExternal->EOF) ) {
			echo "<script type=\"text/javascript\" src=\"{$rsExternal->fields['javascript_content']}\"></script>\r";
			$rsExternal->MoveNext();
		}
		
		if (isset($params['javascript'])) {
			$url .= "?javascript={$params['javascript']}";
		}
		
		echo "<script type=\"text/javascript\" src=\"{$url}\"></script>\r";
	}
	
	/* Only outputs one JS file */
	function OutputJSInline( $javascript = false ) {
		if (!$javascript) { return; }
		
		global $params;
		global $gCms;
		
		$smarty = $gCms->GetSmarty();
		
		$query = "SELECT * FROM {$config['db_prefix']}module_javascript WHERE javascript_external_include = 0";
		
		if ( $javascript ) {
			$query .= " AND javascript_alias = " . $db->qstr($javascript);
		} else {
			$query .= " AND javascript_global <> 0";
		}
		
		$query .= " ORDER BY javascript_sort_order;";
		
		$rsScripts = $this->db->Execute($query);
		
		if ($db->ErrorNo() > 0) {
			echo "/*" . $this->db->ErrorMsg() . "*/";
		}
		
		while ( ($rsScripts) && (!$rsScripts->EOF) ) {
			echo "/*Script: {$rsScripts->fields['javascript_name']}*/\r";
			//Switch to our delimiters so that JS brackets are not processed
			// [-[ & ]-] ensure that JSON is not parsed as well
			$smarty->left_delimiter = '[-[';
			$smarty->right_delimiter = ']-]';
			
			//Compile the data and return in in $_compiled
			$smarty->_compile_source('Temporary JavaScript', $rsScripts->fields['javascript_content'], $_compiled );
			
			//Interpret the compiled information
			@ob_start();
			$smarty->_eval('?>' . $_compiled);
			$contents = @ob_get_contents();
			@ob_end_clean();
			
			//Set the delimiters back to the CMS to finish the rest of the processing
			$smarty->left_delimiter = '{';
			$smarty->right_delimiter = '}';
			
			//Display the JavaScript
			if ((bool)$rsScripts->fields['javascript_compress']) {
				echo "/*Minified using JSMin http://www.crockford.com/javascript/jsmin.html*/\r";
				$contents = JSMin::minify($contents);
			}
			
			if ((bool)$rsScripts->fields['javascript_pack']) {
				echo "/*Packed using Packer http://joliclic.free.fr/php/javascript-packer/en/*/\r";
				$packer = new JavaScriptPacker($contents, 'Normal', false, false);
				$contents = $packer->pack();
			}
			
			echo $contents;
			
			$rsScripts->MoveNext();
		}
	}
	
}

?>