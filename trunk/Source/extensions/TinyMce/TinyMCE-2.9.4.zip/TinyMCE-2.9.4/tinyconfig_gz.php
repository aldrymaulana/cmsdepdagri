<?PHP

echo "nothing for you here...";
die();

?>

