<?php

echo "nothing for you here...";
exit;

?>