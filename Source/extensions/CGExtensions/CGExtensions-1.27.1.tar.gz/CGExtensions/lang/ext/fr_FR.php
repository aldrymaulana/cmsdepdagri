<?php
$lang['param_nocache'] = 'Utilis&eacute; si la mise en cache de modules est activ&eacute;e, ce param&egrave;tre d&eacute;sactivera la mise en cache de ce module. Ce param&egrave;tre est utile.';
$lang['info_cache_modulecalls'] = 'EXPERIMENTAL : dans certaines circonstances, le r&eacute;sultat de l&#039;appel &agrave; un module peut &ecirc;tre mis en cache. L&#039;activer peut am&eacute;liorer significativement les performances de votre site. Cependant, cela peut causer des difficult&eacute;s sur certains appels. Vous pouvez d&eacute;sactiver cette option en ajoutant le param&egrave;tre nocache=1 &agrave; l&#039;appel de votre module.';
$lang['cache_modulecalls'] = 'Appels au module de cache';
$lang['cache_halfhour'] = 'Une demi heure';
$lang['cache_1hr'] = 'Une heure';
$lang['cache_2hrs'] = 'Deux heures';
$lang['cache_6hrs'] = 'Six heures';
$lang['cache_12hrs'] = 'Douze heures';
$lang['cache_24hrs'] = 'Un jour';
$lang['cache_noexpiry'] = 'N&#039;expire pas (utiliser avec prudence)';
$lang['cache_filelock'] = 'Verrouiller les fichiers pour pr&eacute;venir des &eacute;tats de concurrence&nbsp;';
$lang['cache_autoclean'] = 'Supprimer automatiquement les fichiers cache p&eacute;rim&eacute;s&nbsp;';
$lang['cache_lifetime'] = 'Dur&eacute;e de vie du cache (en secondes)&nbsp;';
$lang['cache_settings'] = 'R&eacute;glages du cache';
$lang['error_image_transform'] = 'Erreur de transformation d&#039;image';
$lang['prompt_delete_orig_image'] = 'Supprimer l&#039;image d&#039;origine apr&egrave;s le redimensionnement et le tatouage ?';
$lang['info_imageextensions'] = 'Sp&eacute;cifiez, une liste d&eacute;limit&eacute;e par des virgules, des extensions de fichiers images d&eacute;sign&eacute;s convenables pour le redimensionnement, tatouage, et cr&eacute;ation de vignettes. <strong>Remarque :</strong> les modules qui utilisent les capacit&eacute;s d&#039;upload CGExtensions peuvent remplacer ces param&egrave;tres.';
$lang['allowed_upload_filetypes'] = 'Extensions de fichiers qui peuvent &ecirc;tre t&eacute;l&eacute;charg&eacute;s&nbsp;';
$lang['info_allowed_upload_filetypes'] = 'Sp&eacute;cifiez, une liste d&eacute;limit&eacute;e par des virgules, des extensions de fichier pouvant &ecirc;tre t&eacute;l&eacute;charg&eacute;. <strong>Remarque :</strong> les modules qui utilisent les capacit&eacute;s d&#039;upload CGExtensions peuvent remplacer ces param&egrave;tres.';
$lang['resize_image_to'] = 'Dimension maximale de l&#039;image redimensionn&eacute;e&nbsp;';
$lang['resizing'] = 'Redimensionnement de l&#039;image&nbsp;';
$lang['prompt_allow_resizing'] = 'Redimensionner les images t&eacute;l&eacute;charg&eacute;es ?';
$lang['thumbnailing'] = 'Cr&eacute;ation de vignettes&nbsp;';
$lang['prompt_allow_thumbnailing'] = 'Cr&eacute;er des vignettes &agrave; partir d&#039;images t&eacute;l&eacute;charg&eacute;es ?';
$lang['info_graphicssettings'] = 'Cet onglet permet de configurer le comportement par d&eacute;faut de modules qui CGExtensions utiliser des fonctionnalit&eacute;s pour le t&eacute;l&eacute;chargement des images. La fonctionnalit&eacute; comprend le redimensionnement automatique d&#039;image d&#039;entr&eacute;e, le tatouage, et 
la cr&eacute;ation de vignettes.';
$lang['prompt_allow_watermarking'] = 'Tatouage des images t&eacute;l&eacute;charg&eacute;es ?';
$lang['info_sysdefault_templates'] = 'Ce gabarit d&eacute;finit le contenu par d&eacute;faut du gabarit-mod&egrave;le lorsque vous cr&eacute;ez un nouveau mod&egrave;le du type appropri&eacute;. Les ajustements du contenu de ce gabarit n&#039;auront pas d&#039;effet imm&eacute;diat sur votre site web';
$lang['available'] = 'Disponible';
$lang['selected'] = 'Selectionn&eacute;';
$lang['up'] = 'Vers le haut';
$lang['down'] = 'Vers le bas';
$lang['sortablelist_templates'] = 'Liste de tri des gabarits&nbsp;';
$lang['default_templates'] = 'Gabarits par d&eacute;faut';
$lang['sysdflt_sortablelist_template'] = 'Syst&egrave;me de tri par d&eacute;faut des listes de gabarits';
$lang['info_sysdefault_template'] = 'Le syst&egrave;me de mod&egrave;les par d&eacute;faut est utilis&eacute; lors de la cr&eacute;ation d&#039;un nouveau mod&egrave;le d&#039;un certain type. La Modification de la valeur a uniquement des effets lorsque vous cr&eacute;ez un nouveau mod&egrave;le dans un autre onglet';
$lang['watermarkerror_1000'] = 'Le tatouage num&eacute;rique n&#039;est pas configur&eacute; correctement';
$lang['watermarkerror_1001'] = 'Fichier sp&eacute;cifi&eacute; incorrect ou corrompu pour le tatouage';
$lang['watermarkerror_1002'] = 'Type de fichier non autoris&eacute;';
$lang['watermarkerror_1003'] = 'Aucun fichier sp&eacute;cifi&eacute; pour le tatouage';
$lang['watermarkerror_1004'] = 'Probl&egrave;me lors de la cr&eacute;ation du filigrane image';
$lang['watermarkerror_1005'] = 'Probl&egrave;me de chargement d&#039;image pour le tatouage';
$lang['watermarkerror_1006'] = 'Autre erreur';
$lang['translucency'] = 'Translucidit&eacute;';
$lang['watermark_alignment'] = 'Alignez tous les filigranes dans cette position relative';
$lang['align_ul'] = 'En haut &agrave; gauche';
$lang['align_uc'] = 'En haut centr&eacute;';
$lang['align_ur'] = 'En haut &agrave; droite';
$lang['align_ml'] = 'Au milieu &agrave; gauche';
$lang['align_mc'] = 'Centr&eacute;';
$lang['align_mr'] = 'Au milieu &agrave;droite';
$lang['align_ll'] = 'En bas &agrave; gauche';
$lang['align_lc'] = 'En bas centr&eacute;';
$lang['align_lr'] = 'En bas &agrave; droite';
$lang['use_transparency'] = 'Utiliser la transparence';
$lang['background_color'] = 'Couleur d&#039;arri&egrave;re-plan';
$lang['none'] = 'Aucun';
$lang['image'] = 'Image&nbsp;';
$lang['text_color'] = 'Couleur du texte';
$lang['rgb_colors'] = '#F0F8FF-AliceBlue,
#FAEBD7-AntiqueWhite,
#00FFFF-Aqua,
#7FFFD4-Aquamarine,
#F0FFFF-Azure,
#F5F5DC-Beige,
#FFE4C4-Bisque,
#FFEBCD-BlanchedAlmond,
#000000-Black,
#0000FF-Blue,
#8A2BE2-BlueViolet,
#A52A2A-Brown,
#DEB887-BurlyWood,
#5F9EA0-CadetBlue,
#7FFF00-Chartreuse,
#D2691E-Chocolate,
#FF7F50-Coral,
#6495ED-CornflowerBlue,
#FFF8DC-Cornsilk,
#DC143C-Crimson,
#00FFFF-Cyan,
#00008B-DarkBlue,
#008B8B-DarkCyan,
#B8860B-DarkGoldenRod,
#A9A9A9-DarkGray,
#006400-DarkGreen,
#BDB76B-DarkKhaki,
#8B008B-DarkMagenta,
#556B2F-DarkOliveGreen,
#FF8C00-Darkorange,
#9932CC-DarkOrchid,
#8B0000-DarkRed,
#E9967A-DarkSalmon,
#8FBC8F-DarkSeaGreen,
#483D8B-DarkSlateBlue,
#2F4F4F-DarkSlateGray,
#00CED1-DarkTurquoise,
#9400D3-DarkViolet,
#FF1493-DeepPink,
#00BFFF-DeepSkyBlue,
#696969-DimGray,
#1E90FF-DodgerBlue,
#D19275-Feldspar,
#B22222-FireBrick,
#FFFAF0-FloralWhite,
#228B22-ForestGreen,
#FF00FF-Fuchsia,
#DCDCDC-Gainsboro,
#F8F8FF-GhostWhite,
#FFD700-Gold,
#DAA520-GoldenRod,
#808080-Gray,
#008000-Green,
#ADFF2F-GreenYellow,
#F0FFF0-HoneyDew,
#FF69B4-HotPink,
#CD5C5C-IndianRed,
#4B0082-Indigo,
#FFFFF0-Ivory,
#F0E68C-Khaki,
#E6E6FA-Lavender,
#FFF0F5-LavenderBlush,
#7CFC00-LawnGreen,
#FFFACD-LemonChiffon,
#ADD8E6-LightBlue,
#F08080-LightCoral,
#E0FFFF-LightCyan,
#FAFAD2-LightGoldenRodYellow,
#D3D3D3-LightGrey,
#90EE90-LightGreen,
#FFB6C1-LightPink,
#FFA07A-LightSalmon,
#20B2AA-LightSeaGreen,
#87CEFA-LightSkyBlue,
#8470FF-LightSlateBlue,
#778899-LightSlateGray,
#B0C4DE-LightSteelBlue,
#FFFFE0-LightYellow,
#00FF00-Lime,
#32CD32-LimeGreen,
#FAF0E6-Linen,
#FF00FF-Magenta,
#800000-Maroon,
#66CDAA-MediumAquaMarine,
#0000CD-MediumBlue,
#BA55D3-MediumOrchid,
#9370D8-MediumPurple,
#3CB371-MediumSeaGreen,
#7B68EE-MediumSlateBlue,
#00FA9A-MediumSpringGreen,
#48D1CC-MediumTurquoise,
#C71585-MediumVioletRed,
#191970-MidnightBlue,
#F5FFFA-MintCream,
#FFE4E1-MistyRose,
#FFE4B5-Moccasin,
#FFDEAD-NavajoWhite,
#000080-Navy,
#FDF5E6-OldLace,
#808000-Olive,
#6B8E23-OliveDrab,
#FFA500-Orange,
#FF4500-OrangeRed,
#DA70D6-Orchid,
#EEE8AA-PaleGoldenRod,
#98FB98-PaleGreen,
#AFEEEE-PaleTurquoise,
#D87093-PaleVioletRed,
#FFEFD5-PapayaWhip,
#FFDAB9-PeachPuff,
#CD853F-Peru,
#FFC0CB-Pink,
#DDA0DD-Plum,
#B0E0E6-PowderBlue,
#800080-Purple,
#FF0000-Red,
#BC8F8F-RosyBrown,
#4169E1-RoyalBlue,
#8B4513-SaddleBrown,
#FA8072-Salmon,
#F4A460-SandyBrown,
#2E8B57-SeaGreen,
#FFF5EE-SeaShell,
#A0522D-Sienna,
#C0C0C0-Silver,
#87CEEB-SkyBlue,
#6A5ACD-SlateBlue,
#708090-SlateGray,
#FFFAFA-Snow,
#00FF7F-SpringGreen,
#4682B4-SteelBlue,
#D2B48C-Tan,
#008080-Teal,
#D8BFD8-Thistle,
#FF6347-Tomato,
#40E0D0-Turquoise,
#EE82EE-Violet,
#D02090-VioletRed,
#F5DEB3-Wheat,
#FFFFFF-White,
#F5F5F5-WhiteSmoke,
#FFFF00-Yellow,
#9ACD32-YellowGreen';
$lang['info_watermarks'] = 'Le tatouage est une m&eacute;thode pour pr&eacute;venir le vol d&#039;image. Une image ou un texte sp&eacute;cifi&eacute; est superpos&eacute;e sur le dessus de l&#039;image t&eacute;l&eacute;charg&eacute;e. Si un filigrane graphique n&#039;est pas sp&eacute;cifi&eacute;, ou ne peut pas &ecirc;tre trouv&eacute;, et si le texte et les param&egrave;tres sont d&eacute;finis, ils seront utilis&eacute;s pour le tatouage d&#039;images';
$lang['text_watermarks'] = 'Texte de filigranes&nbsp;';
$lang['graphic_watermarks'] = 'Filigrane graphique&nbsp;';
$lang['watermarking'] = 'Tatouage num&eacute;rique&nbsp;';
$lang['watermark_text'] = 'Texte en filigrane';
$lang['font'] = 'Police';
$lang['font_size'] = 'Taille du texte';
$lang['text_angle'] = 'Angle du texte';
$lang['general_settings'] = 'Param&egrave;tres g&eacute;n&eacute;raux';
$lang['graphics_settings'] = 'Param&egrave;tres graphiques';
$lang['CGFILEUPLOAD_NOFILE'] = 'Aucun fichier upload&eacute; r&eacute;pondant aux sp&eacute;cifications';
$lang['CGFILEUPLOAD_FILESIZE'] = 'La taille du fichier uploader exc&egrave;de le maximun autoris&eacute;';
$lang['CGFILEUPLOAD_FILETYPE'] = 'Les fichiers de ce type ne peuvent &ecirc;tre upload&eacute;s';
$lang['CGFILEUPLOAD_FILEEXISTS'] = 'Un fichier du m&ecirc;me nom existe d&eacute;j&agrave;';
$lang['CGFILEUPLOAD_BADDESTDIR'] = 'Le dossier de destination sp&eacute;cifi&eacute; pour l&#039;upload n&#039;existe pas';
$lang['CGFILEUPLOAD_BADPERMS'] = 'Les permissions sur les fichiers n&#039;autorisent pas l&#039;upload vers le dossier de destination';
$lang['CGFILEUPLOAD_MOVEFAILED'] = 'Impossible de d&eacute;placer le fichier vers sa destination';
$lang['CGFILEUPLOAD_PREPROCESSING_FAILED'] = 'Le pr&eacute;-traitement de l&#039;upload du fichier n&#039;a pas fonctionn&eacute;';
$lang['thumbnail_size'] = 'Taille des vignettes&nbsp;';
$lang['image_extensions'] = 'Extensions des fichiers image&nbsp;';
$lang['group'] = 'Groupe';
$lang['template'] = 'Gabarit&nbsp;';
$lang['select_one'] = 'S&eacute;lectionner un';
$lang['priority_countries'] = 'Priorit&eacute; du pays&nbsp;';
$lang['prompt_edittemplate'] = '&Eacute;diter le gabarit';
$lang['prompt_deletetemplate'] = 'Supprimer le gabarit';
$lang['prompt_templatename'] = 'Nom du gabarit&nbsp;';
$lang['prompt_template'] = 'Texte du gabarit&nbsp;';
$lang['prompt_name'] = 'Nom du gabarit';
$lang['prompt_newtemplate'] = 'Nouveau gabarit';
$lang['prompt_default'] = 'Par d&eacute;faut';
$lang['yes'] = 'Oui';
$lang['no'] = 'Non';
$lang['submit'] = 'Soumettre';
$lang['apply'] = 'Appliquer';
$lang['cancel'] = 'Annuler';
$lang['edit'] = '&Eacute;diter';
$lang['areyousure'] = '&Ecirc;tes-vous s&ucirc;r ?';
$lang['resettofactory'] = 'R&eacute;initialiser aux valeurs par d&eacute;faut';
$lang['error_template'] = 'Gabarit  d&#039;erreur&nbsp;';
$lang['error_templatenameexists'] = 'Il y a d&eacute;j&agrave; un gabarit du m&ecirc;me nom';
$lang['friendlyname'] = 'Extensions de modules (CG)';
$lang['postinstall'] = 'Ce module est pr&ecirc;t &agrave; l&#039;emploi. Codez !';
$lang['postuninstall'] = 'A bient&ocirc;t';
$lang['uninstalled'] = 'Module d&eacute;sinstall&eacute;.';
$lang['installed'] = 'La version %s a &eacute;t&eacute; install&eacute;e.';
$lang['prefsupdated'] = 'Les pr&eacute;f&eacute;rences du module ont &eacute;t&eacute; mises &agrave; jour.';
$lang['accessdenied'] = 'Acc&egrave;s refus&eacute;. Veuillez v&eacute;rifier vos permissions.';
$lang['error'] = 'Erreur !';
$lang['upgraded'] = 'Le module a &eacute;t&eacute; mis &agrave; jour &agrave; la version %s.';
$lang['moddescription'] = 'Ce module est une librarie de classes php utilis&eacute;es pour cr&eacute;er des formulaires complexes';
$lang['help'] = '<h3>Que fait ce module ?</h3>
<p>Ce module fournit une API, des formulaires et des tags smarty &agrave; utiliser dans d&#039;autres modules.  Si vous n&#039;&ecirc;tes pas un programmeur, vous n&#039;aurez certianement rien &agrave; faire avec ce module, bien qu&#039;il soit indispensable au bon fonctionnement d&#039;autres modules (d&eacute;pendences).</p>
<h3 style=&quot;color: #f00;&quot;>Notes</h3>
<p>Many modules take advantages of the forms that are provided by the CGExtensions module to assist in managing templates.  When they do, the CGExtensions module information is displayed prominently.  However when you submit, or cancel from these forms you will be returned to the original module.</p>
<h3>How Do I Use It</h3>
<p>Well, you start your own module (I suggest starting with the Skeleton module), and then when you need to use an advanced form object from this library, simply make your module dependant upon FormObjects, and then instantiate an object of the appropriate type.  See the code inside the FormObjects directory for usage instructions.</p>
<h3>Smarty Addons</h3>
<p>This module adds a few smarty conveniences for use with other modules. They are listed and described here:</p>
<ul>
<li><u>cgerror - <em>block</em> plugin</u>
<p>Description: This block plugin uses the error template (configurable from the CGExtensions admin interface) to display an error message.</p>
<p>optional parameters: &#039;errorclass&#039; = override the default class name in the template.</p>
<p>i.e: <code>{cgerror}This is error text{/cgerror}</code><br/>
    or: <code>{cgerror}{$errortextvar}{/cgerror}</br>
</p>
</li>
<li><u>{cge_isbot [assign=name]}</u> - <em>function</em> plugin
<p>Description: A plugin to detect wether the request is from a robot.<p>
<p>i.e: <code>{cg_isbot assign=&#039;isbot&#039;}{if $isbot}&amp;lt;h3&amp;gt;You are a bot&amp;lt;/h3&amp;gt;{/if}</code></p>
</li>
<li><u>{cge_is_smartphone [assign=name]}</u> - <em>function</em> plugin
<p>Description: A plugin to detect wether the request is from a smart phone such as an iphone or android.<p>
<p>i.e: <code>{cg_is_smartphone assign=&#039;isbot&#039;}{if $isbot}&amp;lt;h3&amp;gt;I should do some funky mobile styling here.&amp;lt;/h3&amp;gt;{/if}</code></p>
</li>
<li><u>cge_state_options - <em>function</em> plugin</u>
<p>Description: Output a set of &amp;lt;option&amp;gt; tags for states.  The values are US/Canada State/Province abbreviations, the labels are the full length names in english.  This method reads the defined state list as defined in the database.</p>
<p>i.e: <code>&amp;lt;select name=&quot;foo&quot;&amp;gt;{cge_state_options selected=&amp;quot;ab&amp;quot;}&amp;lt;/select&amp;gt;</code></p>
</li>
<li><u>cge_country_options - <em>block</em> plugin</u>
<p>Description: Output a set of &amp;lt;options&amp;gt; tags for countries.  The values are approved country codes, the labels are the full length names (in english).  This method reads the country list as defined in the database, and takes into account the priority countries as defined in the CGExtensions admin console.</p>
<p>i.e: <code>&amp;lt;select name=&amp;quot;foo&amp;quot;{cge_country_options selected=&amp;quot;us&amp;quot;}&amp;lt;/select&amp;gt;</code></p>
</li>
<li><u>get_current_url - <em>function</em> plugin</u>
<p>Description: Return the current page url.</p>
<p>Optional Parameters: &#039;assign&#039; = assign the output to the named smarty variable.</p>
<p>i.e: <code>{get_current_url assign=&amp;quot;cur_url&amp;quot;}{$cur_url}</code></p>
</li>
<li><u>cge_yesno_options - <em>function</em> plugin</u>
<p>Description: Output options for a dropdown list that allows selecting two options, &amp;quot;Yes&amp;quot; or &amp;quot;No&amp;quot;.  This plugin will output the &amp;lt;option&amp;gt tags using localized strings for the labels, and integers for the values.</p>
<p>Optional Parameters:
  <ul>
    <li>&amp;quot;prefix&amp;quot; - A prefix to place before the name attribute on the tag.  i.e: prefix=$actionid</li>
    <li>&amp;quot;name&amp;quot; - A name for the select list, if this parameter is specified the system will generate a complete &amp;lt;select&amp;gt; tag.  Otherwise, only &amp;lt;option&amp;gt; tags will be generated.</li>
    <li>&amp;quot;selected&amp;quot; - The value of the currently selected element (either 0 or 1)</li>
    <li>&amp;quot;assign&amp;quot; - Assign the output html code to a newly generated smarty variable.</li>
  </ul>
</p>
<br/>
<p>i.e: <code>{cge_yesno_options prefix=\$actionid name=&amp;quot;send_mail&amp;quot; selected=$send_mail}</code></p>
</li>
<li><u>cge_have_module - <em>function</em> plugin</u>
  <p>Description: Output a boolean (0 or 1) value if a module is installed and ready to use.</p>
  <p>Optional Parameters:
     <ul>
       <li>&amp;quot;m&amp;quot;|&amp;quot;mod&amp;quot;|&amp;quot;module&amp;quot; - Specify the module name</lI>
       <li>&amp;quot;assign&amp;quot; - Assign the output html code to a newly generated smarty variable.</li>
     </ul>
  </p>
<br/>
<p>i.e: <code>{cge_have_module module=&amp;quot;FrontEndUsers&amp;quot assign=&amp;quot;have_feu&amp;quot;}</code></p>
</li>
<li><u>cgimage - <em>function</em> plugin</u>
  <p>Description: Output an image tag, This plugin is typically used in admin templates, as it automatically searches in the admin theme, and in registered icon directories.</p>
  <p>Required Parameters:
    <ul>
      <li>&amp;quot;image&amp;quot; - The filename of the image.  You may specify a filename, or a path relative to the admin theme&amp;quot;s images directory.</li>
    </ul>
  </p>
  <br/>
  <p>Optional Parameters:
    <ul>
      <li>&amp;quot;alt&amp;quot; - Specify alt text for the image.  If not specified, the value of the image parameter will be used.</li>
      <li>&amp;quot;class&amp;quot; - Specify a class for the image tag.</li>
      <li>&amp;quot;width&amp;quot; - Specify an integer width for the image tag.</li>
      <li>&amp;quot;height&amp;quot; - Specify an integer height for the image tag.</li>
      <li>&amp;quot;assign&amp;quot; - Assign the output html code to a newly generated smarty variable.</li>
    </ul>
  </p>
  <br/>
  <p>See also:  CGExtensions->AddImageDir()</p>
  <p>i.e: <code>{cgimage image=&amp;quot;icons/system/newobject.gif&amp;quot;}</code></p>
</li>
<li><u>rfc_date - <em>modifier</em> plugin</u>
<p>Description: Format a supplied time in an RFC consistent manner.  This modifier is particularly useful when generating RSS feeds.</p>
<p>i.e: <code>{$smarty.now|rfc_date}</code></p>
</li>
<li><u>jsmin - <em>block</em> plugin</u>
  <p>Description: Pass content through the javascript minifier.</p>
  <p>Note: You must specify the approprate {literal},{/literal},{ldelim|, and {rdelim} inside the block to allow smarty to process or ignore the code.</p>
  <p>i.e:  <code>{jsmin}&amp;lt;script type=&quot;text/javascript&quot;&amp;gt;// alot of javascript code here&amp;lt;/script&amp;gt;{/jsmin}</code></p>
</li>
<li><u>cge_textarea - <em>block</em> plugin</u>
  <p>Description: Create a text area tag, with optional support for wysiwyg editor.  This tag is typically used in admin templates to create text areas.</p>
  <p>Required Parameters:
    <ul>
      <li>&amp;quot;prefix&amp;quot; - A string to prefix the textarea element name.  i.e: {$actionid}</li>
      <li>&amp;quot;name&amp;quot; - The element name.</li>
    </ul>
  </p>
  <br/>
  <p>Optional Parameters:
    <ul>
      <li>&amp;quot;wysiwyg&amp;quot; - An integer value to indicate wether a wysiwyg should be applied (the actual wysiwyg that is used depends on CMSMS site preferrences and user preferences.</li>
      <li>&amp;quot;content&amp;quot; - The content for the text area.</li>
      <li>&amp;quot;class&amp;quot; - An optional class to supply to the text area tag.</li>
      <li>&amp;quot;assign&amp;quot; - Assign the output html code to a newly generated smarty variable.</li>
    </ul>
  </p>
  <br/>
  <p>i.e: <code>{cge_textarea prefix=$actionid name=&amp;quot;description&amp;quot; content=$description wysiwyg=1}</code></p>
</li>
<li><u>cge_str_to_assoc - <em>function</em> plugin</u>
  <p>Description: Convert url parameter type string to an associative array.</p>
  <p>Required Parameters:
    <ul>
      <li>&amp;quot;input&amp;quot; - The input string</li>
    </ul>
  </p>
  <br/>
  <p>Optional Parameters:
    <ul>
      <li>&amp;quot;delim1&amp;quot; - Delimiter for separating the string into a list of variables.  Defaults to &amp;quot;,&amp;quot;</li>
      <li>&amp;quot;delim2&amp;quot; - Delimiter for separating variable into a variable name and value.  Defaults to &amp;quot;=&amp;quot;</li>
      <li>&amp;quot;assign&amp;quot; - Assign the output html code to a newly generated smarty variable.</li>
    </ul>
  </p>
  <br/>
  <p>i.e: <code>{cge_str_to_assoc input=&amp;quot;var1=val1,var2=val2,var3=val3&amp;quot; assign=&amp;quot;tmp&amp;quot;}</code></p>
</li>
<li><u>cge_cache - <em>block</em> plugin</u>
  <p>Description: Cache html outout between start and end blocks for performance. By default content between the start and end tags is cached to files in the tmp/cache directory for a period of five minutes.  Later versions of this plugin will allow extending the cache lifetime.</p>
  <p><strong>Note:</strong> This is not technically a block plugin, but does behave like one.</p>
  <p><strong>Note:</strong> This is an advanced plugin that can dramatically improve the average performance of your (primarily static) website, though it should be used with caution as using it incorrectly can cause strange behaviour on your site.  This functionality works best when wrapped around smarty tags that query the database and generate static html content.  This plugin should not be used around dynamic functionality or forms.</p>
  <p><strong>Note:</strong> This plugin utilizes file locking to prevent race conditions.  This may present problems on different platforms.  Use this plugin with caution.</p>
  <pp>i.e: <code>{cge_cache}{Products}{/cge_cache}</code></p>
</li>
</ul>
<h3>Support</h3>
<p>This module does not include commercial support. However, there are a number of resources available to help you with it:</p>
<ul>
<li>For the latest version of this module, FAQs, or to file a Bug Report or buy commercial support, please visit the cms development forge at <a href=\"http://dev.cmsmadesimple.org\">dev.cmsmadesimple.org</a>.</li>
<li>Additional discussion of this module may also be found in the <a href=\"http://forum.cmsmadesimple.org\">CMS Made Simple Forums</a>.</li>
<li>The author(s), calguy et all can often be found in the <a href=\"irc://irc.freenode.net/#cms\">CMS IRC Channel</a>.</li>
<li>Lastly, you may have some success emailing the author(s) directly.</li>  
</ul>
<p>As per the GPL, this software is provided as-is. Please read the text
of the license for the full disclaimer.</p>

<h3>Copyright and License</h3>
<p>Copyright &amp;copy; 2008, Robert Campbel <a href=\"mailto:calguy1000@cmsmadesimple.org\">&amp;lt;calguy1000@cmsmadesimple.org&amp;gt;</a>. All Rights Are Reserved.</p>
<p>This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.</p>
<p>However, as a special exception to the GPL, this software is distributed
as an addon module to CMS Made Simple.  You may not use this software
in any Non GPL version of CMS Made simple, or in any version of CMS
Made simple that does not indicate clearly and obviously in its admin 
section that the site was built with CMS Made simple.</p>
<p>This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
Or read it <a href=\"http://www.gnu.org/licenses/licenses.html#GPL\">online</a></p>';
?>