<?php
/*
    Class: DLComments
        Provides an interface for submitting comments to a page.

    About: Author
        Duc Tri Le <cmsmadesimple---at---email.tiger-inc.com>

    About: License
        This class is released under the GNU General Public License.

    About: Changelog
        * 1.0 (April 17, 2009): Added option to disable CAPTCHA. Made the css
            and template editing textareas higher. Fixed bug that coused error
            in the module settings when message icons were used. (Kazimierz
            Król)
        * 1.0RC2 (December 12, 2008): Switched comments to NaturalDocs and moved
            methods back into file. Hence, the method __call is removed. Fixed
            bug with the display of the CSS not showing another CSS template.
            Changed the way some data are stored in the database.
        * 1.0RC1 (August 15, 2008): Added the ability to auto approve comments
            and sending an e-mail to let you know a comment was submitted.
        * 0.3 (May 30, 2008): Second try at bug fix for Module Manager.
        * 0.2 (May 30, 2008): Fixed bug when installing via Module Manager.
        * 0.1 (May 16, 2008): Initial release.
        * 0.0 (April 10, 2008): Started.
*/
class DLComments extends CMSModule {
    /*
        Group: Data

        Boolean: $get_groups
            A boolean specifiying whether or not we should connect to the
            database to retrieve the current list of comment groups or use what
            is in the cache.
    */
    protected $get_groups = TRUE;

    /*
        Group: Class Construction

        Constructor: __construct
            Create a new instance of DLComments. This will also register this
            class as a plugin.

        Returns:
            (DLComments) An instance of DLComments.
    */
    public function __construct() {
        // Call the constructor of the parent
        parent::__construct();

        // Register this module to smarty
        $this->RegisterModulePlugin();
    }

    /*
        Group: Override Methods

        Methods:
            AllowAutoInstall     - Whether or not an auto install is allowed.
            AllowAutoUpgrade     - Whether or not an auto upgrade is allowed.
            GetAbout             - Get about information.
            GetAdminSection      - Get the admin section this module belongs to.
            GetAuthor            - Get the author.
            GetAuthorEmail       - Get the author e-mail address.
            GetChangeLog         - Get the changelog.
            GetDependencies      - Get other modules depended by this module.
            GetDescription       - Get a description of module.
            GetFriendlyName      - Get module friendly name.
            GetHelp              - Get help information.
            GetName              - Get module name.
            GetParameters        - Get parameters.
            GetVersion           - Get version number of module.
            HasAdmin             - Whether or not module has admin panel.
            InstallPostMessage   - Message to be displayed after installation.
            IsPluginModule       - Whether or not this is a plugin module.
            MinimumCMSVersion    - Minimum CMS version to run this module.
            UninstallPostMessage - Message to be displayed after uninstall.
            UninstallPreMessage  - Message to be alerted before uninstall.
            VisibileToAdminUser  - Privilege checking.
    */
    function AllowAutoInstall() { return FALSE; }
    function AllowAutoUpgrade() { return FALSE; }
    function GetAbout() { return $this->Lang('about'); }
    function GetAdminSection() { return 'content'; }
    function GetAuthor() { return 'Duc Tri Le'; }
    function GetAuthorEmail() { return 'cmsmadesimple@email.tiger-inc.com'; }
    function GetChangeLog() { return $this->Lang('changelog'); }
    function GetDependencies() { return array('DLSupport' => '2.0', 'CMSMailer' => '1.73.14'); }
    function GetDescription() { return $this->Lang('about'); }
    function GetFriendlyName() { return 'DL Suite: Comments'; }
    function GetHelp() { return $this->Lang('help'); }
    function GetName() { return __CLASS__; }
    function GetParameters() { return array(); }
    function GetVersion() { return '1.0'; }
    function HasAdmin() { return TRUE; }
    function InstallPostMessage() { return $this->Lang('postinstall'); }
    function IsPluginModule() { return TRUE; }
    function MinimumCMSVersion() { return '1.5.1'; }
    function UninstallPostMessage() { return $this->Lang('postuninstall'); }
    function UninstallPreMessage() { return $this->Lang('preuninstall'); }
    function VisibleToAdminUser() { return $this->CheckPermission('DL Suite: Comments'); }

    /*
        Group: Module Specific

        Method: GetCommentsGroups
            Retrieve all the comment groups currently in the database. This will
            try to retrieve the information from cache to prevent many
            connections to the database. If you need to force this to read from
            the database, be sure to set the member data $get_groups to TRUE.

        Parameters:
            $htmlentities - (boolean) Optional and defaults to FALSE. If this is
                set to TRUE, then the comment groups value will be passed
                through the function "htmlentities", otherwise, it won't.

        Returns:
            (array) An array containing all of the comment groups.
    */
    protected function GetCommentsGroups($htmlentities = FALSE) {
        // Cache
        static $result1, $result2;
        static $sql_tpt = 'SELECT DISTINCT `group` FROM %smodule_dlcomments ORDER BY `group` ASC;';

        // Retrieve comment groups from database if it is the first time or if
        // we are forced to read from database, otherwise, reads from cache
        if(!is_array($result1) || $this->get_groups) {
            // Set flag so that the next time this reads from cache
            $this->get_groups = FALSE;

            // Get the database object
            $db =& $this->GetDb();

            // Create the SQL for retrieving all of the comments groups
            $sql = sprintf($sql_tpt, cms_db_prefix());

            // Now get all of the comments
            $db->SetFetchMode(ADODB_FETCH_ASSOC);
            $result1 = $db->GetCol($sql);

            // Pass the values through htmlentities
            $result2 = array();
            foreach($result1 as $item) { $result2[] = htmlentities($item); }
        }

        return $htmlentities ? $result2 : $result1;
    }

    /*
        Method: GetCommentsListing
            Retrieve various information regarding the listing of the comments.

        Parameters:
            $id - (numeric) The ID given to this module upon execution.
            $returnid - (string) The ID of the page to return to when the
                required action is completed. An empty string means that it is
                just an internal page on the admin site whereas any numeric
                number is the ID of a frontend page.
            $params - (array) An array containing various user inputs.

        Returns:
            (array) An array containing the various results generated by this
            method.
    */
    protected function GetCommentsListing($id, $returnid, $params) {
        // Response array to be sent back via JSON
        $result = array( 'success' => FALSE, 'hide_html_area' => FALSE, 'message' => '', 'html' => '');

        // Get user input
        $group = DLSupport::SanitizeString($params['group']);
        $type  = DLSupport::SanitizeString($params['type']);

        // Get all the comment groups
        $groups = $this->GetCommentsGroups();
        array_unshift($groups, 'Show All');

        // Validate input
        if(!in_array($group, $groups)) {
            $result['message'] = $this->GetIcon('remove', $this->Lang('error_message').': ').$this->Lang('failure_group');
            return $result;
        }
        if(!in_array($type, array('approval', 'modify'))) {
            $result['message'] = $this->GetIcon('remove', $this->Lang('error_message').': ').$this->Lang('failure_type');
            return $result;
        }

        // Get the database object
        $db =& $this->GetDb();

        // Create the SQL for retrieving all of the comments
        $tpt = '
            SELECT `id`, `group`, `user`, `comment` FROM %smodule_dlcomments
            WHERE `approved` = %s'.($group == 'Show All' ? '' : ' AND `group` LIKE "%s"').'
            ORDER BY `posted_date` ASC;
        ';
        $sql = sprintf($tpt, cms_db_prefix(), ($type == 'approval' ? 0 : 1), $group);

        // Now get all of the comments
        $db->SetFetchMode(ADODB_FETCH_ASSOC);
        $comments = $db->GetAll($sql) or array();

        // Make sure we got something
        if(count($comments)< 1) {
            $result['success'] = TRUE;
            $result['message'] = $this->GetIcon('warning', $this->Lang('warning_message').': ').$this->Lang('warning_no_comments_'.$type);
            return $result;
        }

        // If we made it here, it was a success
        $result['success'] = TRUE;
        $result['message'] = $this->GetIcon('accept', $this->Lang('success_message').': ').$this->Lang('success_show_'.$type);

        // Now create the checkboxes
        foreach($comments as $key => $comment) {
            $comment['form_checkbox'] = $this->CreateInputCheckbox($id, 'selections[]', $comment['id'], '', 'class="'.$type.'_selections" id="DLComments_checkbox_'.$type.'_'.$comment['id'].'"');
            $comments[$key] = $comment;
        }

        // Form components
        $form_group = $this->CreateInputHidden($id, 'group', $group);
        $form_select_all = $this->CreateInputCheckbox($id, '', '', '-1', 'onchange="DLSupport.checkboxSelectAllToggle(this, \''.$type.'_selections\');"');
        $form_submit = $this->CreateInputSubmit($id, 'submit', $type == 'approval' ? $this->Lang('approve') : $this->Lang('save'), 'onclick="DLSupport.Form.submitValue(this);"');
        $form_remove = $this->CreateInputSubmit($id, 'submit', $this->Lang('remove'), 'onclick="DLSupport.Form.submitValue(this);"');

        // Set up smarty data
        $DLComments = compact('comments', 'form_group', 'form_select_all', 'form_remove', 'form_submit', 'type');
        $this->smarty->assign('DLComments', $DLComments);

        $result['html'] = $this->ProcessTemplate('show_listing.tpl');
        return $result;
    }

    /*
        Method: GetIcon
            A wrapper function for calling "DLSupport::GetIcon" since the
            majority of the icon retrieval will be on the same size.

        Parameters:
            $icon - (string) The filename of the icon to get without its file
                extension. Note that not all icons exist. Be sure to check that
                they exist first.
            $alt - (string) Optional and defaults to an empty string. The text
                to be placed in the "alt" attribute of the IMG tag. If it is not
                given or empty, it will use the $icon value with underscores
                converted to whitespace and the first letter of each word would
                be capitalize.
            $size - (int) Optional and defaults to 32. This is the dimension of
                the icon. Note that not all dimensions exist. Be sure to check
                that the dimension folder you are requesting exist.

        Returns:
            (string) The HTML for the IMG tag with appropriate information for
            displaying the icon.
    */
    protected function GetIcon($icon, $alt = '', $size = 32) {
        return DLSupport::GetIcon($size, $icon, $alt);
    }

    /*
        Method: GetIconFrontend
            Retrieve the icon for the frontend. If there is a preference with a
            value for the given $icon, then this will use that. Otherwise, it
            will use the default icon from DLSupport.

        Parameters:
            $icon - (string) The icon to retrieve.
            $alt - (string) The text that will be in the alt attribute of the
                IMG tag.

        Returns:
            (string) The HTML for the IMG tag with appropriate information for
            displaying the icon.
    */
    protected function GetIconFrontend($icon, $alt) {
        static $tpt = '<img src="%s" alt="%s" />';

        // Make sure we actually want to show the icon
        $result = '';
        if($this->GetPreference('show_icon') == 'Yes') {
            // Get the icon preference
            $result = $this->GetPreference('icon_'.$icon);

            // If it is empty, then we use DLSupport's icon
            if(empty($result)) {
                $icon = $icon == 'success' ? 'accept' : ($icon == 'error' ? 'remove' : 'warning');

                $result = $this->GetIcon($icon, $alt);
            } else {
                $result = sprintf($tpt, $result, $alt);
            }
        }

        return $result;
    }

    /*
        Method: GetSettingsHTML
            Retrieve the HTML for the settings page.

        Parameters:
            $id - (numeric) The ID given to this module upon execution.
            $returnid - (string) The ID of the page to return to when the
                required action is completed. An empty string means that it is
                just an internal page on the admin site whereas any numeric
                number is the ID of a frontend page.
            $params - (array) An array containing various user inputs.

        Returns:
            (string) The HTML for the settings page.
    */
    protected function GetSettingsHTML($id, $returnid, $params) {
        // Get the current settings
        $missing_group    = $this->GetPreference('missing_group');
        $missing_required = $this->GetPreference('missing_required');
        $success_add      = $this->GetPreference('success_add');
        $show_icon        = $this->GetPreference('show_icon');
        $icon_success     = $this->GetPreference('icon_success');
        $icon_warning     = $this->GetPreference('icon_warning');
        $icon_error       = $this->GetPreference('icon_error');
        $auto_approve     = $this->GetPreference('auto_approve');
        $send_email       = $this->GetPreference('send_email');
        $email_address    = $this->GetPreference('email_address');
        $use_captcha      = $this->GetPreference('use_captcha');

        // Form Components
        $form_start = DLSupport::NewFormStart(
            $this, $id, 'updatesettings', $returnid, 'post', array(),
            array("onsubmit=\"return DLComments.submitForm(this, 'settings');\"")
        );
        $form_missing_group = $this->CreateTextarea(FALSE, $id, $missing_group, 'missing_group', 'small');
        $form_missing_required = $this->CreateTextarea(FALSE, $id, $missing_required, 'missing_required', 'small');
        $form_success_add = $this->CreateTextarea(FALSE, $id, $success_add, 'success_add', 'small');
        $form_show_icon = $this->CreateInputDropdown($id, 'show_icon', array($this->Lang('yes') => 'Yes', $this->Lang('no') => 'No'), -1, $show_icon);
        $form_icon_success = $this->CreateInputText($id, 'icon_success', $icon_success);
        $form_icon_warning = $this->CreateInputText($id, 'icon_warning', $icon_warning);
        $form_icon_error = $this->CreateInputText($id, 'icon_error', $icon_error);
        $form_auto_approve = $this->CreateInputDropdown($id, 'auto_approve', array($this->Lang('yes') => 'Yes', $this->Lang('no') => 'No'), -1, $auto_approve);
        $form_use_captcha = $this->CreateInputDropdown($id, 'use_captcha', array($this->Lang('yes') => 'Yes', $this->Lang('no') => 'No'), -1, $use_captcha);
        $form_send_email = $this->CreateInputDropdown($id, 'send_email', array($this->Lang('yes') => 'Yes', $this->Lang('no') => 'No'), -1, $send_email);
        $form_email_address = $this->CreateInputText($id, 'email_address', $email_address);
        $form_submit = $this->CreateInputSubmit($id, 'submit', $this->Lang('submit'), 'onclick="DLSupport.Form.submitValue(this);"');
        $form_end = $this->CreateFormEnd();

        // Images
        $success_image = empty($icon_success) ? $this->GetIcon('accept', $this->Lang('success_image'), 16) : '<img src="'.$icon_success.'" alt="'.$this->Lang('success_image').'" />';
        $warning_image = empty($icon_warning) ? $this->GetIcon('warning', $this->Lang('warning_image'), 16) : '<img src="'.$icon_warning.'" alt="'.$this->Lang('warning_image').'" />';
        $error_image = empty($icon_error) ? $this->GetIcon('remove', $this->Lang('error_image'), 16) : '<img src="'.$icon_error.'" alt="'.$this->Lang('error_image').'" />';

        // Process using Smarty
        $this->smarty->assign('DLComments', compact(
            'form_start', 'form_missing_group', 'form_missing_required', 'form_success_add',
            'form_show_icon', 'form_icon_success', 'form_icon_warning', 'form_icon_error',
            'form_auto_approve', 'form_use_captcha', 'form_send_email', 'form_email_address',
            'form_submit', 'form_end', 'success_image', 'warning_image', 'error_image'
        ));
        $result = $this->ProcessTemplate('show_settings.tpl');

        return $result;
    }

    /*
        Method: GetStoredTemplates
            Retrieve HTML for the listing of the templates.

        Parameters:
            $id - (numeric) The ID given to this module upon execution.
            $returnid - (string) The ID of the page to return to when the
                required action is completed. An empty string means that it is
                just an internal page on the admin site whereas any numeric
                number is the ID of a frontend page.
            $params - (array) An array containing various user inputs.
            $type - (string) The type of template to get the listing for.

        Returns:
            (string) The HTML for the listing of the templates.
    */
    protected function GetStoredTemplates($id, $returnid, $params, $type) {
        // Get the templates information
        $templates = explode('|', $this->GetPreference('list_of_'.$type.'_templates'));
        $default = substr($this->GetPreference('default_'.$type.'_template'), strlen($type)+1);

        // Get the actual value & store it to array
        $yes_icon = $this->GetIcon('accept', $this->Lang('yes'), 16);
        $no_icon = $this->GetIcon('remove', $this->Lang('no'), 16);
        foreach($templates as $key => $template) {
            $value = $this->GetTemplate($type.'_'.$template);
            $tmp = array(
                'default' => ($default == $template) ?  $yes_icon : $no_icon,
                'name'   => cms_htmlentities($template),
                'value ' => $value,

                'form_start' => DLSupport::NewFormStart(
                    $this, $id, 'updatetemplate', $returnid, 'post',
                    array('old_name' => $template),
                    array("onsubmit=\"return DLComments.submitForm(this, '$type');\"")
                ),
                'form_name' => $this->CreateInputText($id, 'name', $template),
                'form_default' => $this->CreateInputCheckbox($id, 'default', 'Yes', ($default == $template) ? 'Yes' : 'No'),
                'form_content' => $this->CreateTextarea(FALSE, $id, $value, 'content', 'big')
            );

            $templates[$key] = $tmp;
        }

        // Form components
        $form_add_start = DLSupport::NewFormStart(
            $this, $id, 'updatetemplate', $returnid, 'post', array(),
            array("onsubmit=\"return DLComments.submitForm(this, '$type');\"")
        );
        $form_add_name = $this->CreateInputText($id, 'name');
        $form_add_default = $this->CreateInputCheckbox($id, 'default', 'Yes');
        $form_add_content = $this->CreateTextarea(FALSE, $id, '', 'content', 'big');
        $form_add_submit = $this->CreateInputSubmit($id, 'submit', $this->Lang('add'), 'onclick="DLSupport.Form.submitValue(this);"');

        $form_remove = $this->CreateInputSubmit($id, 'submit', $this->Lang('remove'), 'onclick="DLSupport.Form.submitValue(this);"');
        $form_save = $this->CreateInputSubmit($id, 'submit', $this->Lang('save'), 'onclick="DLSupport.Form.submitValue(this);"');
        $form_type = $this->CreateInputHidden($id, 'type', $type);
        $form_end = $this->CreateFormEnd();

        // Process using Smarty
        $this->smarty->assign('DLComments', compact('form_add_start', 'form_add_name', 'form_add_default', 'form_add_content', 'form_add_submit', 'form_remove', 'form_save', 'form_type', 'form_end', 'templates', 'type'));
        $result = $this->ProcessTemplate('show_templates.tpl');

        return $result;
    }

    /*
        Method: IncludeAdmin
            Retrieve the HTML for including required JavaScript and CSS on an
            admin page.

        Returns:
            (string) The HTML to be used to include the necessary JavaScript and
            CSS for the admin page.
    */
    protected function IncludeAdmin() {
        // Cache
        static $result;
        static $script_tpt = '<script type="text/javascript" src="%s"></script><link rel="stylesheet" type="text/css" href="%s" />';

        // If we don't have cache data, build the HTML
        if(is_null($result)) {
            // Include the JavaScript from DLSupport
            $result = DLSupport::IncludeJavaScript();

            // Include our JavaScript and CSS
            $result .= sprintf($script_tpt,
                DLSupport::ModuleUrl('DLComments').'/data/dlcomments.js',
                DLSupport::ModuleUrl('DLComments').'/data/admincss.css'
            );
        }

        return $result;
    }

    /*
        Method: IncludeFrontend
            Retrieve the HTML for including required JavaScript and CSS on a
            regular page.

        Returns:
            (string) The HTML to be used to include the necessary JavaScript and
            CSS for the frontend page.
    */
    protected function IncludeFrontend() {
        // cache
        static $result;
        static $script_tpt = '<script type="text/javascript" src="%s"></script>';

        // If we don't have cache data, build the HTML
        if(is_null($result)) {
            // Include the JavaScript from DLSupport
            $result = DLSupport::IncludeJavaScript();
            $result .= sprintf($script_tpt, DLSupport::ModuleUrl('DLComments').'/data/dlcomments.js');
        }

        return $result;
    }

    /*
        Method: ShowFilterArea
            Retrieve the HTML for the filter area on the backend.

        Parameters:
            $id - (numeric) The ID given to this module upon execution.
            $returnid - (string) The ID of the page to return to when the
                required action is completed. An empty string means that it is
                just an internal page on the admin site whereas any numeric
                number is the ID of a frontend page.
            $params - (array) An array containing various user inputs.
            $type - (string) The type of template to get the listing for.

        Returns:
            (string) The HTML for the filter area.
    */
    protected function ShowFilterArea($id, $returnid, $params, $type) {
        // Get user input
        $group = DLSupport::SanitizeString($params['group']);

        // Get all of the comment groups
        $tmp = $this->GetCommentsGroups();
        $groups = array($this->Lang('show_all') => 'Show All');
        foreach($tmp as $item) { $groups[$item] = $item; }

        // Form components
        $form_start = DLSupport::NewFormStart(
            $this, $id, 'showlisting', $returnid, 'post',
            array('type' => $type),
            array("onsubmit=\"return DLComments.submitForm(this, '$type');\"")
        );
        $form_groups = $this->CreateInputDropDown($id, 'group', $groups);
        $form_submit = $this->CreateInputSubmit($id, 'submit', $this->Lang('submit'), 'onclick="DLSupport.Form.submitValue(this);"');
        $form_end = $this->CreateFormEnd();

        // Process using Smarty
        $this->smarty->assign('DLComments', compact('form_start', 'form_groups', 'form_submit', 'form_end'));
        $result = $this->ProcessTemplate('admin_filter_area.tpl');

        return $result;
    }

    /*
        Method: ShowFrontendCSS
            Retrieve the HTML for the frontend CSS inclusion.

        Parameters:
            $id - (numeric) The ID given to this module upon execution.
            $returnid - (string) The ID of the page to return to when the
                required action is completed. An empty string means that it is
                just an internal page on the admin site whereas any numeric
                number is the ID of a frontend page.
            $params - (array) An array containing various user inputs.
            $css - (string) Optional and defaults to NULL. The CSS template to
                retrieve.

        Returns:
            (string) The HTML for the frontend CSS.
    */
    protected function ShowFrontendCSS($css = NULL) {
        // Get all the CSS available
        $templates = explode('|', $this->GetPreference('list_of_css_templates'));

        // Make sure given css exist, if not, use default CSS
        if(!in_array($css, $templates)) {
            $css = substr($this->GetPreference('default_css_template'), 4);
        }

        // Get the full name of the template
        $css = 'css_'.$css;

        // Prepare the HTML
        $result = '<style type="text/css">';
        $result .= $this->ProcessTemplateFromDatabase($css);
        $result .= '</style>';

        return $result;
    }

    /*
        Method: ShowListingArea
            Retrieve the HTML for the listing area on the backend.

        Parameters:
            $id - (numeric) The ID given to this module upon execution.
            $returnid - (string) The ID of the page to return to when the
                required action is completed. An empty string means that it is
                just an internal page on the admin site whereas any numeric
                number is the ID of a frontend page.
            $params - (array) An array containing various user inputs.
            $type - (string) The type of template to get the listing for.

        Returns:
            (string) The HTML for the listing area.
    */
    protected function ShowListingArea($id, $returnid, $params, $type) {
        // Form components
        $form_start = DLSupport::NewFormStart(
            $this, $id, 'updatecomments', $returnid, 'post',
            array('type' => cms_htmlentities($type)),
            array("onsubmit=\"return DLComments.submitForm(this, '$type');\"")
        );
        $form_end = $this->CreateFormEnd();

        // Process using Smarty
        $this->smarty->assign('DLComments', compact('form_start', 'form_end', 'type'));
        $result = $this->ProcessTemplate('admin_listing_area.tpl');

        return $result;
    }

    /*
        Method: ShowSettingsArea
            Retrieve the HTML for the settings area on the backend.

        Parameters:
            $id - (numeric) The ID given to this module upon execution.
            $returnid - (string) The ID of the page to return to when the
                required action is completed. An empty string means that it is
                just an internal page on the admin site whereas any numeric
                number is the ID of a frontend page.
            $params - (array) An array containing various user inputs.

        Returns:
            (string) The HTML for the settings area.
    */
    protected function ShowSettingsArea($id, $returnid, $params) {
        // Get the settings HTML
        $settings = $this->GetSettingsHTML($id, $returnid, $params);

        // Process using Smarty
        $this->smarty->assign('DLComments', compact('settings'));
        $result = $this->ProcessTemplate('admin_settings_area.tpl');

        return $result;
    }

    /*
        Method: ShowSubmissionForm
            Retrieve the HTML for the submission form on the frontend.

        Parameters:
            $id - (numeric) The ID given to this module upon execution.
            $returnid - (string) The ID of the page to return to when the
                required action is completed. An empty string means that it is
                just an internal page on the admin site whereas any numeric
                number is the ID of a frontend page.
            $params - (array) An array containing various user inputs.
            $group - (string) The name of the comment group to submit the
                comment.
            $template - (string) Optional and defaults to NULL. If it is NULL,
                then the default template will be used.

        Returns:
            (string) The HTML for the submission form.
    */
    protected function ShowSubmissionForm($id, $returnid, $params, $group, $template = NULL) {
        // Get all the comments available
        $templates = explode('|', $this->GetPreference('list_of_submission_form_templates'));

        // Make sure given template exist, if not, use default template
        if(!in_array($template, $templates)) {
            $template = substr($this->GetPreference('default_submission_form_template'), 16);
        }

        // Get the full name of the template
        $template = 'submission_form_'.$template;

        // Form components
        $form_start = DLSupport::NewFormStart(
            $this, $id, 'submitcomment', $returnid, 'post',
            array('group' => cms_htmlentities($group)),
            array("onsubmit=\"return DLComments.submitForm(this, 'frontend');\"")
        );
        $form_user = $this->CreateInputText($id, 'user');
        $form_comment = $this->CreateTextarea(FALSE, $id, '', 'comment');
        $form_submit = $this->CreateInputSubmit($id, 'submit', $this->Lang('submit'), 'onclick="DLSupport.Form.submitValue(this);"');
        $form_end = $this->CreateFormEnd();

        // Create captcha
        $use_captcha = $this->GetPreference('use_captcha');
        if($use_captcha == 'Yes') {
          $captcha = DLSupport::Captcha();
          $captcha_image = $captcha['image'];
          $captcha_field = $captcha['field'];
        } else {
          $captcha_image = ''; //the variables shouldn't be undefined even if captcha is not used
          $captcha_field = '';
        }

        // Initial result
        $result = DLComments::IncludeFrontend();

        // Process using Smarty
        $this->smarty->assign('DLComments', compact('form_start', 'form_user', 'form_comment', 'form_submit', 'form_end', 'captcha_image', 'captcha_field', 'use_captcha'));
        $result .= $this->ProcessTemplateFromDatabase($template);

        return $result;
    }

    /*
        Method: ShowTemplateArea
            Retrieve the HTML for the template area.

        Parameters:
            $id - (numeric) The ID given to this module upon execution.
            $returnid - (string) The ID of the page to return to when the
                required action is completed. An empty string means that it is
                just an internal page on the admin site whereas any numeric
                number is the ID of a frontend page.
            $params - (array) An array containing various user inputs.
            $type - (string) The type of template to get the listing for.

        Returns:
            (string) The HTML for the template area.
    */
    protected function ShowTemplateArea($id, $returnid, $params, $type) {
        // Get the templates
        $templates = $this->GetStoredTemplates($id, $returnid, $params, $type);

        // Process using Smarty
        $this->smarty->assign('DLComments', compact('templates', 'type'));
        $result = $this->ProcessTemplate('admin_template_area.tpl');

        return $result;
    }

    /*
        Method: ShowUserComments
            Retrieve the HTML for the user comments.

        Parameters:
            $group - (string) The name of the comment group to submit the
                comment.
            $template - (string) Optional and defaults to NULL. If it is NULL,
                then the default template will be used.

        Returns:
            (string) The HTML for the user comments.
    */
    protected function ShowUserComments($group, $template = NULL) {
        // Get all the templates available
        $templates = explode('|', $this->GetPreference('list_of_comments_templates'));

        // Make sure given template exist, if not, use default template
        if(!in_array($template, $templates)) {
            $template = substr($this->GetPreference('default_comments_template'), 9);
        }

        // Get the full name of the template
        $template = 'comments_'.$template;

        // Get the database object
        $db =& $this->GetDb();

        // Create the SQL for retrieving all of the comments in the given comment group
        $tpt = '
            SELECT `user`, `comment`, `posted_date` FROM %smodule_dlcomments
            WHERE `approved` = 1 AND `group` LIKE "%s"
            ORDER BY `posted_date` ASC;
        ';
        $sql = sprintf($tpt, cms_db_prefix(), $group);

        // Now get all of the comments
        $db->SetFetchMode(ADODB_FETCH_ASSOC);
        $comments = $db->GetAll($sql) or array();

        // Process using Smarty
        $this->smarty->assign('DLComments', compact('comments'));
        $result = $this->ProcessTemplateFromDatabase($template);

        return $result;
    }

    /*
        Group: Upgrades and Degrades

        Method: Degrade
            Undo any upgrades that has been made.

        Parameters:
            $start - (int) The starting degrading method.
            $counter - (int) The number of degrading that needs to be done.
    */
    protected function Degrade($start, $counter) {
        for($i = $start; ($i >= 0) && ($counter > 0); --$i) {
            // Get the degrading metod
            $degrade_method = 'Degrade'.$i;

            // If it exists, degrade
            if(method_exists($this, $degrade_method)) {
                call_user_func(array($this, $degrade_method));
            }

            // Decrement counter
            --$counter;
        }
    }

    /*
        Methods:
            Degrade0 - Degrade from version 1.0RC1 to 0.2.
            Degrade1 - Degrade from version 1.0RC2 to 1.0RC1.
            Degrade2 - Degrade from version 1.0 to 1.0RC2.
    */
    protected function Degrade0() {
        $this->RemovePreference('auto_approve');
        $this->RemovePreference('send_email');
        $this->RemovePreference('email_address');
    }

    protected function Degrade1() {
        $csss = explode('|', $this->GetPreference('list_of_css_templates'));
        $comments = explode('|', $this->GetPreference('list_of_comments_templates'));
        $submission_forms = explode('|', $this->GetPreference('list_of_submission_form_templates'));

        $this->SetPreference('list_of_css_templates', serialize($csss));
        $this->SetPreference('list_of_comments_templates', serialize($comments));
        $this->SetPreference('list_of_submission_form_templates', serialize($submission_forms));
    }

    protected function Degrade2() {
        $this->RemovePreference('use_captcha', 'Yes');
    }

    /*
        Methods:
            Upgrade0 - Upgrade from version 0.2 to 1.0RC1.
            Upgrade1 - Upgrade from version 1.0RC1 to 1.0RC2.
            Upgrade2 - Upgrade from version 1.0RC2 to 1.0.
    */
    protected function Upgrade0() {
        $this->SetPreference('auto_approve', 'No');
        $this->SetPreference('send_email', 'No');
        $this->SetPreference('email_address', '');
    }

    protected function Upgrade1() {
        $csss = unserialize($this->GetPreference('list_of_css_templates'));
        $comments = unserialize($this->GetPreference('list_of_comments_templates'));
        $submission_forms = unserialize($this->GetPreference('list_of_submission_form_templates'));

        $this->SetPreference('list_of_css_templates', implode('|', $csss));
        $this->SetPreference('list_of_comments_templates', implode('|', $comments));
        $this->SetPreference('list_of_submission_form_templates', implode('|', $submission_forms));
    }

    protected function Upgrade2() {
        $this->SetPreference('use_captcha', 'Yes');
    }
}
?>