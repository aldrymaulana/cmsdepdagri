<?php

$sort_order = 0;
$query = "SELECT coalesce(max(javascript_sort_order), 0)+1 as max_sort_order FROM {$this->table_base}javascript;";
$rsMaxOrder = $this->db->Execute($query);

$sort_order = (string)$rsMaxOrder->fields['max_sort_order'];

echo $this->CreateFormStart($id, 'javascript_save', $returnid, 'post', '', false, '', array('save_type' => 'new'));

echo "<table>";

echo "<tr>";
echo "<td valign=\"top\">";
echo $this->CreateLabelForInput($id, 'javascript_name', $this->Lang('name'));
echo "</td>";
echo "<td valign=\"top\">";
echo $this->CreateInputText($id, 'javascript_name', '', '10', '100');
echo "</td>";
echo "</tr>";

echo "<tr>";
echo "<td valign=\"top\">";
echo $this->CreateLabelForInput($id, 'javascript_content', $this->Lang('content'));
echo "</td>";
echo "<td valign=\"top\">";
echo $this->CreateTextArea(false, $id, '', 'javascript_content');
echo "</td>";
echo "</tr>";

echo "<tr>";
echo "<td valign=\"top\">";
echo $this->CreateLabelForInput($id, 'javascript_external_include', $this->Lang('external'));
echo "</td>";
echo "<td valign=\"top\">";
echo $this->CreateInputCheckbox($id, 'javascript_external_include', '1', '0');
echo "</td>";
echo "</tr>";

echo "<tr>";
echo "<td valign=\"top\">";
echo $this->CreateLabelForInput($id, 'javascript_compress', $this->Lang('minify'));
echo "</td>";
echo "<td valign=\"top\">";
echo $this->CreateInputCheckbox($id, 'javascript_compress', '1', '1');
echo "</td>";
echo "</tr>";

echo "<tr>";
echo "<td valign=\"top\">";
echo $this->CreateLabelForInput($id, 'javascript_pack', $this->Lang('pack'));
echo "</td>";
echo "<td valign=\"top\">";
echo $this->CreateInputCheckbox($id, 'javascript_pack', '1', '1');
echo "</td>";
echo "</tr>";

echo "<tr>";
echo "<td valign=\"top\">";
echo $this->CreateLabelForInput($id, 'javascript_global', $this->Lang('global'));
echo "</td>";
echo "<td valign=\"top\">";
echo $this->CreateInputCheckbox($id, 'javascript_global', '1', '1');
echo "</td>";
echo "</tr>";

echo "<tr>";
echo "<td valign=\"top\">";
echo $this->CreateLabelForInput($id, 'javascript_sort_order', $this->Lang('order'));
echo "</td>";
echo "<td valign=\"top\">";
echo $this->CreateInputText($id, 'javascript_sort_order', $sort_order);
echo "</td>";
echo "</tr>";

echo "<tr>";
echo "<td valign=\"top\" colspan=\"2\">";
echo $this->CreateInputSubmit($id, 'javascript_submit', $this->Lang('save_javascript'));
echo "</td>";
echo "</tr>";

echo "</table>";

echo $this->CreateFormEnd();

?>