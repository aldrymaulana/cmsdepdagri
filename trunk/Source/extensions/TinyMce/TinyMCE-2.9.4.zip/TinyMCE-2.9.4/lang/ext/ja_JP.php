<?php
$lang['stripbackgroundtags'] = 'CSSからの背景タグを外します。';
$lang['false'] = 'いいえ';
$lang['true'] = 'はい';
$lang['submit'] = '送信';
$lang['help'] = <<<EOF
	<h3>何ができるのでしょうか?</h3>
	<p>TinyMCEをウィジウィグエディタとして利用できます。</p>
	<h3>使用方法</h3>
	<p>インストールし、ユーザー画面設定から、TinyMCEをウィジウィグエディタとして選択します。</p>
EOF;
?>
