<?php
$lang['description'] = 'Ein umfangreiches Inlineeditormodul.';
$lang['admdescription'] = 'Ein umfangreiches Inlineeditormodul.';
$lang['help'] = '<h3>Verwendung</h3>
<ul>
  <li>
    1) <span style=&quot;color:orange&quot;>Wichtig!</span> F&uuml;gen Sie den {cms_module module=&quot;touchInlineEdit&quot;} Tag in jedes Template in dem Sie das Modul nutzen m&ouml;chten oben direkt nach dem {process_pagedata} Tag ein.<br />
    2) Konfigurieren Sie die Gruppenrechte (setze Berechtigung: Use touchInlineEdit) oder konfigurieren Sie die optionale FrontentUser (FEU) Unterst&uuml;tzung.
  </li>
</ul>
<h3>&Uuml;ber</h3>
<ul>
  <li>Copyright by <a href="http://www.touchdesign.de/">touchDesign</a></li>
  <li>Autor Christoph Gruber</li>
  <li>CMSms TouchInlineEdit <a href="http://dev.cmsmadesimple.org/projects/touchinlineedit">Projektseite</a></li>
  <li>Support via <a href="http://www.homepage-community.de/index.php?topic=1680.0">HPC</a></li>
  <li>License GPL 2.0</li>
</ul>';
$lang['settings'] = 'Einstellungen';
$lang['permissions'] = 'Berechtigungen';
$lang['templates'] = 'Templates';
$lang['editor'] = 'Editor';
$lang['tablecoltemplate'] = 'Template';
$lang['yes'] = 'Ja';
$lang['no'] = 'Nein';
$lang['save'] = 'Speichern';
$lang['edit'] = 'Bearbeiten';
$lang['cancel'] = 'Abbrechen';
$lang['reset'] = 'Zur&uuml;cksetzen';
$lang['settingssaved'] = 'Einstellungen gespeichert.';
$lang['templatessaved'] = 'Template gespeichert.';
$lang['settingsconfirm'] = 'Wenn Sie den InlineEditor wechseln werden alle Einstellungen und Templates die Sie f&uuml;r %s eingerichtet haben zur&uuml;ckgesetzt.';
$lang['nopermission'] = 'Sie haben keine Berechtigung um &Auml;nderungen an TouchInlineEdit vorzunehmen.';
$lang['fePlugin_label'] = 'Welcher Inlineeditor soll verwendet werden.';
$lang['fePlugin_help'] = 'Inlineeditor';
$lang['feEditButton_label'] = 'Editbutton im Frontend';
$lang['feEditButton_help'] = 'Soll ein Button zum de-/aktivieren von InlineEdit angezeigt werden?';
$lang['feEditButtonText_label'] = 'Editbutton text';
$lang['feEditButtonText_help'] = 'Editbutton text.';
$lang['feEditButtonText_default'] = 'TouchInlineEdit';
$lang['feUpdateAlertMessage_label'] = 'Updatenachricht?';
$lang['feUpdateAlertMessage_help'] = 'M&ouml;chten Sie einen Hinweis nach erolgreichem speichern des Inhaltes im Browser ausgeben?';
$lang['feUpdateAlertMessage_default'] = 'Inhalt erfolgreich gespeichert...';
$lang['touchInlineEditButton_label'] = 'Editbutton-Template';
$lang['feEditOnDblClick_label'] = 'Aktiviere InlineEdit durch Doppelklick';
$lang['feEditOnDblClick_help'] = 'Aktiviere InlineEdit durch einen Doppelklick in den Inhaltsbereich.';
$lang['feFEUallow_label'] = 'Erlaube FEU?';
$lang['feFEUallow_help'] = 'Erlaube Frontend Usern das nutzen von InlineEdit.';
$lang['feFEUgroups_label'] = 'FEU Gruppen';
$lang['feFEUgroups_help'] = 'Frontend User Gruppenbeschr&auml;nkungen einrichten.';
$lang['feFEUdisabled_label'] = 'FrontEndUser (FEU) Support ist deaktiviert.';
$lang['feFEUdisabled_help'] = 'Um InlineEdit mit Frontend User Support (FEU) zu nutzen muss zuvor die FrontendUser Erweiterung installiert werden.';
$lang['feAdminAllow_label'] = 'Erlaube Admins?';
$lang['feAdminAllow_help'] = 'Erlaube Administratoren (mit &quot;Use touchInlineEdit&quot; Berechtigung) das nutzen von InlineEdit.';
$lang['postinstall'] = 'Installation erfolgreich...';
$lang['postuninstall'] = 'Deinstallation erfolgreich...';
$lang['postupgrade'] = 'Upgrade erfolgreich auf Version %s...';
$lang['postcontentupdate'] = 'Inhalt mit content_id:%s aktualisiert.';
$lang['preuninstall'] = 'Durch die Deinstallation gehen alle Einstellungen und Templates verloren! Mit der Deinstallation von InlineEdit fortfahren?';
$lang['nicedit_full_panel_label'] = 'Erweiterte Werkzeugleiste?';
$lang['nicedit_full_panel_help'] = 'Aktiviere erweiterte Werkzegleiste.';
$lang['nicedit_jquery_load_label'] = 'Lade jQuery Scripte.';
$lang['nicedit_jquery_load_help'] = 'Lasse die ben&ouml;tigten jQuery Scripte durch TouchInlineEdit laden.';
$lang['nicedit_button_list_label'] = 'Buttons';
$lang['nicedit_button_list_help'] = 'Passen Sie sich hier Ihre Werkzeigleiste und die verf&uuml;gbaren Kn&ouml;pfe an.';
$lang['nicedit_height_label'] = 'Maximalh&ouml;he';
$lang['nicedit_height_help'] = 'Maximale H&ouml;he des InlineEditors in Pixel der Standard ist&quot;auto&quot;.';
$lang['elrte_toolbar_label'] = 'Welche Werkzeugleiste?';
$lang['elrte_toolbar_help'] = 'W&auml;hlen Sie eine Werkzeugleiste die Sie nutzen m&ouml;chten.';
$lang['elrte_jquery_load_label'] = 'Load jQuery libary';
$lang['elrte_jquery_load_help'] = 'Let InlineEdit load required jQuery libary in header of pages.';
$lang['tiny_mce_jquery_load_label'] = 'Lade jQuery Scripte.';
$lang['tiny_mce_jquery_load_help'] = 'Let InlineEdit load required jQuery libary in header of pages.';
$lang['tiny_mce_theme_label'] = 'Theme';
$lang['tiny_mce_theme_help'] = 'Choose any theme you want.';
$lang['tiny_mce_skin_label'] = 'Skin';
$lang['tiny_mce_skin_help'] = 'Choose any skin you like.';
$lang['tiny_mce_skin_variant_label'] = 'Skin variant';
$lang['tiny_mce_skin_variant_help'] = 'Choose any skin variant you like.';
$lang['tiny_mce_width_label'] = 'Width';
$lang['tiny_mce_width_help'] = 'Editor width in pixel default auto.';
$lang['tiny_mce_height_label'] = 'Height';
$lang['tiny_mce_height_help'] = 'Editor height in pixel default auto.';
$lang['tiny_mce_plugins_label'] = 'Plugins';
$lang['tiny_mce_plugins_help'] = 'Check the plugins you want to use (strg for multiple plugins).';
$lang['tiny_mce_buttons1_label'] = 'First toolbar';
$lang['tiny_mce_buttons1_help'] = 'Customize and insert buttons for your first toolbar.';
$lang['tiny_mce_buttons2_label'] = 'Second toolbar';
$lang['tiny_mce_buttons2_help'] = 'Customize and insert buttons for your second toolbar.';
$lang['tiny_mce_buttons3_label'] = 'Third toolbar';
$lang['tiny_mce_buttons3_help'] = 'Customize and insert buttons for your third toolbar.';
$lang['tiny_mce_forced_root_block_label'] = 'Force root block';
$lang['tiny_mce_forced_root_block_help'] = 'Enable focre root block.';
$lang['tiny_mce_force_br_newlines_label'] = 'Newlines BR';
$lang['tiny_mce_force_br_newlines_help'] = 'Enable break tag BR for newlines.';
$lang['tiny_mce_force_p_newlines_label'] = 'Newlines P';
$lang['tiny_mce_force_p_newlines_help'] = 'Enable paragraph tag P for newlines.';
$lang['tiny_mce_entity_encoding_label'] = 'Entity encoding';
$lang['tiny_mce_entity_encoding_help'] = 'Choose entity encoding.';
$lang['tiny_mce_theme_advanced_resizing_label'] = 'Resizing';
$lang['tiny_mce_theme_advanced_resizing_help'] = 'Enable resizing.';
$lang['utma'] = '156861353.2012804222.1301515057.1305136886.1305143093.13';
$lang['utmz'] = '156861353.1305053051.11.3.utmcsr=dev.cmsmadesimple.org|utmccn=(referral)|utmcmd=referral|utmcct=/project/files/882';
$lang['qca'] = 'P0-1397392617-1301515056795';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>