<?php
$cur_dir = dirname(__FILE__);
$messages = array(
    'about',
    'changelog',
    'help'
);

foreach($messages as $message) {
    $lang[$message] = file_get_contents($cur_dir.DIRECTORY_SEPARATOR.$message);
}

$lang['postinstall']    = 'Thank you for install DL Suite: Support. Please refer to the help page for more information on its usage.';
$lang['postuninstall']  = 'I am sorry to see that you have uninstall DL Suite: Support. I am always looking to make this module better so please take some time to let me know what were some of the problems that led you to uninstall this module.';
$lang['preuninstall']   = 'Are you sure you want to uninstall DL Suite: Support?';
?>