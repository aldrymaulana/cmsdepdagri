<?php
if(!($this instanceof DLSupport)) { exit; }

// Make sure given method can be used
if(!in_array($params['method'], array_keys(DLSupport::$smarty_methods))) {
    error_log('DLSupport: Calling an unsupported method');
    return;
}

// Should we return the value? Defaults to FALSE
$params['return'] = isset($params['return']) ? $params['return'] : FALSE;

// Should we output the value? Defaults to TRUE
$params['output'] = isset($params['output']) ? $params['output'] : TRUE;

// Should be assign the result to a value? Defaults to FALSE
$params['set'] = is_string($params['set']) && strlen($params['set']) > 0 ? $params['set'] : FALSE;

// Create the arguments array
$the_arguments = DLSupport::CreateParameters(
    DLSupport::$smarty_methods[$params['method']]['parameters'], $params
);

// Is it static or instance
if(DLSupport::$smarty_methods[$params['method']]['static']) {
    $klass = array('DLSupport', $params['method']);
} else {
    $klass = array($this, $params['method']);
}

// Call the function and store its result if it has any
$result = call_user_func_array($klass, $the_arguments);

// Output the result if we want to
if($params['output']) {
    echo $result;
}

// Assign the value to Smarty if we want to
if($params['set']) {
    // Get the current list of values
    $current_values = $this->smarty->get_template_vars('dlsupport');

    if(empty($current_values)) {
        $current_values = array();
    }

    // Set the result
    $current_values[$params['set']] = $result;

    // Store back to Smarty
    $this->smarty->assign('dlsupport', $current_values);
}

// Return the result if we want to
if($params['return']) {
    return $result;
}
?>