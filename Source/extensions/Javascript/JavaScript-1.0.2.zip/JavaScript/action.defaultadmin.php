<?php

if (!isset($gCms)) { return false; };

$tab = '';

if (FALSE == empty($params['active_tab'])) { $tab = $params['active_tab']; }

echo $this->StartTab('javascript', $params);
require_once(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'function.tabs_javascript.php');
echo $this->EndTab();

?>