<?php

echo "nothing for you here";
die();

?>
