<?php
if (!isset($gCms)) exit;

$this->DoAction('detail', $id, $params, $returnid);

# vim:ts=4 sw=4 noet
?>
