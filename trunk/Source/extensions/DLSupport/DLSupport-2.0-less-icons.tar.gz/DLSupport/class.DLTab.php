<?php
/*
    Class: DLTab
        Use in conjunction with <DLSupportJS.Tab> to hanlde a tab collection.
*/
class DLTab {
    /*
        Group: Private Data

        String: $content_wrapper
            (string) The ID of the content wrapper.
    */
    private $content_wrapper = '';

    /*
        String: $tab_wrapper
            (string) The ID of the tab wrapper.
    */
    private $tab_wrapper = '';

    /*
        Array: $tabs
            (array) An array containing all of tabs and their content.

            The array has the following structure
            (code)
            array(
                 {id of tab} => Array (
                     tab_id => {
                        (string) The ID of the tab.
                    },
                     name => {
                        (string) The title of the tab.
                    },
                     data => {
                        (string) The data for the content of the tab.
                    },
                     is_link => {
                        (boolean) Whether or not the data is a link.
                    },
                     load_once => {
                        (boolean) Whether link should only be loaded once.
                    }
                 ),
                 ...
            )
            (end)
    */
    private $tabs = array();

    /*
        Group: Class Construction

        Constructor: __construct
            Create a new instance of DLTab.

        Parameters:
            $tab_wrapper - (string) The tab wrapper's ID.
            $content_wrapper - (string) The content wrapper's ID.

        Returns:
            An instance of DLTab.
    */
    public function __construct($tab_wrapper, $content_wrapper) {
        $this->tab_wrapper = $tab_wrapper;
        $this->content_wrapper = $content_wrapper;
    }

    /*
        Group: Tab Management

        Method: AddTab
            Add a new tab to the list of tabs.

        Parameters:
            $id - (string) The ID of the tab. Set this to an empty string to
                have an ID automatically generated for it.
            $name - (string) The title of the tab.
            $data - (string) The data for the content of the tab.
            $options - (array) An associative array containing various options
                used by this method. Defaults to an empty array.

            The structure of the *$options* parameter, if given, should look
            like the following:
            (code)
            array(
                link => {
                    (boolean) If this is set to TRUE, then the given *$data*
                    should be the URL for which the content should be retrieved.
                    Defaults to FALSE.
                },
                once => {
                    (boolean) If this is set to TRUE and if the option *link* is
                    also TRUE, then the content will only be fetched once.
                    Defaults to FALSE.
                }
            )
            (end)
    */
    public function AddTab($id, $name, $data, $options = array()) {
        // Get the options
        $options = array_merge(array(
            'link' => FALSE,
            'once' => FALSE
        ), $options);

        // Generate the $id if needed
        if(empty($id)) {
            $id = uniqid();
        }

        // Store tab data
        $this->tabs[$id] = array(
            'tab_id' => $id,
            'name' => $name,
            'data' => $data,
            'is_link' => $options['link'],
            'load_once' => $options['once']
        );
    }

    /*
        Group: HTML Retrieval

        Method: GetAllHTML
            Get all of the HTML.

        Returns:
            (string) All of the HTML.
    */
    public function GetAllHTML() {
        $result = $this->GetTabHTML();
        $result .= $this->GetContentHTML();
        $result .= $this->GetJavaScript();

        return $result;
    }

    /*
        Method: GetContentHTML
            Retrieve the HTML for the Contents.

        Returns:
            (string) The HTML for the Content wrapper and its contents.
    */
    public function GetContentHTML() {
        static $tpt = '<div id="%s">%s</div>';

        // Get the HTML for each content block
        $contents = '';
        foreach($this->tabs as $tab) {
            $contents .= sprintf($tpt,
                $this->content_wrapper.'_'.$tab['tab_id'],
                $tab['is_link'] ? '' : $tab['data']
            );
        }

        // Get the wrapper
        $result = sprintf($tpt, $this->content_wrapper, $contents);

        return $result;
    }

    /*
        Method: GetJavaScript
            Get the HTML for the initialization of the script.

            Note that this does not include the actual source code itself as
            that should have already been loaded via DLSupportJS.

        Parameters:
            $name - (string) Optional and defaults to an empty string. The tab
                collection name. Leave it as an empty string to use a randomly
                generated string.
            $default - (string) Optional and defaults to an empty string. The ID
                of the tab that should be first shown to the user. Leave it as
                an empty string to use the first tab declared.

        Returns:
            (string) The HTML for the JavaScript initialization.
    */
    public function GetJavaScript($name = '', $default = '') {
        // Use the first tab if the default is empty
        if(empty($default)) {
            $keys = array_keys($this->tabs);

            if(!empty($keys)) {
                $default = $keys[0];
            } else {
                return '';
            }
        }

        // Make sure the name is given
        if(empty($name)) {
            $name = uniqid();
        }

        $result = sprintf(
            '<script type="text/javascript">'.
            'var %s = new DLSupportJS.Tab("%s", "%s", "%s");'.
            '</script>',
            $name, $default, $this->tab_wrapper, $this->content_wrapper
        );

        return $result;
    }

    /*
        Method: GetTabHTML
            Retrieve the HTML for the Tabs.

        Returns:
            The HTML for the Tab wrapper and its tabs.
    */
    public function GetTabHTML() {
        // Get the HTML for each tab block
        $tabs = '';
        foreach($this->tabs as $tab) {
            $tab_link = '';
            $load_once = '';

            // Work on the tab link
            if($tab['is_link']) {
                $tab_link = 'TabURL="'.$tab['data'].'" TabLoaded="false"';

                // Work on the load once
                $load_once = $tab['load_once'] ? 'TabOnce="true"' : 'TabOnce="false"';
            }

            $tabs .= sprintf('<li id="%s" %s %s>%s</li>',
                $this->tab_wrapper.'_'.$tab['tab_id'],
                $tab_link, $load_once
            );
        }

        // Get the wrapper
        $result = sprintf('<ul id="%s">%s</ul>', $this->tab_wrapper, $tabs);

        return $result;
    }
}
?>