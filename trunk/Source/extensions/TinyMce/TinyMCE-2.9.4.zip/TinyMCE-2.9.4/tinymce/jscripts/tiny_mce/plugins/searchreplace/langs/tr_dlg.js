tinyMCE.addI18n('tr.searchreplace_dlg',{
searchnext_desc:"Tekrar ara",
notfound:"Arama tamamland\u0131. Aranan metin bulunamad\u0131.",
search_title:"Bul",
replace_title:"Bul/De\u011Fi\u015Ftir",
allreplaced:"Aranan metin bulundu\u011Fu yerlerde de\u011Fi\u015Ftirildi.",
findwhat:"Aranacak",
replacewith:"De\u011Fi\u015Ftirilecek",
direction:"Y\u00F6n",
up:"Yukar\u0131",
down:"A\u015Fa\u011F\u0131",
mcase:"B\u00FCy\u00FCk/k\u00FC\u00E7\u00FCk harf e\u015Fle",
findnext:"Sonrakini bul",
replace:"De\u011Fi\u015Ftir",
replaceall:"T\u00FCm\u00FCn\u00FC de\u011Fi\u015Ftir"
});