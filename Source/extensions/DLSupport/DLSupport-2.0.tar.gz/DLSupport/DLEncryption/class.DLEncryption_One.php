<?php // No sense in declaring this class if it is already declared
if(!class_exists('DLEncryption_One')) {

/*
    Class: DLEncryption_One
        Encryption class based on AzDGCrypt. Originally written by AzDG
        (support@azdg.com)
*/
class DLEncryption_One extends DLEncryption {
    /*
        Group: Unique Methods

        Method: Preprocess
            Preprocess the given data.

        Parameters:
            $key - (string) The key used to encrypt and decrypt the given data.
            $data - (string) The data that is being encrypted or decrypted.

        Returns:
            (string) The data after it has been proccessed.
    */
    private function Preprocess($key, $data) {
        $length = strlen($data);
        $r = md5($key);
        $c = 0;
        $result = '';

        for($i = 0; $i < $length; ++$i) {
            if($c == strlen($r)) { $c = 0; }

            $result .= substr($data, $i, 1) ^ substr($r, $c, 1);
            ++$c;
        }

        return $result;
    }

    /*
        Group: Inherit Methods

        Method: Decrypt
            Decrypt the given data using the given key.

        See:
            <DLEncryption->Decrypt>
    */
    public function Decrypt($key, $data) {
        // Get the hash of the key
        $key = $this->Hash($key, 10);

        // Preprocess the data
        $preprocess = $this->Preprocess($key, base64_decode($data));
        $length = strlen($preprocess);

        // Start decrypting
        $result = '';
        for($i = 0; $i < $length; ++$i) {
            $md5 = substr($preprocess, $i, 1);
            ++$i;

            $result .= (substr($preprocess, $i, 1) ^ $md5);
        }

        // Unserialize the result
        $result = unserialize($result);

        return $result;
    }

    /*
        Method: Encrypt
            Encrypt the given data using the given key.

        See:
            <DLEncryption->Encrypt>
    */
    public function Encrypt($key, $data) {
        // Get the hash of the key
        $key = $this->Hash($key, 10);

        $r = md5(uniqid());
        $c = 0;
        $result = '';

        // Serialize the data
        $tmp = serialize($data);
        $length = strlen($tmp);

        // Start encrypting
        for($i = 0; $i < $length; ++$i) {
            if($c == strlen($r)) { $c = 0; }

            $result .= substr($r, $c, 1) . (substr($tmp, $i, 1) ^ substr($r, $c, 1));
            ++$c;
        }

        // Base64 Encode the result
        $result = base64_encode($this->Preprocess($key, $result));

        return $result;
    }
}

}
?>