To install File List 1.0.1:

1) Put function.file_list.php in plugin directory.
2) Put appicons folder in uploads/images/