/*
    Class: DLSupport.AJAX
        Send and retrieve information without reloading page.

        This is used when we cannot use Prototype.
*/
DLSupport.AJAX = {
    /*
        Method: monitor
            Monitor the states of the AJAX object and call the appropriate
            callback functions.

        Parameters:
            ajax - (object) The AJAX transport.
            error - (function) The function to call if there was an error while
                the request is being made.
            failure - (function) The function to call if the request was a
                failure.
            success - (function) The function to call if the request was a
                success.
    */
    monitor: function(ajax, error, failure, success) {
        // Only continue if the request is loaded (readyState is 4)
        if(ajax.readyState == 4) {
            // Make sure it was successful
            try {
                if(ajax.status == 200) {
                    // It was a success, call the success callback function
                    success.apply(this, [ajax]);
                } else {
                    // It was not a success but is not an error, call the
                    // failure callback function
                    failure.apply(this, [ajax]);
                }
            } catch(e) {
                // Add error message to error log
                DLSupport.addErrorLog('DLSupport.AJAX.monitor', [ajax, error, failure, success], e.message);

                // Call the error callback function
                error.apply(this, [ajax, e.message]);
            }
        }
    },

    /*
        Method: request
            Make a request to the given url using the given method and
            parameters.

        Parameters:
            url - (string) The URL of the page to request.
            options - (object) An object containing various options used by this
                method. Defaults to an empty object

            The structure of the *options* parameter, if given, should look like
            the following:
            (code)
            Object(
                method: {
                    (string) The method to use to make the request. This should
                    be either "GET" or "POST". Defaults to "POST".
                },
                onError: {
                    (function) The callback function to call if at any time an
                    error occurred in the request. Defaults to a function that
                    alerts the user that an error has occurred.
                },
                onFailure: {
                    (function) The callback function for a request that has
                    failed. Defaults to an empty function.
                },
                onSuccess: {
                    (function) The callback function for a successful request.
                    Defaults to an empty function.
                },
                parameters: {
                    (object) An object containing any information to be sent to
                    the requested URL. Defaults to an empty object.
                },
                query_string: {
                    (string) If given, this will be used instead of the
                    "parameters" option. This should be a properly formed query
                    string to be sent to the server. Defaults to an empty
                    string.
                }
            )
            (end)

        Returns:
            (mixed) The AJAX transport. This can be eitehr XMLHttpRequest or
            ActiveXObject, depending on the browser.
    */
    request: function(url) {
        var options = DLSupport.defaultValues(arguments[1] || {}, {
            method: 'POST',
            parameters: {},
            query_string: '',
            onError: function(ajax, message) { window.alert(message); },
            onFailure: function() {},
            onSuccess: function() {}
        });

        // Convert the paramters to a query string
        var parameters = (options.query_string.length > 0) ?
                         options.query_string :
                         DLSupport.toQueryString(options.parameters);

        // Create the AJAX object
        var ajax;
        if(window.XMLHttpRequest) { // Mozilla, Safari, ...
            ajax = new XMLHttpRequest();
        } else if(window.ActiveXObject) { // IE
            try {
                ajax = new ActiveXObject("Msxml2.XMLHTTP");
            } catch (e) {
                try {
                    ajax = new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) { // If we made it here, we have to just give up
                    // Add error message to error log
                    DLSupport.addErrorLog('DLSupport.AJAX.request', [url], e.message);

                    // Call the error callback function
                    options.onError.apply(this, [ajax, 'Failed to create AJAX object: '+e.message]);
                    return;
                }
            }
        }

        // Monitor the changes in the AJAX state
        ajax.onreadystatechange = DLSupport.curry(
            DLSupport.AJAX.monitor, this, ajax,
            options.onError, options.onFailure, options.onSuccess
        );

        // If method is "GET", append params to the url
        if(options.method.toUpperCase() == 'GET') {
            url = ((url.indexOf('?') == -1) ? '?' : '&')+parameters;
            parameters = '';
        }

        // Open the connection
        ajax.open(options.method.toUpperCase(), url, true);

        // If method is "POST", set the appropriate request header
        if(options.method.toUpperCase() == 'POST') {
            ajax.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        }

        // Send the request
        ajax.send(parameters);

        return ajax;
    }
};