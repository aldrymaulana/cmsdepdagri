<?php
if(!cmsms()) exit;
echo $this->mkLink($id,$returnid,$params,true);
return;
