<?php
$lang['help'] = '<h3>Usage</h3>
<ul>
  <li>Load module - {cms_module module=&quot;touchInlineEdit&quot;}</li>
</ul>
<h3>About</h3>
<ul>
  <li>Copyright by <a href="http://www.touchdesign.de/">touchDesign</a></li>
  <li>Author Christoph Gruber</li>
  <li>Support via <a href="http://www.homepage-community.de/index.php?topic=1680.0">HPC</a></li>
  <li>License GPL 2.0</li>
</ul>';
$lang['settings'] = 'Instellingen';
$lang['permissions'] = 'Permissies';
$lang['templates'] = 'Sjablonen';
$lang['editor'] = 'Editor ';
$lang['tablecoltemplate'] = 'Sjabloon';
$lang['yes'] = 'Ja';
$lang['no'] = 'Nee';
$lang['save'] = 'Opslaan';
$lang['edit'] = 'Wijzig';
$lang['cancel'] = 'Annuleer';
$lang['reset'] = 'Reset ';
$lang['settingssaved'] = 'Instellingen opgeslagen.';
$lang['templatessaved'] = 'Sjabloon opgeslagen.';
$lang['fePlugin_label'] = 'Welke editor wilt u gebruiken?';
$lang['fePlugin_help'] = 'Selecteer een editor.';
$lang['feEditButton_label'] = 'Wijzig button in FE?';
$lang['feEditButton_help'] = 'Add enable/disable button for inline edit in frontend.';
$lang['feFullPanel_label'] = 'Uitgebreidde toolbar?';
$lang['feFullPanel_help'] = 'Enable advanced toolbar for inline edit.';
$lang['feUpdateAlert_label'] = 'Update signalering?';
$lang['feUpdateAlert_help'] = 'Enable update alert in frontend.';
$lang['touchInlineEditButton_label'] = 'Inline edit button template:';
$lang['feEditOnDblClick_label'] = 'Activate inline edit on double click?';
$lang['feEditOnDblClick_help'] = 'Activate inline edit on double click in content area.';
$lang['feInlineEditButton'] = 'Wijzig';
$lang['feUpdateAlert'] = 'Content is opgeslagen...';
$lang['feFEUallow_label'] = 'Allow FEU?';
$lang['feFEUallow_help'] = 'Allow frontend users to use inline edit.';
$lang['feFEUgroups_label'] = 'Set FEU group(s)?';
$lang['feFEUgroups_help'] = 'Set FEU group restrictions.';
$lang['feFEUdisabled_label'] = 'FrontEndUser (FEU) support is disabled.';
$lang['feFEUdisabled_help'] = 'To use inline edit with frontend user support you have to install the frontend users (FEU) module.';
$lang['feAdminAllow_label'] = 'Allow admins?';
$lang['feAdminAllow_help'] = 'Allow admin users (with &quot;Use touchInlineEdit&quot; permissions) to use inline edit.';
$lang['postinstall'] = 'Install success...';
$lang['postuninstall'] = 'Uninstall success...';
$lang['postupgrade'] = 'Upgrade success version %s...';
$lang['postcontentupdate'] = 'Content with content_id:%s updated.';
$lang['preuninstall'] = 'Are you sure you want to uninstall this module and destroy all settings/templates?';
$lang['niceditFullPanel_label'] = 'Extended toolbar?';
$lang['niceditFullPanel_help'] = 'Use extended toolbar.';
$lang['niceditJQueryLoad_label'] = 'Load jQuery libary';
$lang['niceditJQueryLoad_help'] = 'Let inline edit load required jQuery libary in header of pages.';
$lang['elrteToolbar_label'] = 'Welke toolbar?';
$lang['elrteToolbar_help'] = 'Choose any toolbar you like.';
$lang['elrteJQueryLoad_label'] = 'Laadt jQuery library';
$lang['elrteJQueryLoad_help'] = 'Let inline edit load required jQuery libary in header of pages.';
$lang['utma'] = '156861353.1335698708.1284586217.1293733507.1293740018.685';
$lang['utmz'] = '156861353.1293453495.653.57.utmcsr=dev.cmsmadesimple.org|utmccn=(referral)|utmcmd=referral|utmcct=/bug/list/6';
$lang['qca'] = 'P0-1551306179-1284586216711';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353.2.10.1293740018';
?>