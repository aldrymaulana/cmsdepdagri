// We only need one instance of DLComments
if(!this.DLComments) {



/*
    Class: [JavaScript] DLComments
        Auxilary class for DL Suite: Comments.

    About: Author
        Duc Tri Le <cmsmadesimple---at---email.tiger-inc.com>

    About: License
        This class is released under the GNU General Public License.
*/
var DLComments = {
    /*
        Method: copyData
            Copy the inner HTML of the original element to a textarea (creating
            it if it doesn't already exist. This will hide the original element
            and restore it when the textarea loses focus.

        Parameters:
            field - (string) The type of field to create.
            original - (object) The DOM element in which the inner HTML will be
                retrieved from.
            type - (string) The type of settings: approval|modify.
            name - (string) The name of the input field.
            id - (string) The ID.
    */
    copyData: function(field, original, type, name, id) {
        // Check the checkbox
        var check_box = DLSupport.getElement('DLComments_checkbox_'+type+'_'+id);
        check_box.checked = true;

        var field_span = DLSupport.getElement('DLComments_'+type+'_'+name+'_edit_'+id);

        // Create the field element if it doesn't already exist
        if(field_span.innerHTML == '') {
            // Create the element
            var element = document.createElement(field);

            // Set the element properties
            element.name = 'DLComments_'+name+'_'+id;
            if(type == 'input') { element.type = 'text'; }

            // Add the element to document
            field_span.appendChild(element);
        }

        // Get the text area
        var field_element = field_span.firstChild;

        // Copy the content of the given element over to the textarea and style
        field_element.value = original.innerHTML;
        field_element.style.width = '95%';
        if(field == 'textarea') { field_element.style.height = '150px'; }

        // Set the onblur event
        field_element.onblur = DLSupport.curry(DLComments.restoreData, this, original, field_span, field_element);

        // Hide the original element and show the textarea span
        original.style.display = 'none';
        field_span.style.display = '';
        field_element.focus();
    },

    /*
        Method: restoreData
            Copy the value of the field back to the original element while
            keeping the field in the document.

        Parameters:
            original - (object) The original DOM element.
            field_span - (object) The span that contains the field.
            field - (object) The field from which the value is to be retrieved.
    */
    restoreData: function(original, field_span, field) {
        // Copy the value of the textarea to the original element
        original.innerHTML = field.value;

        // Hide the textarea span and show the original element
        field_span.style.display = 'none';
        original.style.display = '';
    },

    /*
        Method: serverResponse
            Process the server response.

        Parameters:
            form - (object) The form that began the request.
            message_area - (object) The DOM element that will hold the message
                returned by the request.
            html_area - (object) The DOM element that will hold the HTML
                returned by the request.
            transport - (object) The AJAX transport.
    */
    serverResponse: function(form, message_area, html_area, transport) {
        // Decode the response
        var response = JSON.parse(transport.responseText);

        // Only continue if it is a valid object
        if(response) {
            // Display the server message unless we didn't have one
            if((response.message.length > 0) && message_area) {
                message_area.style.display = '';
                message_area.style.color = response.success ? '#009F3C' : '#DF0024';
                message_area.innerHTML = response.message;

                window.location.hash = message_area.id;
            } else if(message_area) {
                message_area.style.display = 'none';
            }

            // See if we need to hide the HTML area
            if(response.hide_html_area && html_area) {
                html_area.style.display = 'none';
            } else if((response.html.length > 0) && html_area) {
                html_area.style.display = '';
                html_area.innerHTML = response.html;
            }
        } else {
            window.alert('An error occurred during transmission. Terminating.');
        }

        // Enable all of the submit buttons
        DLSupport.Form.enableSubmitFields(form);
        DLSupport.hideLoadingImage();
    },

    /*
        Method: showHide
            Toggle the display of the given data and update the given link to
            reflect the new action.

        Parameters:
            link - (object) The link that will toggle the display of the data.
            data - (object) An object containing various information about what
                to toggle. It includes the id of the element to hide or show,
                and the text of the link when that element is hidden and when it
                is visible.
    */
    showHide: function(link, data) {
        var element = DLSupport.getElement(data.id);

        // Depending on the status, continue appropriately
        if(link.innerHTML == data.show) {
            element.style.display = '';
            link.innerHTML = data.hide;
        } else {
            element.style.display = 'none';
            link.innerHTML = data.show;
        }
    },

    /*
        Method: submitForm
            Submit a form to the server.

        Parameters:
            form - (object) The form to submit.
            type - (string) The type of request.
    */
    submitForm: function(form, type) {
        // Get some data
        var message_area = DLSupport.getElement('DLComments_message_area_'+type);
        var html_area = DLSupport.getElement('DLComments_html_area_'+type);

        // Convert the form data to a query string
        var query_string = DLSupport.Form.toQueryString(form);

        // Disable all of the submit buttons
        DLSupport.Form.disableSubmitFields(form);
        DLSupport.showLoadingImage('red');

        // Submit the form
        DLSupport.AJAX.request(form.action, {
            method: form.method,
            query_string: query_string,
            onSuccess: DLSupport.curry(DLComments.serverResponse, this, form, message_area, html_area)
        });

        return false;
    }
};



}