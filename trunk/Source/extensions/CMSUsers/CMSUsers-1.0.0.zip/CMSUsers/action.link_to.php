<?php
if(!cmsms()) exit;
echo $this->mkLink($id,$returnid,$params);
return;
