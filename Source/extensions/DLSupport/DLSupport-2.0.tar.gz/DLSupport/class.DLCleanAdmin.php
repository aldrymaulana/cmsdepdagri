<?php
/*
    Class: DLCleanAdmin
        Manage the clean admin site.
*/
class DLCleanAdmin {
    /*
        Group: Member Data

        String: $default_content
            (string) The default content of the default page.
    */
    private $default_content;

    /*
        Array: $pages
            An associative array containing the pages in this clean admin site.

            The structure of this array should look like the following:
            (code)
            array(
                array(
                    title => {(string) The title of the page.},
                    url => {(string) The URL of the page.}
                ),
                ...
            )
            (end)
    */
    private $pages;

    /*
        Group: Class Construction

        Constructor: __construct
            Create a new clean admin site.

        Returns:
            (DLCleanAdmin) An instance of DLCleanAdmin.
    */
    public function __construct() {
        $this->default_content = '';
        $this->pages = array();
    }

    /*
        Group: Output

        Method: OutputAsAJAX
            Output the given data so that it can be read by JavaScript.

        Parameters:
            $action - (string) The action to return.
            $data - (array) An associative array containing the data to be sent
                back to the clean admin page.
    */
    public function OutputAsAJAX($action, $data) {
        // Add in the action
        $data['action'] = $action;

        // Output the JSON
        DLSupport::JSON($data);
    }

    /*
        Method: OutputSite
            Output the site but outputting the index page.

        Parameters:
            $title - (string) The title of the site.
            $options - (array) An associative array containing various options
                used by this method. Defaults to an empty array.

            The structure of the *$options* parameter, if given, should look
            like the following:
            (code)
            array(
                css => array(
                    {(string) URL to a CSS file.},
                    ...
                ),
                javascript => array(
                    {(string) URL to a JavaScript file.},
                    ...
                ),
                logo => {
                    (string) The URL to image to be used as the logo. The image
                    must have a dimension of 180x180 pixels. If this is an
                    empty string, it will randomly select one of the default
                    logos. Defaults to an empty string.
                }
            )
            (end)
    */
    public function OutputSite($title, $options = array()) {
        // Get the options
        $options = array_merge(array(
            'css'           => array(),
            'javascript'    => array(),
            'logo'          => ''
        ), $options);

        // Set the CSS and JavaScript
        $the_css = array();
        foreach($options['css'] as $css) {
            $the_css[] = sprintf(
                '<link rel="stylesheet" type="text/css" href="%s" />', $css
            );
        }
        $the_css = implode('', $the_css);

        $the_javascript = array();
        foreach($options['javascript'] as $javascript) {
            $the_javascript[] = sprintf(
                '<script type="text/javascript" src="%s"></script>', $javascript
            );
        }
        $the_javascript = implode('', $the_javascript);
        
        // Determine the logo
        if(empty($options['logo'])) {
            $options['logo'] = DLSupport::ModuleURL('DLSupport').
                '/images/cleanadmin/logo_'.mt_rand(1, 8).'.png';
        }

        // Get an instance of DLSupport
        $DLS = DLSupport::Singleton();

        // Set data to Smarty
        $DLS->smarty->assign('DLCleanAdmin', array(
            'title' => $title,
            'javascript' => $the_javascript,
            'css' => $the_css,
            'logo' => $options['logo'],
            'pages' => $this->pages,
            'default_content' => $this->default_content
        ));

        // Output
        DLSupport::CleanExit($DLS->ProcessTemplate('DLCleanAdmin.output_site.tpl'));
    }

    /*
        Group: Page Management

        Method: AddPage
            Add a new page to the clean admin site.

        Parameters:
            $url - (string) The URL of the page.
            $title - (string) The title of the page.
    */
    public function AddPage($url, $title) {
        // Add the page
        $this->pages[] = array('title' => $title, 'url' => $url);
    }
    
    /*
        Method: GetBreadcrumb
            Retrieve the breadcrumb for a clean admin page.

        Parameters:
            $data - (array) An array of pages containing the breadcrumb
                information.

            The structure of the *$data* parameter, if given, should look like
            the following:
            (code)
            array(
                array(
                    url => {
                        (string) The URL of the page. This can be an empty
                        string in which case, no link is created.
                    },
                    text => {
                        (string) The title of the page.
                    }
                ),
                ...
            )
            (end)

        Returns:
            (string) The HTML for the breadcrumb.
    */
    public function GetBreadcrumb($data) {
        // Get an instance of DLSupport
        $DLS = DLSupport::Singleton();

        // Set the data to Smarty
        $DLS->smarty->assign('DLCleanAdmin', array(
            'breadcrumb' => $data
        ));

        // Process
        $result = $DLS->ProcessTemplate('DLSupport.clean_breadcrumb.tpl');

        return $result;
    }

    /*
        Method: OverwriteDefaultPage
            Overwrite the default page content.

        Parameters:
            $content - (string) The HTML for the default page.
    */
    public function OverwriteDefaultPage($content) {
        $this->default_content = $content;
    }
}