<?php

$lang = array(
	
	
	
	
	
// Exceptions

'field_is_empty' => 'The field %s is empty.',	
'field_cannot_be_empty' => 'The field "%s" cannot be empty.',	
'unknown field' => 'Unknown field "%s"',
'fields not equal' => 'The "%s" and "%s" have to be the same.',
'invalid email' => 'The email &laquo;%s&raquo; is not valid.',
'field not unique' => '%s already exists.',
'select one' => 'Select one',
	
	
	
	
	
	
);