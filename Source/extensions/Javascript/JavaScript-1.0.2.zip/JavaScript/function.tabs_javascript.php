<?php

$row_count = 0;

$query = "SELECT * FROM {$this->table_base}javascript ORDER BY javascript_sort_order;";
$rsjavascript = $this->db->Execute($query);

echo "<table cellspacing=0 class=\"pagetable\"><thead>\n";
echo "<tr><td colspan=\"5\" valign=\"top\">" . $this->CreateLink($id, 'javascript_new', $returnid, $this->Lang('new_javascript')) . "</td></tr>";
echo "<tr>";
echo "<td valign=\"top\">" . $this->Lang('id') . "</td>";
echo "<td valign=\"top\">" . $this->Lang('name') . "</td>";
echo "<td valign=\"top\"></td>";
echo "<td valign=\"top\">" . $this->Lang('order') . "</td>";
echo "<td valign=\"top\">" . $this->Lang('delete') . "</td>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";

while ( ($rsjavascript) && (!$rsjavascript->EOF) ) {
	$row_count++;
	$row_class = ($row_count % 2) ? 'row1' : 'row2';
	$row_class_hover = $row_class . 'hover';
	echo "<tr class=\"$row_class\" onmouseover=\"this.className=\'$row_class_hover\';\" onmouseout=\"this.className=\'$row_class\';\">";
	echo "<td valign=\"top\">{$rsjavascript->fields['javascript_id']}</td>";
	echo "<td valign=\"top\">" . $this->CreateLink($id, 'javascript_edit', $returnid, $rsjavascript->fields['javascript_name'], array("javascript_id" => $rsjavascript->fields['javascript_id'])) . "</td>";
	echo "<td valign=\"top\">{JavaScript javascript='{$rsjavascript->fields['javascript_alias']}'}</td>";
	echo "<td valign=\"top\">{$rsjavascript->fields['javascript_sort_order']}</td>";
	echo "<td valign=\"top\">" . $this->CreateLink($id, 'javascript_delete', $returnid, $gCms->variables['admintheme']->DisplayImage('icons/system/delete.gif', sprintf($this->Lang('delete_javascript'), $rsjavascript->fields['javascript_name'])), array("javascript_id" => $rsjavascript->fields('javascript_id')), sprintf($this->Lang('confirm_delete'), $rsjavascript->fields['javascript_name'])) . "</td>";
	echo "</tr>";
	$rsjavascript->MoveNext();
}

echo "<tr><td colspan=\"5\" valign=\"top\">" . $this->CreateLink($id, 'javascript_new', $returnid, $this->Lang('new_javascript')) . "</td></tr>";

echo "</tbody>";
echo "</table>";

?>