<? 
	$lang['friendlyname'] = 'FrontEnd Editor';
	
	$lang['postinstall'] = 'FrontEndEditor has been successfully installed!<br/>
							If the module misses some function you would like to have sent a request in the forge.<br/>
							<a href="http://dev.cmsmadesimple.org/feature_request/list/770">place your request here</a><br/>
							If you find any bugs please let me know so i can fix them;)<br/>
							<a href="http://dev.cmsmadesimple.org/feature_request/list/770">Place your bugs here</a>';
	
	$lang['uninstall_confirm'] = 'Are you sure you want to uninstall the FrontEndEditor module?';
	
	$lang['postuninstall'] = 'FrontEndEditor has been successfully un-installed.<br/>
							  Please leave me a comment why you uninstalled the module so i can improve it futher.';
	
	$lang['changelog'] = '1.2 version - FrontEndEditor<br/>
						  UPDATES :<br/>
						  *Main conten of pages is used instead of a other database table<br/>
						  *Complete rewrite of module to be more efficent<br/>
						  *Only one tag has to be used in template for it to work<br/>
						  <br/>
						  BUGFIX :<br/>
						  *none if you find any let me know';
	
	$lang['help'] = "FrontEndEditor - version 1.2<br/>
					 With this module you can edit the content of your website trough the front end of your website<br/>
					 To place on your website use this tag in your template {cms_module module='FrontEndEditor' action='add_text'}<br/>
					 Be aware that there is no security in this module so anyone that see it can use it.<br/>
					 So i advise using the costum content module to protect it from people that are not allowed to change your website's content<br/>
					 <br/>
					 If the module misses some function you would like to have sent a request in the forge.<br/>
					 <a href='http://dev.cmsmadesimple.org/feature_request/list/770'>place your request here</a><br/>
					 If you find any bugs please let me know so i can fix them;)<br/>
					 <a href='http://dev.cmsmadesimple.org/feature_request/list/770'>Place your bugs here</a>";
	
	$lang['submit'] = 'submit';
	
	$lang['cancel'] = 'cancel';
	
	$lang['changed'] = 'Your text has been changed to:';
		
	$lang['textbx'] = 'Place your new text here';
	
	$lang['formtitle'] = 'Edit box';
?>
