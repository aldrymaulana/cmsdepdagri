<?php
$lang['help'] = '<h3>Внедрение</h3>
<ul>
  <li>Вставьте тег {cms_module module="touchInlineEdit"} между тегами <head> в шаблоне.</li>
</ul>
<h3>About</h3>
<ul>
  <li>Copyright by <a href="http://www.touchdesign.de/">touchDesign</a></li>
  <li>Author Christoph Gruber</li>
  <li>CMSms TouchInlineEdit <a href="http://dev.cmsmadesimple.org/projects/touchinlineedit">project page</a></li>
  <li>Support via <a href="http://www.homepage-community.de/index.php?topic=1680.0">HPC</a></li>
  <li>License GPL 2.0</li>
</ul>';
$lang['settings'] = 'Настройки';
$lang['permissions'] = 'Права';
$lang['templates'] = 'Шаблоны';
$lang['editor'] = 'Редактор';
$lang['tablecoltemplate'] = 'Шаблон';
$lang['yes'] = 'Да';
$lang['no'] = 'Нет';
$lang['save'] = 'Сохранить';
$lang['edit'] = 'Редактировать';
$lang['cancel'] = 'Отменить';
$lang['reset'] = 'Вернуть настройки по умолчанию';
$lang['settingssaved'] = 'Настройки сохранены.';
$lang['templatessaved'] = 'Шаблон сохранен.';
$lang['fePlugin_label'] = 'Какой редактор использовать?';
$lang['fePlugin_help'] = 'Выбор редактора';
$lang['feEditButton_label'] = 'Кнопка "Редактировать" во фронтенде';
$lang['feEditButton_help'] = 'Добавить включить/отключить кнопку для редактора во фронтенде.';
$lang['feUpdateAlert_label'] = 'Уведомлять о сохранениях?';
$lang['feUpdateAlert_help'] = 'Включить подтверждение о сохранении во фронтенде';
$lang['touchInlineEditButton_label'] = 'Шаблон для кнопки редактирования';
$lang['feEditOnDblClick_label'] = 'Загрузка редактора двойным щелчком?';
$lang['feEditOnDblClick_help'] = 'Загружать редактор двойным нажатием мыши на контент.';
$lang['feInlineEditButton'] = 'Редактировать';
$lang['feUpdateAlert'] = 'Страница сохранена...';
$lang['feFEUallow_label'] = 'Разрешить использование FEU (FrontEndUsers)';
$lang['feFEUallow_help'] = 'Разрешить редактирование для пользователей сайта';
$lang['feFEUgroups_label'] = 'Настроить группы FEU?';
$lang['feFEUgroups_help'] = 'Настроить ограничения групп пользователей.';
$lang['feFEUdisabled_label'] = 'Отключить поддержку FEU (FrontEndUsers).';
$lang['feFEUdisabled_help'] = 'Для того, чтобы разрешить редактирование контента пользователями сайта, необходима установка модуля FEU (FrontEndUsers).';
$lang['feAdminAllow_label'] = 'Права редакторов?';
$lang['feAdminAllow_help'] = 'Разрешить редакторам (с правами "Use touchInlineEdit") использование модуля InlineEdit.';
$lang['postinstall'] = 'Установка прошла успешно...';
$lang['postuninstall'] = 'Модуль был удален...';
$lang['postupgrade'] = 'Успешное обновление до версии %s...';
$lang['postcontentupdate'] = 'Страница с content_id:%s обновлена.';
$lang['preuninstall'] = 'Вы уверены, что хотите удалить модуль. Все настройки будут сброшены, а шаблоны удалены.';
$lang['niceditFullPanel_label'] = 'Расширенная панель?';
$lang['niceditFullPanel_help'] = 'Использовать расширенную панель редактора.';
$lang['niceditJQueryLoad_label'] = 'Подгружать библиотеку JQuery.';
$lang['niceditJQueryLoad_help'] = 'Позволить модулю загружать библиотеку JQeury в <head>.';
$lang['elrteToolbar_label'] = 'Панель редактора?';
$lang['elrteToolbar_help'] = 'Выберите панель для редактора.';
$lang['elrteJQueryLoad_label'] = 'Загружать библиотеку JQuery.';
$lang['elrteJQueryLoad_help'] = 'Позволить модулю загружать библиотеку JQeury в <head>.';
$lang['qca'] = 'P0-1938388883-1277855813144';
$lang['utma'] = '156861353.429593658.1277855813.1293976069.1293984629.155';
$lang['utmz'] = '156861353.1293937905.152.73.utmcsr=wiki.cmsmadesimple.org|utmccn=(referral)|utmcmd=referral|utmcct=/index.php/User_Handbook/Admin_Panel/Tags/content_dump';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>