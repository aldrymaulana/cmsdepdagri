<?php
// Specify this is JavaScript
header('Content-Type: text/javascript');
header('Pragma: cache');

// Now we set up the caching data
$offset = 31556926;	// 1 year
$etag = md5('2.0RC3_'.$_SERVER['REQUEST_URI'].'_'.gmdate('D, d M Y H:i:s', filemtime(__FILE__)));

header('Expires: '. gmdate('D, d M Y H:i:s', time()+$offset) . ' GMT');
header('Cache-Control: must-revalidate, max-age='.(time()+$offset));
header('ETag: '.$etag);

// List of files to include in content
$files = array(
    'class.js',
    'dlsupportjs.js',
    'dlsupportjs.cleanadmin.js',
    'dlsupportjs.tab.js'
);

// Retrieve the contents
$dir = dirname(__FILE__).DIRECTORY_SEPARATOR;
$content = '';
foreach($files as $file) {
    $content .= file_get_contents($dir.$file);
    $content .= "\n\n\n";
}

// Now, if browser supports gzip, use it, otherwise, show use the old thing
$use_gzip = is_numeric(strpos($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip')) &&
            !is_numeric(strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE'));
if($use_gzip) {
    header('Content-Encoding: gzip');
    $content = gzencode($content);
}

header('Content-Length: '.strlen($content));
echo $content;
?>