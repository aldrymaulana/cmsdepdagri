<?php
if(!($this instanceof DLComments)) { exit; }

$response = $this->GetCommentsListing($id, $returnid, $params);

DLSupport::CleanExit(json_encode($response));
?>