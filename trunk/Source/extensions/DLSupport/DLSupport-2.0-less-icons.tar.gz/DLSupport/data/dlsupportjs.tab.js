/*
    Class: DLSupportJS.Tab
        Sub class of <DLSupportJS> providing support for the tabs.
*/
DLSupportJS.Tab = new JS.Class({
    /*
        Array: Contents
            (array) An array of contents.
    */
    Contents: [],

    /*
        Object: ContentWrapper
            (object) The wrapper element for the contents.
    */
    ContentWrapper: null,

    /*
        Object: CurrentlyOpenTab
            (object) The currently opened tab.
    */
    CurrentlyOpenTab: null,

    /*
        Array: Tabs
            (array) An array of tabs.
    */
    Tabs: [],

    /*
        Object: TabWrapper
            (object) The wrapper element for the tabs.
    */
    TabWrapper: null,

    /*
        Method: initialize
            Initialize the script.

        Parameters:
            tab - (string) The ID or the object that should be the currently
                opened tab. Note that this should not include the wrapper ID.
            tabs - (mixed) The ID or the object that is the wrapper for the
                tabs.
            contents - (mixed) The ID or the object that is the wrapper for the
                contents.
    */
    initialize: function(tab, tabs, contents) {
        tabs = $(tabs);
        contents = $(contents);

        // Make sure given objects exist
        if(!(tabs && contents)) { return; }

        // Set the tabs wrapper data
        tabs.identify();
        this.TabWrapper = tabs;
        this.Tabs = tabs.childElements();

        // Set the contents wrapper data
        contents.identify();
        this.ContentWrapper = contents;
        this.Contents = contents.childElements();

        // Add events to the current tabs
        for(var i = 0; i < this.Tabs.length; ++i) {
            this.addEvents(this.Tabs[i]);
        }

        // Show the selected table
        tab = $(this.getId(tab));
        this.showTab(tab);
    },

    /*
        Method: addEvents
            Add events to the given tab.

        Parameters:
            tab - (object) The tab that will observe various events.
    */
    addEvents: function(tab) {
        Event.observe(tab, 'click', function(tab) {
            this.showTab(tab);
        }.bind(this, tab));

        Event.observe(tab, 'mouseover', function(tab) {
            tab.addClassName('hover');
        }.bind(this, tab));

        Event.observe(tab, 'mouseout', function(tab) {
            tab.removeClassName('hover');
        }.bind(this, tab));
    },

    /*
        Method: addTab
            Add in a new tab with the given ID. If the ID already exist, this
            will just show that tab.

        Parameters:
            id - (string) The ID of the tab.
            name - (string) The title of the tab.
            data - (string) The data for the content of the tab.
            options - (object) An object containing various options used by this
                method. Defaults to an empty object.

        options Attributes:
            link - (boolean) If this is true, then the given "data" should be
                the URL for which the content should be retrieved. Defaults to
                false.
            once - (boolean) If this is true and if *link* is true, then the
                content will only be fetched one time. Defaults to false.
    */
    addTab: function(id, name, data) {
        // Get the options
        var options = Object.extend({
            link:   false,
            once:   false
        }, arguments[3] || {});

        // Get the full ID
        var tabID = this.getId(id);
        var contentID = this.getId(id, 'content');

        // Make sure both the tab ID and content ID doesn't exist
        var tab = $(tabID);
        var content = $(contentID);
        if(tab && content) {
            // Since it already exist, just show the tab
            this.showTab(tab); return;
        } else if(tab || content) {
            // Since only one exist, we cannot add
            return;
        }

        // Create the tab
        var tabLi = new Element('li', {id: tabID});
        tabLi.update(name);

        // Set link information
        if(options.link) {
            tabLi.writeAttribute({
                TabURL:     data,
                TabLoaded:  'false',
                TabOnce:    options.once ? 'true' : 'false'
            });
            data = '&nbsp;';
        }

        // Create the content
        var contentDiv = new Element('div', {id: contentID});
        contentDiv.update(data);

        // Append the new tab and its content
        this.TabWrapper.insert(tabLi);
        this.ContentWrapper.insert(contentDiv);

        // Update stored data
        this.Tabs = this.TabWrapper.childElements();
        this.Contents = this.ContentWrapper.childElements();

        // Add events for the tab
        this.addEvents(tabLi);

        // Show the tab
        this.showTab(tabLi);
    },

    /*
        Method: getId
            Get the true ID of the given data.

        Parameters:
            data - (mixed) The current ID or the object with the ID.
            type - (string) The type of ID to get. Possible values are "tab" and
                "content". This is optional and defaults to "tab".

        Returns:
            (string) The ID.
    */
    getId: function(data) {
        var type = arguments[1] || 'tab';

        // If it is an object with the id property, use other, otherwise,
        // just use the given data
        var result = data.id || data;

        // First, remove the wrapper portion
        result = result.replace(this.TabWrapper.id+'_', '');
        result = result.replace(this.ContentWrapper.id+'_', '');

        // Add back in the appropriate type
        if(type == 'tab') {
            result = this.TabWrapper.id+'_'+result;
        } else {
            result = this.ContentWrapper.id+'_'+result;
        }

        return result;
    },

    /*
        Method: loadPage
            Load the page of the given object.

        Parameters:
            obj - (object) The object for which the page is to be loaded.
    */
    loadPage: function(obj) {
        new Ajax.Request(obj.readAttribute('TabURL'), {
            onFailuire: function() {
                window.alert('Sorry, but the content of this tab could not be loaded');
            },
            onSuccess: function(obj, transport) {
                var content = $(this.getId(obj, 'content'));
                content.update(transport.responseText);
                obj.writeAttribute('TabLoaded', 'true');
            }.bind(this, obj)
        });
    },

    /*
        Method: removeTab
            Remove the given tab and its contents.

            Note that if the tab to be removed is the currently opened tab, the
            new currently opened tab will be the first tab in the tabs list.

        Parameters:
            tab - (string) The ID of the tab to remove. Note that this should
                not include the wrapper ID.
    */
    removeTab: function(tab) {
        tab = $(this.getId(tab));
        var content = $(this.getId(tab, 'content'));

        // Make sure they exist
        if(!(tab && content)) {
            return;
        }

        // See if the tab to be removed is the currently opened tab
        if(content == this.CurrentlyOpenTab) {
            // Show the first tab that is not the tab to be removed
            var tabToShow = null;
            for(var i = 0; i < this.Contents.length; ++i) {
                tabToShow = this.Contents[i];
                if(tabToShow != this.CurrentlyOpenTab) { break; }
            }
            this.showTab(tabToShow);
        }

        // Remove the tab
        tab.remove();

        // Remove the content
        content.remove();

        // Update stored data
        this.Tabs = this.TabWrapper.childElements();
        this.Contents = this.ContentWrapper.childElements();
    },

    /*
        Method: showTab
            Show the given tab while hiding all the other tabs.

        Parameters:
            tab - (object) The tab to show.
    */
    showTab: function(tab) {
        // Get the ID of the tab
        tab = this.getId(tab);

        // Hide all the other tabs while showing the given tab
        var currentTabId;
        for(var i = 0 ; i < this.Tabs.length; ++i) {
            currentTabId = this.getId(this.Tabs[i]);

            if(tab == currentTabId) {
                this.Tabs[i].addClassName('selected');
                this.Contents[i].show();
                this.CurrentlyOpenTab = this.Contents[i];

                // If it is a link, retrieve its content
                if(this.Tabs[i].readAttribute('TabURL')) {
                    if(!(this.Tabs[i].readAttribute('TabOnce') == 'true') ||
                       !(this.Tabs[i].readAttribute('TabLoaded') == 'true')) {
                        this.loadPage(this.Tabs[i]);
                        continue;
                    }
                }
            } else {
                this.Tabs[i].removeClassName('selected');
                this.Contents[i].hide();
            }
        }
    }
});