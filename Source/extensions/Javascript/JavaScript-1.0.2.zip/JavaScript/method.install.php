<?php

$db = $this->GetDb();
$taboptarray = array('mysql' => 'TYPE=MyISAM');
$dict = NewDataDictionary($db);

/* Tables */
$flds = "
	  javascript_id I KEY
	, javascript_name C(255)
	, javascript_alias C(255)
	, javascript_content X
	, javascript_sort_order I
	, javascript_compress L
	, javascript_external_include L
	, javascript_global L
	, javascript_pack L
	, javascript_created " . CMS_ADODB_DT . "
	, javascript_modified T DEFTIMESTAMP
;";
$sqlarray = $dict->CreateTableSQL(cms_db_prefix() . 'module_javascript', $flds, $taboptarray);
$dict->ExecuteSQLArray($sqlarray);
$db->CreateSequence(cms_db_prefix() . 'module_javascript_seq');

?>