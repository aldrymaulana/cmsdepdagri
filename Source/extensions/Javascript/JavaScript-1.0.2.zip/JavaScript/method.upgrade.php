<?php

$current_version = $oldversion;

$dict = NewDataDictionary($db);

switch($current_version) {
	case '1.0.0':
		$current_version = '1.0.0';
		break;
	case '1.0.1':
		$current_version = '1.0.1';
		break;
}

?>