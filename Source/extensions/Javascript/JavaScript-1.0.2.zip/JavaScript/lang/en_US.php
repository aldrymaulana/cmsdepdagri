<?php

$lang['friendly_name'] = 'JavaScript';

$lang['id'] = 'Id';
$lang['name'] = 'Name';
$lang['order'] = 'Sort Order';
$lang['delete'] = 'Delete';
$lang['content'] = 'Content';

$lang['new_javascript'] = 'New JavaScript';
$lang['edit_javascript'] = 'Edit JavaScript %s';
$lang['save_javascript'] = 'Save JavaScript';
$lang['delete_javascript'] = 'Delete JavaScript %s';
$lang['created_javascript'] = 'JavaScript has been created';
$lang['saved_javascript'] = 'JavaScript has been saved';

$lang['confirm_delete'] = 'Are you sure you want to delete %s';

$lang['active'] = 'Active';
$lang['inactive'] = 'Inactive';

$lang['minify'] = 'Minify';
$lang['pack'] = 'Pack';
$lang['external'] = 'Externally Linked';
$lang['global'] = 'Add Globally';

$lang['help'] = '<p>Author: Jonathan Nichols &lt;nichols.jonathan.r@gmail.com&gt;</p>
<p><strong>Version: 1.0.0</strong></p>
<p> <strong>Change History:</strong><br/>
	None </p>
<h2>Basic Usage:</h2>
<p>{cms_module module=\'JavaScript\'}<br />
	<strong>Or</strong>{JavaScript}</p>
<h2>Advanced Usage:</h2>
<p>{cms_module module=\'JavaScript\' javascript=\'script-alias\'}<br />
	<strong>Or</strong>{JavaScript javascript=\'script-alias\'}</p>';

?>