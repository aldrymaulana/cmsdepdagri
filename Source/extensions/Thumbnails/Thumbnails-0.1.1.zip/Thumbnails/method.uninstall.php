<?php
  $this->Audit( 0, $this->Lang('friendlyname'), $this->Lang('uninstalled'));
?>