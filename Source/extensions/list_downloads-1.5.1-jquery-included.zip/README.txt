
Installation english:
There are 4 folders with files you need (images, js, php, plugins).
Copy all 4 folders to the root directory of your CMSms installation.
Than, have a look to the tag help (of your CMSms backend) to see how to use the plugin.

Installation deutsch:
Es gibt 4 Ordner mit Dateien, welche ben�tigt werden (images, js, php, plugins).
Kopiere alle 4 Ordner in das Root Verzeichnis Deiner CMSms Installation.
Schaue Dir danach die Hilfe des Plugins/Tags in Deinem CMSms Backend an, um zu lesen, wie Du das Plugin benutzen kannst.
