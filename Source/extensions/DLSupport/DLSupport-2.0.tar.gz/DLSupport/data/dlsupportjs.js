/*
    Class: DLSupportJS
        JavaScript framework using Prototype (<http://www.prototypejs.org>),
        Scriptaculous (<http://script.aculo.us>), and JS.Class
        (<http://jsclass.jcoglan.com>).

    About: Author
        Duc Tri Le <cmsmadesimple---at---email.tiger-inc.com>

    About: License
        This class is released under the GNU General Public License.
*/
var DLSupportJS = {
    /*
        Object: UploadFileOptions
            (object) An object containing a uploaded file options. Mainly used
            to hide the loading image once the file has been uploaded.
    */
    UploadFileOptions: {},

    /*
        Method: HideLoadingImage
            Hide the loading image if it is currently visible.

        Parameters:
            options - (object) An object containing various options used in the
                execution of this method. Refer to the method <HideOverlay> for
                more information on some of these options. Defaults to an empty
                object.

            The structure of the *options* parameter, if given, should look like
            the following:
            (code)
            Object (
                finish: {
                    (function) The function that should be run after the overlay
                    is hidden. Defaults to an empty function.
                },
                keep_overlay: {
                    (boolean) Whether or not the overlay div should be kept
                    visible. Defaults to false.
                },
                remove: {
                    (boolean) Whether or not the overlay div should be removed
                    from the DOM structure as well. Defaults to false.
                },

                duration: {
                    (int) Refer to the "duration" attribute of the parameter
                    "options" from the method HideOverlay.
                },
                remove_overlay: {
                    (boolean) Refer to the "remove" attribute of the parameter
                    "options" from the method HideOverlay.
                }
            )
            (end)

        Returns:
            (boolean) Returns true if successful, false, otherwise.
    */
    HideLoadingImage: function() {
        // Get the options
        var options = Object.extend({
            // Options specifically for this method
            finish:         Prototype.emptyFunction,
            keep_overlay:   false,
            remove:         false,

            // Options for HideOverlay
            duration:       1,
            remove_overlay: false
        }, arguments[0] || {});

        // Get the loading image
        var loading_image = $('DLSupportJS_LoadingImage');

        // Make sure the loading image exists
        if(!loading_image) {
            return false;
        }

        // We need to create a wrapper function if removal is wanted
        if(options.remove) {
            options.finish = function(loading_image, funct) {
                // Remove the loading image
                loading_image.remove();

                // Run the given function
                funct.apply(this);
            }.curry(loading_image, options.finish);
        }

        // Hide the loading image
        loading_image.hide();

        // Hide the overlay if we want to
        if(options.keep_overlay) {
            options.finish.apply(this);
        } else {
            DLSupportJS.HideOverlay({
                duration:   options.duration,
                finish:     options.finish,
                remove:     options.remove_overlay
            });
        }
    },

    /*
        Method: HideOverlay
            Hide the overlay div if it is currently visible.

        Parameters:
            options - (object) An object containing various options used in the
                execution of this method. Defaults to an empty object.

            The structure of the *options* parameter, if given, should look like
            the following:
            (code)
            Object (
                duration: {
                    (int) The time, in seconds, of how long the effect should
                    last. Defaults to 1.
                },
                finish: {
                    (function) The function that should be run after the overlay
                    is hidden. Defaults to an empty function.
                },
                remove: {
                    (boolean) Whether or not the overlay div should be removed
                    from the DOM structure as well. Defaults to false.
                }
            )
            (end)

        Returns:
            (boolean) Returns true if successful, false, otherwise.
    */
    HideOverlay: function() {
        // Get the options
        var options = Object.extend({
            duration:   1,
            finish:     Prototype.emptyFunction,
            remove:     false
        }, arguments[0] || {});

        // Get the overlay div
        var overlay_div = $('DLSupportJS_OverlayDiv');

        // Make sure the overlay div exists
        if(!overlay_div) {
            return false;
        }

        // Set flag that overlay is hidden
        overlay_div.is_hidden = true;

        // We need to create the wrapper function if removal is wanted
        if(options.remove) {
            options.finish = function(overlay_div, funct) {
                // Remove the overlay div
                overlay_div.remove();

                // Run the given function
                funct.apply(this);
            }.curry(overlay_div, options.finish);
        }

        // Hide the overlay
        Effect.Fade(overlay_div, {
            duration:       options.duration,
            from:           overlay_div.getStyle('opacity'),
            afterFinish:    options.finish
        });
    },

    /*
        Method: PageLoading
            Show the loading image when this method is called and hide it when
            the body "onload" event is triggered.

        Parameters:
            options - (object) An object containing various options used in the
                execution of this method. Refer to the methods
                <HideLoadingImage>, <HideOverlay>, <ShowOverlay>, and
                <ShowLoadingImage> for more information on some of these
                attributes. Defaults to an empty object.

            The structure of the *options* parameter, if given, should look like
            the following:
            (code)
            Object (
                wait_time: {
                    (int) The time, in seconds, to wait before the loading image
                    is hidden. Defaults to 0.
                },

                color: {
                    (string) Refer to the "color" attribute of the parameter
                    "options" from the method ShowLoadingImage.
                },
                loading_finish: {
                    (function) Refer to the "finish" attribute of the parameter
                    "options" from the method ShowLoadingImage.
                },
                opacity: {
                    (int) Refer to the "opacity" attribute of the parameter
                    "options" from the method ShowOverlay.
                },
                overlay_color: {
                    (string) Refer to the "color" attribute of the parameter
                    "options" from the method ShowOverlay.
                },

                duration: {
                    (int) Refer to the "duration" attribute of the parameter
                    "options" from the method HideOverlay.
                },
                hiding_finish: {
                    (function) Refer to the "finish" attribute of the parameter
                    "options" from the method HideLoadingImage.
                },
                remove: {
                    (boolean) Refer to the "remove" attribute of the parameter
                    "options" from the method HideLoadingImage.
                }
                remove_overlay: {
                    (boolean) Refer to the "remove" attribute of the parameter
                    "options" from the method HideOverlay.
                }
            )
            (end)

        Returns:
            (boolean) This method will always return true.
    */
    PageLoading: function() {
        // Get the options
        var options = Object.extend({
            // Options specifically for this method
            wait_time: 0,

            // Options for ShowLoadingImage
            color:          "red",
            loading_finish: Prototype.emptyFunction,
            opacity:        75,
            overlay_color:  '#FFFFFF',

            // Options for HideLoadingImage
            duration:       1,
            hiding_finish:  Prototype.emptyFunction,
            remove:         false,
            remove_overlay: false
        }, arguments[0] || {});

        // Show the loading image
        DLSupportJS.ShowLoadingImage({
            duration:       0,

            color:          options.color,
            finish:         options.loading_finish,
            opacity:        options.opacity,
            overlay_color:  options.overlay_color
        });

        // Set an event for hiding the overlay once the page finish loading
        Event.observe(window, 'load', function(options) {
            DLSupportJS.HideLoadingImage.curry({
                duration:       options.duration,
                finish:         options.hiding_finish,
                remove:         options.remove,
                remove_overlay: options.remove_overlay
            }).delay(options.wait_time);
        }.curry(options));
    },

    /*
        Method: ShowLoadingImage
            Show the loading image.

        Parameters:
            options - (object) An object containing various options used in the
                execution of this method. Refer to the method <ShowOverlay> for
                more information on some of the attributes. Defaults to an empty
                object.

            The structure of the *options* parameter, if given, should look like
            the following:
            (code)
            Object (
                color: {
                    (string) The color of the loading image. The following are
                    the supported values: "black", "blue", "brown", "gold",
                    "gray", "green", "navy", "orange", "purple", "red", "white",
                    and "yellow". Defaults to "red".
                },
                finish: {
                    (function) The function that should be run after the loading
                    image is showned. Defaults to an empty function.
                },

                duration: {
                    (int) Refer to the "duration" attribute of the parameter
                    "options" from the method ShowOverlay.
                },
                opacity: {
                    (int) Refer to the "opacity" attribute of the parameter
                    "options" from the method ShowOverlay.
                },
                overlay_color: {
                    (string) Refer to the "color" attribute of the parameter
                    "options" from the method ShowOverlay.
                }
            )
            (end)

        Returns:
            (boolean) The method always returns true.
    */
    ShowLoadingImage: function() {
        // Get the options
        var options = Object.extend({
            // Options specifically for this method
            color:  'red',
            finish: Prototype.emptyFunction,

            // Options for ShowOverlay
            duration:       1,
            opacity:        75,
            overlay_color:  '#FFFFFF'
        }, arguments[0] || {});

        // Create the image if it doesn't already exists
        var loading_image = $('DLSupportJS_LoadingImage');
        if(!loading_image) {
            loading_image = new Element('img', {id: 'DLSupportJS_LoadingImage'});
            loading_image.hide();
            document.body.appendChild(loading_image);
        }

        // Set the image src
        loading_image.writeAttribute(
            'src',
            '/modules/DLSupport/images/loading_images/'+options.color+'.gif'
        );

        // Wrap the given finish function
        options.finish = DLSupportJS._ShowLoadingImage.curry(options.finish);

        // Show the overlay and then show the loading image
        DLSupportJS.ShowOverlay({
            color:      options.overlay_color,
            duration:   options.duration,
            finish:     options.finish,
            opacity:    options.opacity
        });

        return true;
    },
    _ShowLoadingImage: function(funct) {
        // Get the loading image
        var loading_image = $('DLSupportJS_LoadingImage');

        // Get the dimensions of the overlay div
        var overlay_dimensions = $('DLSupportJS_OverlayDiv').getDimensions();

        // Set the position for the loading image
        loading_image.setStyle({
            left:   (overlay_dimensions.width/2 - 50)+'px',
            top:    (overlay_dimensions.height/2 - 50)+'px'
        });

        // Show the loading image
        loading_image.show();

        // Run the given function
        funct.apply(this);
    },

    /*
        Method: ShowOverlay
            Create and show the overlay div if it is currently hidden.

        Parameters:
            options - (object) An object containing various options used in the
                execution of this method. Defaults to an empty object.

            The structure of the *options* parameter, if given, should look like
            the following:
            (code)
            Object (
                color: {
                    (string) The background color of the overlay. Defaults to
                    "#FFFFFF".
                },
                duration: {
                    (int) The time, in seconds, of how long the effect should
                    last. Defaults to 1.
                },
                finish: {
                    (function) The function that should be run after the overlay
                    is showned. Defaults to an empty function.
                },
                opacity: {
                    (int) The opacity percentage for the overlay. This value
                    should be between 0 & 100. Defaults to 75.
                }
            )
            (end)

        Returns:
            (boolean) The method will always return true.
    */
    ShowOverlay: function() {
        // Get the options
        var options = Object.extend({
            color:      '#FFFFFF',
            duration:   1,
            finish:     Prototype.emptyFunction,
            opacity:    75
        }, arguments[0] || {});

        // Create the overlay div if it doesn't already exist
        var overlay_div = $('DLSupportJS_OverlayDiv');
        if(!overlay_div) {
            overlay_div = new Element('div', {id: 'DLSupportJS_OverlayDiv'});
            overlay_div.is_hidden = true;
            overlay_div.hide();
            document.body.appendChild(overlay_div);
        }

        // We use different effects if div is already visible
        if(overlay_div.is_hidden) {
            // Set the background color
            overlay_div.setStyle({backgroundColor: options.color});

            Effect.Appear(overlay_div, {
                duration:       options.duration,
                to:             options.opacity/100,
                afterFinish:    options.finish
            });
        } else {
            // Set the duration to 0 if the colors are the same
            if((overlay_div.current_bg_color == options.color) &&
               (overlay_div.current_opacity == options.opacity)) {
                options.duration = 0;
            }

            // Change the overlay color
            new Effect.Morph(overlay_div, {
                style: {
                    backgroundColor:    options.color,
                    opacity:            ''+(options.opacity/100)
                },
                duration:       options.duration,
                afterFinish:    options.finish
            });
        }

        // Set flag some flags for the overlay div
        overlay_div.is_hidden = false;
        overlay_div.current_bg_color = options.color;
        overlay_div.current_opacity = options.opacity;

        return true;
    },

    /*
        Method: UploadComplete
            This method is called after an upload has been completed.

        Parameters:
            data - (string) JSON data sent by server.
    */
    UploadComplete: function(data) {
        // Evaluate the JSON
        data = data.evalJSON();

        // Call user function
        DLSupportJS.UploadFileOptions.finish.apply(window, [data]);

        // Hide the loading image if we want to
        if(DLSupportJS.UploadFileOptions.hide_loading_image) {
            DLSupportJS.HideLoadingImage({
                duration:       DLSupportJS.UploadFileOptions.hiding_duration,
                keep_overlay:   DLSupportJS.UploadFileOptions.keep_overlay,
                remove:         DLSupportJS.UploadFileOptions.remove,
                remove_overlay: DLSupportJS.UploadFileOptions.remove_overlay
            });
        }
    },

    /*
        Method: UploadFile
            Submit the provided form whose sole purpose is to upload files.

        Parameters:
            form - (mixed) Either the ID of the form or the DOM element for the
                form itself that will be uploading the file.
            options - (object) An object containing various options used by this
                method. Refer to the method <HideLoadingImage>, <HideOverlay>,
                <ShowLoadingImage>, and <ShowOverlay> for more information on
                some of the attributes. Defaults to an empty object.

            The structure of the *options* parameter, if given, should look like
            the following:
            (code)
            Object (
                finish: {
                    (function) The function to run once the upload is complete.
                    Defaults to an empty function.
                },
                hide_loading_image: {
                    (boolean) Whether or not the function HideLoadingImage
                    should be called. Defaults to true.
                }

                keep_overlay: {
                    (boolean) Refer to the "keep_overlay" attribute of the
                    parameter "options" from the method HideLoadingImage.
                },
                remove: {
                    (boolean) Refer to the "remove" attribute of the parameter
                    "options" from the method HideLoadingImage.
                },

                hiding_duration: {
                    (int) Refer to the "duration" attribute of the parameter
                    "options" from the method HideOverlay.
                },
                remove_overlay: {
                    (boolean) Refer to the "remove" attribute of the parameter
                    "options" from the method HideOverlay.
                },

                color: {
                    (string) Refer to the "color" attribute of the parameter
                    "options" from the method ShowLoadingImage.
                },

                loading_duration: {
                    (int) Refer to the "duration" attribute of the parameter
                    "options" from the method ShowOverlay.
                },
                opacity: {
                    (int) Refer to the "opacity" attribute of the parameter
                    "options" from the method ShowOverlay.
                },
                overlay_color: {
                    (string) Refer to the "color" attribute of the parameter
                    "options" from the method ShowOverlay.
                },
            )
            (end)

        Returns:
            (boolean) This method will always return true.
    */
    UploadFile: function(form) {
        // Get the options
        var options = Object.extend({
            // Attributes specifically for this method
            finish:             Prototype.emptyFunction,
            hide_loading_image: true,

            // Attributes for HideLoadingImage
            hiding_duration:    1,
            keep_overlay:       false,
            remove:             false,
            remove_overlay:     false,

            // Attributes for ShowLoadingImage
            color:              'red',
            loading_duration:   1,
            opacity:            75,
            overlay_color:      '#FFFFFF'
        }, arguments[1] || {});

        // Make sure it is an object
        form = $(form);

        // Create the iframe if needed
        var iframe = $('DLSupportJS_UploadIFrame');
        if(!iframe) {
            iframe = new Element('iframe', {
                id:     'DLSupportJS_UploadIFrame',
                name:   'DLSupportJS_UploadIFrame'
            });
            iframe.hide();

            document.body.appendChild(iframe);
        }

        // Set the target of the form to the iframe
        form.target = 'DLSupportJS_UploadIFrame';

        // Store the upload options
        DLSupportJS.UploadFileOptions = options;

        // Show the loading image
        DLSupportJS.ShowLoadingImage({
            color:          options.color,
            duration:       options.loading_duration,
            opacity:        options.opacity,
            overlay_color:  options.overlay_color
        });

        return true;
    }
};